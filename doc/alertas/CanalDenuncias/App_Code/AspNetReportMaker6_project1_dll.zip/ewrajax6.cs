using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	//
	// Page class
	//
	public class crlookup<C>		
		where C : cConnectionBase, new()
	{

		// 
		// Page main
		//
		public void Page_Main() {
			if (!IsPost)
				return; // No post data
			var sql = ewr_Post("s");
			sql = ewr_Decrypt(sql);
			if (sql == "")
				ewr_End("Missing SQL.");

			// Field delimiter
			var dlm = ewr_Post("dlm");
			dlm = ewr_Decrypt(dlm);

			// Language object
			ReportLanguage = new crLanguage();
			var value = "";
			if (sql.Contains("{filter}")) {
				var filters = "";
				for (var i = 0; i < 5; i++) {

					// Get the filter values (for "IN")
					var filter = ewr_Decrypt(ewr_Post("f" + i), EWR_RANDOM_KEY);
					if (filter != "") {
						value = ewr_Post("v" + i);
						if (value == "") {
							if (i > 0) { // Empty parent field

								//continue; // Allow
								ewr_AddFilter(ref filters, "1=0"); // Disallow
							}
							continue;
						}
						var arValue = value.Split(new[] {','});
						var fldtype = ewr_ConvertToInt(ewr_Post("t" + i));
						var wrkfilter = "";
						for (var j = 0; j < arValue.Length; j++) {						
							if (ewr_NotEmpty(wrkfilter))
								wrkfilter += " OR ";
							var val = arValue[j];
							if (val == EWR_NULL_VALUE)
								wrkfilter += filter.Replace(" = {filter_value}", " IS NULL");
							else if (val == EWR_NOT_NULL_VALUE)
								wrkfilter += filter.Replace(" = {filter_value}", " IS NOT NULL");
							else if (val == EWR_EMPTY_VALUE)
								wrkfilter += filter.Replace(" = {filter_value}", " = ''");
							else
								wrkfilter += filter.Replace("{filter_value}", ewr_QuotedValue(val, ewr_FieldDataType(fldtype)));
						}						
						ewr_AddFilter(ref filters, wrkfilter);
					}
				}
				sql = sql.Replace("{filter}", (filters != "") ? filters : "1=1");
			}

			// Get the query value (for "LIKE" or "=")
			value = ewr_AdjustSql(ewr_Post("q"));
			if (value != "") {
				sql = Regex.Replace(sql, @"LIKE '(%)?\{query_value\}%'", ewr_Like("'$1{query_value}%'")); //???
				sql = sql.Replace("{query_value}", value);
			}

			// Date search type and format
			var ds = ewr_Post("ds"); // Date search type
			var df = ewr_Post("df"); // Date format
			List<OrderedDictionary> rsarr;

			// Connect to database
			var Conn = new C(); // AXR
			try {
				rsarr = Conn.GetRows(sql);
			} finally {
				Conn.Dispose();
			}

			// Output (using ewr_Response) // ASPX
			ewr_Response.Cache.SetCacheability(HttpCacheability.NoCache);
			var key = new List<string>(); 
			foreach (OrderedDictionary row in rsarr) {				
				var cnt = 1; 			
				if (ewr_NotEmpty(dlm)) {
					cnt = 0;
					for (var j = 0; j < row.Count; j++) {
						if (Convert.ToString(row[j]).Contains(dlm)) {
							var ar = Convert.ToString(row[j]).Split(new char[] { Convert.ToChar(dlm) });
							row[j] = ar;
							if (ar.Length > cnt)
								cnt = ar.Length;
						} else {
							if (cnt < 1)
								cnt = 1;
						}
					}
				}
				for (var k = 0; k < cnt; k++) {
					string val0 = "", str0 = "", str = "";
					for (var j = 0; j < row.Count; j++) {
						var val = row[j];
						if (ewr_NotEmpty(dlm) && ewr_IsList(val)) {
							var ar = (string[])val;
							val = (ar.Length > k) ? ar[k] : ar[0];
						}
						if (j == 0) {
							str = ewr_ConvertValue(ds, val);
							val0 = Convert.ToString(val);
							str0 = str;
						} else if (j == 1 && Convert.IsDBNull(val0)) {
							str = ReportLanguage.Phrase("NullLabel");
						} else if (j == 1 && ewr_Empty(val0)) {
							str = ReportLanguage.Phrase("EmptyLabel");
						} else if (j == 1) {
							str = ewr_DropDownDisplayValue(ewr_ConvertValue(ds, val), ds, ewr_ConvertToInt(df));
						} else {
							str = Convert.ToString(val);
						}
						if (!key.Contains(str0))
							ewr_Response.Write(ewr_RemoveDelimiters(str) + EWR_FIELD_DELIMITER);
					}
					if (!key.Contains(str0)) {
						ewr_Response.Write(EWR_RECORD_DELIMITER);
						key.Add(str);
					}
				}				
			}			
			ewr_End(); // ASPX
		}
	}
}
