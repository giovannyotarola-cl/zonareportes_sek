using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Report Maker 6 - Project Configuration
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	// Debug
	public const bool EWR_DEBUG_ENABLED = false; // Set to true for debugging

	public static int EWR_OBJECTINFO_DEPTH = 10; // ObjectInfo // ASPX

	public static int EWR_OBJECTINFO_ENUMERATION_LENGTH = 1000; // ObjectInfo // ASPX

	// Project
	public const string EWR_PROJECT_CLASSNAME = "AspNetReportMaker6_project1"; // ASPX

	public const string EWR_ROOT_RELATIVE_PATH = "."; // Relative path of app root

	public const string EWR_DEFAULT_DATE_FORMAT = "dd/mm/yyyy";

	public const short EWR_DEFAULT_DATE_FORMAT_ID = 7;

	public const string EWR_DATE_SEPARATOR = "/";

	public const short EWR_UNFORMAT_YEAR = 50; // Unformat year	

	public const string EWR_PROJECT_NAME = "project1"; // Project name

	public const string EWR_PROJECT_VAR = "project1"; // Project var

	public const string EWR_CONFIG_FILE_FOLDER =  EWR_PROJECT_NAME + ""; // Config file name	

	public const string EWR_PROJECT_ID = "{5E252714-15AD-4FF5-8F78-DA7E4D955D0D}"; // Project ID (GUID)

	public const string EWR_RANDOM_KEY = "VIC5ZDqnSRt1OjoA"; // Random key for encryption

	public const string EWR_PROJECT_STYLESHEET_FILENAME = "aspxrptcss/project1.css"; // Project stylesheet file name	

	public const int EWR_CODEPAGE = 65001; // Code page

	public const string EWR_CHARSET = "utf-8"; // Project charset	

	public const string EWR_PATH_DELIMITER = "\\"; // Path delimiter

	public const string EWR_RECORD_DELIMITER = "\r";

	public const string EWR_FIELD_DELIMITER = "\t";

	public const bool EWR_USE_DOM_XML = false;	

	// Language settings
	public const string EWR_LANGUAGE_FOLDER = "aspxrptlang/";

	public static List<string[]> EWR_LANGUAGE_FILE = new List<string[]>() {
		new[] {"en", "", "english.xml"}	
	};

	public const string EWR_LANGUAGE_DEFAULT_ID = "en";

	public const string EWR_SESSION_LANGUAGE_ID = EWR_PROJECT_NAME + "_LanguageId"; // Language ID	

	// Database
	public const bool EWR_IS_MSACCESS = false; // Access

	public const bool EWR_IS_MSSQL = true; // MS SQL

	public const bool EWR_IS_MYSQL = false; // MySQL

	public const bool EWR_IS_POSTGRESQL = false; // PostgreSQL

	public const bool EWR_IS_ORACLE = false; // Oracle	

	public const string EWR_DB_CONNECTION_STRING = "Persist Security Info=False;Data Source=192.168.200.228;Initial Catalog=Matricula;User Id=sa;Password=Sa070507";

	public const string EWR_DB_PROVIDER_NAME = "System.Data.SqlClient";

  	public const string EWR_DB_QUOTE_START = "["; 

	public const string EWR_DB_QUOTE_END = "]";	

	public const string EWR_DB_SQLPARAM_SYMBOL = "@"; // Database SQL parameter symbol

	public const string EWR_DB_SCHEMA = "Matricula"; // For Oracl

	// Remove XSS
	public const bool EWR_REMOVE_XSS = true;

	public static string[] EWR_REMOVE_XSS_KEYWORDS = new[] {"javascript", "vbscript", "expression", "<applet", "<meta", "<xml", "<blink", "<link", "<style", "<script", "<embed", "<object", "<iframe", "<frame", "<frameset", "<ilayer", "<layer", "<bgsound", "<title", "<base", "onabort", "onactivate", "onafterprint", "onafterupdate", "onbeforeactivate", "onbeforecopy", "onbeforecut", "onbeforedeactivate", "onbeforeeditfocus", "onbeforepaste", "onbeforeprint", "onbeforeunload", "onbeforeupdate", "onblur", "onbounce", "oncellchange", "onchange", "onclick", "oncontextmenu", "oncontrolselect", "oncopy", "oncut", "ondataavailable", "ondatasetchanged", "ondatasetcomplete", "ondblclick", "ondeactivate", "ondrag", "ondragend", "ondragenter", "ondragleave", "ondragover", "ondragstart", "ondrop", "onerror", "onerrorupdate", "onfilterchange", "onfinish", "onfocus", "onfocusin", "onfocusout", "onhelp", "onkeydown", "onkeypress", "onkeyup", "onlayoutcomplete", "onload", "onlosecapture", "onmousedown", "onmouseenter", "onmouseleave", "onmousemove", "onmouseout", "onmouseover", "onmouseup", "onmousewheel", "onmove", "onmoveend", "onmovestart", "onpaste", "onpropertychange", "onreadystatechange", "onreset", "onresize", "onresizeend", "onresizestart", "onrowenter", "onrowexit", "onrowsdelete", "onrowsinserted", "onscroll", "onselect", "onselectionchange", "onselectstart", "onstart", "onstop", "onsubmit", "onunload"};

	// Chart
	public const int EWR_CHART_WIDTH = 550;

	public const int EWR_CHART_HEIGHT = 440;

	public const string EWR_CHART_ALIGN = "middle";

	public const bool EWR_CHART_SHOW_BLANK_SERIES = false; // Show blank series

	// Drill down setting
	public const bool EWR_USE_DRILLDOWN_PANEL = true; // Use popup panel for drill down

	/**
	 * Password (MD5 and case-sensitivity)
	 * Note: If you enable MD5 password, make sure that the passwords in your
	 * user table are stored as MD5 hash (32-character hexadecimal number) of the
	 * clear text password. If you also use case-insensitive password, convert the
	 * clear text passwords to lower case first before calculating MD5 hash.
	 * Otherwise, existing users will not be able to login.
	 */

	public const bool EWR_ENCRYPTED_PASSWORD = false; // Encrypted password	

	public const bool EWR_CASE_SENSITIVE_PASSWORD = false; // Case Sensitive password

	/**
	 * Numeric and monetary formatting options
	 * Note: DO NOT CHANGE THE FOLLOWING DEFAULT_* VARIABLES!
	 * If you want to use custom settings, customize the language file,
	 * set "use_system_locale" to "0" to override and customize the
	 * phrases under the <locale> node for ewr_FormatCurrency/Number/Percent functions
	*/

	public static bool EWR_USE_SYSTEM_LOCALE = true;

	public static string EWR_DECIMAL_POINT = ".";

	public static string EWR_THOUSANDS_SEP = ",";

	public static string EWR_CURRENCY_SYMBOL = "$";

	// Filter
	public const bool EWR_SHOW_CURRENT_FILTER = false; // True to show current filter

	public const bool EWR_SHOW_DRILLDOWN_FILTER = true; // True to show drill down filter

	// Session names	
	public const string EWR_SESSION_STATUS = EWR_PROJECT_NAME + "_Status"; // Login status	

	public const string EWR_SESSION_USER_NAME = EWR_SESSION_STATUS + "_UserName";	// User name	

	public const string EWR_SESSION_USER_ID = EWR_SESSION_STATUS + "_UserID";	// User ID	

	public const string EWR_SESSION_USER_LEVEL_ID = EWR_SESSION_STATUS + "_UserLevel"; // User level ID		

	public const string EWR_SESSION_USER_LEVEL = EWR_SESSION_STATUS + "_UserLevelValue"; // User level		

	public const string EWR_SESSION_PARENT_USER_ID = EWR_SESSION_STATUS + "_ParentUserID"; // Parent user ID		

	public const string EWR_SESSION_SYS_ADMIN = EWR_PROJECT_NAME + "_SysAdmin"; // System admin

	public const string EWR_SESSION_PROJECT_ID = EWR_PROJECT_NAME + "_ProjectID"; // User Level project ID

	public const string EWR_SESSION_AR_USER_LEVEL = EWR_PROJECT_NAME + "_arUserLevel"; // User level ArrayList	

	public const string EWR_SESSION_AR_USER_LEVEL_PRIV = EWR_PROJECT_NAME + "_arUserLevelPriv"; // User level privilege ArrayList		

	public const string EWR_SESSION_USER_LEVEL_MSG = EWR_PROJECT_NAME + "_UserLevelMessage"; // Security array

	public const string EWR_SESSION_SECURITY = EWR_PROJECT_NAME + "_Security"; // Security array		

	public const string EWR_SESSION_MESSAGE = EWR_PROJECT_NAME + "_Message"; // System message	

	public const string EWR_SESSION_FAILURE_MESSAGE = EWR_PROJECT_NAME + "_Failure_Message"; // System error message

	public const string EWR_SESSION_SUCCESS_MESSAGE = EWR_PROJECT_NAME + "_Success_Message"; // System message

	public const string EWR_SESSION_WARNING_MESSAGE = EWR_PROJECT_NAME + "_Warning_Message"; // Warning message

	// Security
	public const string EWR_ADMIN_USER_NAME = ""; // Administrator user name	

	public const string EWR_ADMIN_PASSWORD = ""; // Administrator password

	public const bool EWR_USE_CUSTOM_LOGIN = true; // Use custom login

	// User admin
	public const string EWR_LOGIN_SELECT_SQL = "";

	// User table filters
	// User level constants
	public const short EWR_ALLOW_LIST = 8; // List

	public const short EWR_ALLOW_REPORT = 8; // Report		

	public const short EWR_ALLOW_ADMIN = 16; // Admin

	// User id constants
	public const bool EWR_USER_ID_IS_HIERARCHICAL = true; // True to show all level / False to show 1 level

	// Table level constants
	public const string EWR_TABLE_PREFIX = "||ASPNETReportMaker||";

	public const string EWR_TABLE_PREFIX_OLD = "||ASPNETReportMaker||";

	public const string EWR_TABLE_GROUP_PER_PAGE = "grpperpage";

	public const string EWR_TABLE_START_GROUP = "start";

	public const string EWR_TABLE_ORDER_BY = "order";

	public const string EWR_TABLE_ORDER_BY_TYPE = "ordertype";

	public const string EWR_TABLE_SORT = "sort"; // Table sort

	public const string EWR_TABLE_SORTCHART = "sortc"; // Table sort chart

	// Data types
	public const short EWR_DATATYPE_NONE = 0;

	public const short EWR_DATATYPE_NUMBER = 1;

	public const short EWR_DATATYPE_DATE = 2;

	public const short EWR_DATATYPE_STRING = 3;

	public const short EWR_DATATYPE_BOOLEAN = 4;

	public const short EWR_DATATYPE_MEMO = 5;

	public const short EWR_DATATYPE_BLOB = 6;

	public const short EWR_DATATYPE_TIME = 7;

	public const short EWR_DATATYPE_GUID = 8;

	public const short EWR_DATATYPE_OTHER = 9;

	// Row types
	public const short EWR_ROWTYPE_DETAIL = 1; // Row type detail

	public const short EWR_ROWTYPE_TOTAL = 2; // Row type group summary

	// Row total types
	public const short EWR_ROWTOTAL_GROUP = 1; // Page summary

	public const short EWR_ROWTOTAL_PAGE = 2; // Page summary

	public const short EWR_ROWTOTAL_GRAND = 3; // Grand summary

	// Row total sub types
	public const short EWR_ROWTOTAL_FOOTER = 1; // Footer

	public const short EWR_ROWTOTAL_SUM = 2; // SUM

	public const short EWR_ROWTOTAL_AVG = 3; // AVG

	public const short EWR_ROWTOTAL_MIN = 4; // MIN

	public const short EWR_ROWTOTAL_MAX = 5; // MAX

	public const short EWR_ROWTOTAL_CNT = 6; // CNT

	// Empty/Null/Not Null/Init/all values
	public const string EWR_EMPTY_VALUE = "##empty##";

	public const string EWR_NULL_VALUE = "##null##";

	public const string EWR_NOT_NULL_VALUE = "##notnull##";

	public const string EWR_INIT_VALUE = "##init##";

	public const string EWR_ALL_VALUE = "##all##";	

	// Boolean values for ENUM('Y'/'N') or ENUM(1/0)
	public const string EWR_TRUE_STRING = "'Y'";

	public const string EWR_FALSE_STRING = "'N'";

	// SQL formats
	public const string EWR_YEAR_SQL = "YEAR(%s)";

	public const string EWR_QUARTER_SQL = "DATEPART(QUARTER,%s)";

	public const string EWR_MONTH_SQL = "MONTH(%s)";

	// Use token in URL (reserved, not used, do NOT change!)
	public const bool EWR_USE_TOKEN_IN_URL = false;

	// Email
	public const string EWR_SMTP_SERVER = "localhost"; // SMTP server	

	public const int EWR_SMTP_SERVER_PORT = 25; // SMTP server port

	public const string EWR_SMTP_SECURE_OPTION = "";	

	public const string EWR_SMTP_SERVER_USERNAME = ""; // SMTP server user name	

	public const string EWR_SMTP_SERVER_PASSWORD = ""; // SMTP server password	

	public const string EWR_SENDER_EMAIL = ""; // Sender email	

	public const string EWR_RECIPIENT_EMAIL = ""; // Recipient email

	public const int EWR_MAX_EMAIL_RECIPIENT = 3;

	public const int EWR_MAX_EMAIL_SENT_COUNT = 3;

	public const string EWR_EXPORT_EMAIL_COUNTER = EWR_SESSION_STATUS + "_EmailCounter";	

	public const int EWR_MAX_EMAIL_SENT_PERIOD = 20;

	public const string EWR_EMAIL_CHARSET = EWR_CHARSET; // Email charset

	public const bool EWR_EMAIL_WRITE_LOG = true; // Write to log file

	public const int EWR_EMAIL_LOG_SIZE_LIMIT = 20; // Email log field size limit

	public const bool EWR_EMAIL_WRITE_LOG_TO_DATABASE = false; // Write email log to database

	public const string EWR_EMAIL_LOG_TABLE_NAME = ""; // Email log table name

	public const string EWR_EMAIL_LOG_FIELD_NAME_DATETIME = ""; // Email log DateTime field name

	public const string EWR_EMAIL_LOG_FIELD_NAME_IP = ""; // Email log IP field name

	public const string EWR_EMAIL_LOG_FIELD_NAME_SENDER = ""; // Email log Sender field name

	public const string EWR_EMAIL_LOG_FIELD_NAME_RECIPIENT = ""; // Email log Recipient field name

	public const string EWR_EMAIL_LOG_FIELD_NAME_SUBJECT = ""; // Email log Subject field name

	public const string EWR_EMAIL_LOG_FIELD_NAME_MESSAGE = ""; // Email log Message field name

	// Export functions
	public static Dictionary<string, string> EWR_EXPORT = new Dictionary<string, string>() {
		{"email", "ExportEmail"},
		{"print", "ExportHtml"},
		{"html", "ExportHtml"},
		{"word", "ExportWord"},
		{"excel", "ExportExcel"},
		{"pdf", "ExportPdf"}
	};

	// Image resize
	public const string EWR_UPLOAD_TMP_PATH = ""; // User upload temp path (relative to app root) e.g. "tmp/"

	public const string EWR_UPLOAD_DEST_PATH = "files/"; // Upload destination path (relative to app root)

	public const string EWR_IMAGE_ALLOWED_FILE_EXT = "gif,jpg,png,bmp"; // Allowed file extensions for images

	public const int EWR_THUMBNAIL_DEFAULT_WIDTH = 0; // Thumbnail default width

	public const int EWR_THUMBNAIL_DEFAULT_HEIGHT = 0; // Thumbnail default height

	public const short EWR_THUMBNAIL_DEFAULT_INTERPOLATION = -1; // Thumbnail default interpolation

	// Use ILIKE for PostgreSql
	public const bool EWR_USE_ILIKE_FOR_POSTGRESQL = true;

	// Use collation for MySQL
	public const string EWR_LIKE_COLLATION_FOR_MYSQL = "";

	// Use collation for MsSQL
	public const string EWR_LIKE_COLLATION_FOR_MSSQL = "";

	// Comma separated values delimiter
	public static string EWR_CSV_DELIMITER = ",";

	// Use mobile menu
	public static bool EWR_USE_MOBILE_MENU = true;

	// Float fields default decimal position
	public const int EWR_DEFAULT_DECIMAL_PRECISION = 2;

	// Validate option
	public const bool EWR_CLIENT_VALIDATE = false;	

	public const bool EWR_SERVER_VALIDATE = false;

	// Auto suggest max entries
	public const int EWR_AUTO_SUGGEST_MAX_ENTRIES = 10;

	// Checkbox and radio button groups
	public const string EWR_ITEM_TEMPLATE_CLASSNAME = "ewTemplate";	

	public const string EWR_ITEM_TABLE_CLASSNAME = "ewItemTable";

	// Cookies
	public static DateTime EWR_COOKIE_EXPIRY_TIME = DateTime.Today.AddDays(365); // Change cookie expiry time here

	// Menu
	public const string EWR_MENUBAR_CLASSNAME = "ewMenuBarVertical";

	public const string EWR_MENUBAR_ITEM_CLASSNAME = "";

	public const string EWR_MENUBAR_ITEM_LABEL_CLASSNAME = "";

	public const string EWR_MENU_CLASSNAME = "ewMenuBarVertical";

	public const string EWR_MENU_ITEM_CLASSNAME = "";

	public const string EWR_MENU_ITEM_LABEL_CLASSNAME = "";

	public const string EWR_PDF_STYLESHEET_FILENAME = ""; // export PDF CSS styles

	// Image resize
	public const bool EWR_RESIZE_ENABLED = false;	

	public const bool EWR_FUSIONCHARTS_FREE = true; // FusionCharts Free

	public const string EWR_FUSIONCHARTS_FREE_JSCLASS_FILE = "FusionChartsFree/JSClass/FusionCharts.js"; // FusionCharts Free

	public const string EWR_FUSIONCHARTS_FREE_CHART_PATH = "FusionChartsFree/Charts/"; // FusionCharts Free
}
