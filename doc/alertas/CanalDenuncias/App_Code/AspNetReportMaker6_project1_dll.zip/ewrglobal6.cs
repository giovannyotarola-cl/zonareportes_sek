using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Report Maker 6 Project Class
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	//
	// Global variables
	//
	// Conn
	public static cConnectionBase Conn {
		get { return (cConnectionBase)ewr_PageData["Conn"]; }
		set { ewr_PageData["Conn"] = value; }
	}

	// Security
	public static cAdvancedSecurityBase Security {
		get { return (cAdvancedSecurityBase)ewr_PageData["Security"]; }
		set { ewr_PageData["Security"] = value; }
	}

	// gsLanguage
	public static string gsLanguage {
		get { return Convert.ToString(ewr_PageData["gsLanguage"]); }
		set { ewr_PageData["gsLanguage"] = value; }
	}

	// gbSkipHeaderFooter
	public static bool gbSkipHeaderFooter {
		get { return ewr_ConvertToBool(ewr_PageData["gbSkipHeaderFooter"]); }
		set { ewr_PageData["gbSkipHeaderFooter"] = value; }
	}

	// StartTime
	public static long StartTime {
		get { return (long)ewr_PageData["StartTime"]; }
		set { ewr_PageData["StartTime"] = value; }
	}

	// CurrentPage
	public static dynamic CurrentPage {
		get { return (dynamic)ewr_PageData["CurrentPage"]; }
		set { ewr_PageData["CurrentPage"] = value; }
	}

	// gsFormError
	public static string gsFormError {
		get { return Convert.ToString(ewr_PageData["gsFormError"]); }
		set { ewr_PageData["gsFormError"] = value; }
	}

	// gsSearchError
	public static string gsSearchError {
		get { return Convert.ToString(ewr_PageData["gsSearchError"]); }
		set { ewr_PageData["gsSearchError"] = value; }
	}

	// gsExport
	public static string gsExport {
		get { return Convert.ToString(ewr_PageData["gsExport"]); }
		set { ewr_PageData["gsExport"] = value; }
	}

	// gsExportFile
	public static string gsExportFile {
		get { return Convert.ToString(ewr_PageData["gsExportFile"]); }
		set { ewr_PageData["gsExportFile"] = value; }
	}

	// gsEmailErrDesc
	public static string gsEmailErrDesc {
		get { return Convert.ToString(ewr_PageData["gsEmailErrDesc"]); }
		set { ewr_PageData["gsEmailErrDesc"] = value; }
	}

	// gsDebugMsg
	public static string gsDebugMsg {
		get { return Convert.ToString(ewr_PageData["gsDebugMsg"]); }
		set { ewr_PageData["gsDebugMsg"] = value; }
	}

	// UserAgent
	public static string[] UserAgent {
		get { return (string[])ewr_PageData["UserAgent"]; }
		set { ewr_PageData["UserAgent"] = value; }
	}

	// gTmpImages = new List<string>()
	public static List<string> gTmpImages = new List<string>();

	// rswrk
	public static List<OrderedDictionary> rswrk;

	// alwrk
	public static List<OrderedDictionary> alwrk;

	// jswrk
	public static string jswrk;

	// selwrk
	public static string selwrk;

	// arwrk
	public static string[] arwrk;

	// sSqlWrk
	public static string sSqlWrk;

	// sWhereWrk
	public static string sWhereWrk;

	// sFilterWrk
	public static string sFilterWrk;

	// sLookupTblFilter
	public static string sLookupTblFilter;

	// wrkonchange
	public static string wrkonchange;

	// ReportLanguage
	public static crLanguage ReportLanguage {
		get { return (crLanguage)ewr_PageData["ReportLanguage"]; }
		set { ewr_PageData["ReportLanguage"] = value; }
	}

	// giChartCnt
	public static int giChartCnt;

	// gbDrillDownInPanel
	public static bool gbDrillDownInPanel {
		get { return ewr_ConvertToBool(ewr_PageData["gbDrillDownInPanel"]); }
		set { ewr_PageData["gbDrillDownInPanel"] = value; }
	}

	// sSql
	public static string sSql;

	// cntf
	public static int cntf;

	// cntd
	public static int cntd;

	// totcnt
	public static int totcnt;

	// wrkcnt
	public static int wrkcnt;

	// cntcol
	public static int cntcol;

	// CurrentTable // ASPX
	public static dynamic CurrentTable {
		get { return CurrentPage; }
		set { CurrentPage = value; }
	}	

	// Page Loading event
	public virtual void Page_Loading() {

		//ewr_Write("Page Loading");
	}

	// Page Unloaded event
	public virtual void Page_Unloaded() {

		//ewr_Write("Page Unloaded");
	}

	// Chart Rendering event
	public virtual void Chart_Rendering(crChart chart) {

		// Example:
		//ewr_VarDump(chart); // View chart info
	//	if (chart.ID == "<Report>_<Chart>") {
	//		chart.SaveParm("formatNumber", "1"); // Format number
	//		chart.SaveParm("numberSuffix", "%"); // % as suffix
	//	}

	}

	// Chart Data Rendered event
	public virtual void Chart_DataRendered(crChart chart, XmlElement node) {

		// Example:
		//ewr_VarDump(chart); // View chart info
	//	if (chart.ID == "<Report>_<Chart>") {
	//		if (node.Name == "set") { // Multiply values by 100
	//			var val = node.GetAttribute("value").AsInt() * 100;
	//			node.SetAttribute("value", val.ToString());
	//		}
	//	}

	}

	// Chart Rendered event
	public virtual void Chart_Rendered(crChart chart, ref string chartxml) {

		// Example:
		//ewr_VarDump(chart); // View chart info
	//	if (chart.ID == "<Report>_<Chart>") {
	//		var doc = chart.XmlDoc; // Get the XmlDocument object
	//		//Enter your code to manipulate the XmlDocument object here
	//		chartxml = doc.OuterXml; // Output the XML
	//	}

	}
}
