using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	// CanalDenuncias
//	public static dynamic CanalDenuncias {
//		get { return (dynamic)ewr_PageData["CanalDenuncias"]; }
//		set { ewr_PageData["CanalDenuncias"] = value; }
//	}
	//
	// Table class for CanalDenuncias
	//
	public class crCanalDenuncias : crTableBase {

		public crField id;

		public crField rut;

		public crField nombre;

		public crField apellido_P;

		public crField apellido_M;

		public crField _EMAIL;

		public crField DIRECCION;

		public crField COMUNA;

		public crField CIUDAD;

		public crField TelefonoContacto;

		public crField TipoDelito;

		public crField detalle;

		public crField adjunto;

		public crField ip;

		public crField fecha;

		public crField tipoUsuario;

		//
		// Table class constructor
		//
		public crCanalDenuncias() {

			// Language object
			if (ReportLanguage == null)
				ReportLanguage = new crLanguage();			
			TableVar = "CanalDenuncias";
			TableName = "CanalDenuncias";
			TableType = "REPORT";
			ExportAll = true;
			ExportPageBreakCount = 0;

			// id
			id = new crField("CanalDenuncias", "CanalDenuncias", "x_id", "id", "[id]", 131, EWR_DATATYPE_NUMBER, -1);
			id.FldDefaultErrMsg = ReportLanguage.Phrase("IncorrectFloat");
			Fields.Add("id", id);
			id.DateFilter = "";
			id.SqlSelect = "";
			id.SqlOrderBy = "";

			// rut
			rut = new crField("CanalDenuncias", "CanalDenuncias", "x_rut", "rut", "[rut]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("rut", rut);
			rut.DateFilter = "";
			rut.SqlSelect = "";
			rut.SqlOrderBy = "";

			// nombre
			nombre = new crField("CanalDenuncias", "CanalDenuncias", "x_nombre", "nombre", "[nombre]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("nombre", nombre);
			nombre.DateFilter = "";
			nombre.SqlSelect = "";
			nombre.SqlOrderBy = "";

			// apellido_P
			apellido_P = new crField("CanalDenuncias", "CanalDenuncias", "x_apellido_P", "apellido_P", "[apellido_P]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("apellido_P", apellido_P);
			apellido_P.DateFilter = "";
			apellido_P.SqlSelect = "";
			apellido_P.SqlOrderBy = "";

			// apellido_M
			apellido_M = new crField("CanalDenuncias", "CanalDenuncias", "x_apellido_M", "apellido_M", "[apellido_M]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("apellido_M", apellido_M);
			apellido_M.DateFilter = "";
			apellido_M.SqlSelect = "";
			apellido_M.SqlOrderBy = "";

			// EMAIL
			_EMAIL = new crField("CanalDenuncias", "CanalDenuncias", "x__EMAIL", "EMAIL", "[EMAIL]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("_EMAIL", _EMAIL);
			_EMAIL.DateFilter = "";
			_EMAIL.SqlSelect = "";
			_EMAIL.SqlOrderBy = "";

			// DIRECCION
			DIRECCION = new crField("CanalDenuncias", "CanalDenuncias", "x_DIRECCION", "DIRECCION", "[DIRECCION]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("DIRECCION", DIRECCION);
			DIRECCION.DateFilter = "";
			DIRECCION.SqlSelect = "";
			DIRECCION.SqlOrderBy = "";

			// COMUNA
			COMUNA = new crField("CanalDenuncias", "CanalDenuncias", "x_COMUNA", "COMUNA", "[COMUNA]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("COMUNA", COMUNA);
			COMUNA.DateFilter = "";
			COMUNA.SqlSelect = "";
			COMUNA.SqlOrderBy = "";

			// CIUDAD
			CIUDAD = new crField("CanalDenuncias", "CanalDenuncias", "x_CIUDAD", "CIUDAD", "[CIUDAD]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("CIUDAD", CIUDAD);
			CIUDAD.DateFilter = "";
			CIUDAD.SqlSelect = "";
			CIUDAD.SqlOrderBy = "";

			// TelefonoContacto
			TelefonoContacto = new crField("CanalDenuncias", "CanalDenuncias", "x_TelefonoContacto", "TelefonoContacto", "[TelefonoContacto]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("TelefonoContacto", TelefonoContacto);
			TelefonoContacto.DateFilter = "";
			TelefonoContacto.SqlSelect = "";
			TelefonoContacto.SqlOrderBy = "";

			// TipoDelito
			TipoDelito = new crField("CanalDenuncias", "CanalDenuncias", "x_TipoDelito", "TipoDelito", "[TipoDelito]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("TipoDelito", TipoDelito);
			TipoDelito.DateFilter = "";
			TipoDelito.SqlSelect = "";
			TipoDelito.SqlOrderBy = "";

			// detalle
			detalle = new crField("CanalDenuncias", "CanalDenuncias", "x_detalle", "detalle", "[detalle]", 201, EWR_DATATYPE_MEMO, -1);
			Fields.Add("detalle", detalle);
			detalle.DateFilter = "";
			detalle.SqlSelect = "";
			detalle.SqlOrderBy = "";

			// adjunto
			adjunto = new crField("CanalDenuncias", "CanalDenuncias", "x_adjunto", "adjunto", "[adjunto]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("adjunto", adjunto);
			adjunto.DateFilter = "";
			adjunto.SqlSelect = "";
			adjunto.SqlOrderBy = "";

			// ip
			ip = new crField("CanalDenuncias", "CanalDenuncias", "x_ip", "ip", "[ip]", 200, EWR_DATATYPE_STRING, -1);
			Fields.Add("ip", ip);
			ip.DateFilter = "";
			ip.SqlSelect = "";
			ip.SqlOrderBy = "";

			// fecha
			fecha = new crField("CanalDenuncias", "CanalDenuncias", "x_fecha", "fecha", "[fecha]", 135, EWR_DATATYPE_DATE, 7);
			fecha.FldDefaultErrMsg = ReportLanguage.Phrase("IncorrectDateDMY").Replace("%s", "/");
			Fields.Add("fecha", fecha);
			fecha.DateFilter = "";
			fecha.SqlSelect = "";
			fecha.SqlOrderBy = "";

			// tipoUsuario
			tipoUsuario = new crField("CanalDenuncias", "CanalDenuncias", "x_tipoUsuario", "tipoUsuario", "[tipoUsuario]", 130, EWR_DATATYPE_STRING, -1);
			Fields.Add("tipoUsuario", tipoUsuario);
			tipoUsuario.DateFilter = "";
			tipoUsuario.SqlSelect = "";
			tipoUsuario.SqlOrderBy = "";
		}

		// Invoke method of table class and subclasses // AXR
		public object Invoke(string name, object[] parameters = null) {
			MethodInfo mi = this.GetType().GetMethod(name);
			if (mi != null)
				return mi.Invoke(this, parameters);
			return null;
		}

		// Get custom property value // AXR
		public object GetCustomValue(string PropName, string FldName = "") {
			string name = "Get_";
			if (FldName != "")
				name += FldName + "_";
			name += PropName;			
			return Invoke(name);
		}		

		// Single column sort
		public void UpdateSort(crField ofld) {
			if (CurrentOrder == ofld.FldName) {
				var sLastSort = ofld.Sort;
				var sThisSort = "";
				if (CurrentOrderType == "ASC" || CurrentOrderType == "DESC") {
					sThisSort = CurrentOrderType;
				} else {
					sThisSort = (sLastSort == "ASC") ? "DESC" : "ASC";
				}
				ofld.Sort = sThisSort;
			} else {
				if (ofld.GroupingFieldId == 0) ofld.Sort = "";
			}
		}

		// Get Sort SQL
		public string SortSql() {
			string sDtlSortSql = "";
			List<string> argrps = new List<string>();
			foreach (var field in Fields) {
				crField fld = field.Value;
				if (ewr_NotEmpty(fld.Sort)) {
					if (fld.GroupingFieldId > 0) {
						if (ewr_NotEmpty(fld.FldGroupSql))
							argrps.Add(fld.FldGroupSql.Replace("%s", fld.FldExpression) + " " + fld.Sort);
						else
							argrps.Add(fld.FldExpression + " " + fld.Sort);
					} else {
						if (ewr_NotEmpty(sDtlSortSql)) sDtlSortSql += ", ";
						sDtlSortSql += fld.FldExpression + " " + fld.Sort;
					}
				}
			}
			string sSortSql = "";
			foreach (string grp in argrps) {
				if (ewr_NotEmpty(sSortSql)) sSortSql += ", ";
				sSortSql += grp;
			}
			if (ewr_NotEmpty(sDtlSortSql)) {
				if (ewr_NotEmpty(sSortSql)) sSortSql += ", ";
				sSortSql += sDtlSortSql;
			}
			return sSortSql;
		}

		// Table level SQL
		public string SqlFrom { // From
			get {return "[SEK_CanalDenuncias]";}
		}

		public string SqlSelect { // Select
			get {return "SELECT * FROM " + SqlFrom;}
		}

		public string SqlWhere { // Where
			get {
				string sWhere = "";
				return sWhere;
			}
		}

		public string SqlGroupBy { // Group By
			get {return "";}
		}

		public string SqlHaving { // Having
			get {return "";}
		}

		public string SqlOrderBy { // Order By
			get {return "";}
		}

		// Table Level Group SQL
		public string SqlFirstGroupField {
			get {return "";}
		}

		public string SqlSelectGroup {
			get {return "SELECT DISTINCT " + SqlFirstGroupField + " FROM " + SqlFrom;}
		}

		public string SqlOrderByGroup {
			get {return "";}
		}

		public string SqlSelectAgg {
			get {return "SELECT * FROM " + SqlFrom;}
		}

		public string SqlAggPfx {
			get {return "";}
		}

		public string SqlAggSfx {
			get {return "";}
		}

		public string SqlSelectCount {
			get {return "SELECT COUNT(*) FROM " + SqlFrom;}
		}

		// Sort URL
		public string SortUrl(crField fld) {
			return "";
		}

		// Table level events
		// Page Selecting event
		public virtual void Page_Selecting(ref string filter) {

			// Enter your code here	
		}

		// Page Breaking event
		public virtual void Page_Breaking(ref bool brk, ref string content) {

			// Example:
		//	brk = false; // Skip page break, or
		//	content = "<div style=\"page-break-after:always;\">&nbsp;</div>"; // Modify page break content

		}

		// Row Rendering event
		public virtual void Row_Rendering() {

			// Enter your code here	
		}

		// Cell Rendered event
		public virtual void Cell_Rendered(crField Field, object CurrentValue, ref string ViewValue, Dictionary<string, string> ViewAttrs, Dictionary<string, string> CellAttrs, ref string HrefValue, Dictionary<string, string> LinkAttrs) {

			//ViewValue = "xxx";
			//ViewAttrs["style"] = "xxx";

		}

		// Row Rendered event
		public virtual void Row_Rendered() {

			// To view properties of field class, use:
			//ewr_VarDump(<FieldName>); 

		}

		// User ID Filtering event
		public virtual void UserID_Filtering(ref string filter) {

			// Enter your code here
		}

		// Load Filters event
		public virtual void Page_FilterLoad() {

			// Enter your code here
			// Example: Register/Unregister Custom Extended Filter
		//	ewr_RegisterFilter(<Field>, "StartsWithA", "Starts With A", "GetStartsWithAFilter"); // With function, or
		//	ewr_RegisterFilter(<Field>, "StartsWithA", "Starts With A"); // No function, use Page_Filtering event
		//	ewr_UnregisterFilter(<Field>, "StartsWithA");

		}

		// Page Filter Validated event
		public virtual void Page_FilterValidated() {

			// Example:
			//MyField1.SearchValue = "your search criteria"; // Search value

		}

		// Page Filtering event
		public virtual void Page_Filtering(crField fld, ref string filter, string typ, string opr, string val, string cond, string opr2, string val2) {

			// Note: ALWAYS CHECK THE FILTER TYPE (typ)! Example:
		//	if (typ == "dropdown" && fld.FldName == "MyField") // Dropdown filter
		//		filter = "..."; // Modify the filter
		//	if (typ == "extended" && fld.FldName == "MyField") // Extended filter
		//		filter = "..."; // Modify the filter
		//	if (typ == "popup" && fld.FldName == "MyField") // Popup filter
		//		filter = "..."; // Modify the filter
		//	if (typ == "custom" && opr == "..." && fld.FldName == "MyField") // Custom filter, opr is the custom filter ID
		//		filter = "..."; // Modify the filter

		}

		// Email Sending event
		public virtual bool Email_Sending(crEmail Email, dynamic Args) {

			//ewr_End(Email); // View Email object info
			return true;
		}
	}

	// CanalDenuncias_summary
	public static dynamic CanalDenuncias_summary {
		get { return (dynamic)ewr_PageData["CanalDenuncias_summary"]; }
		set { ewr_PageData["CanalDenuncias_summary"] = value; }
	}

	//
	// Page class
	//
	public class crCanalDenuncias_summary_base<C, S> : crCanalDenuncias
		where C : cConnectionBase, new()
		where S : cAdvancedSecurityBase, new()
	{

		// Page ID
		public string PageID = "summary";

		// Project ID
		public string ProjectID = "{5E252714-15AD-4FF5-8F78-DA7E4D955D0D}";

		// Table name
		public string TableName = "CanalDenuncias";

		// Page object name
		public string PageObjName = "CanalDenuncias_summary";

		// Page name
		public string PageName {
			get { return ewr_CurrentPage(); }
		}

		// Page URL
		public string PageUrl {
			get {
				string PageUrl = ewr_CurrentPage() + "?";
				return PageUrl;
			}
		}

		// Export URLs
		public string ExportPrintUrl = "";

		public string ExportExcelUrl = "";

		public string ExportWordUrl = "";

		public string ExportPdfUrl = "";

		public string ReportTableClass = "";

		// Message
		public string Message {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_MESSAGE] = msg;
			}
		}

		// Failure Message
		public string FailureMessage {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_FAILURE_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_FAILURE_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_FAILURE_MESSAGE] = msg;
			}
		}

		// Success Message
		public string SuccessMessage {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_SUCCESS_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_SUCCESS_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_SUCCESS_MESSAGE] = msg;
			}
		}

		// Warning Message
		public string WarningMessage {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_WARNING_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_WARNING_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_WARNING_MESSAGE] = msg;
			}
		}

		// Show message
		public void ShowMessage() {
			bool hidden = false;
			string html = "";

			// Message
			string sMessage = Message;
			Message_Showing(ref sMessage, "");
			if (ewr_NotEmpty(sMessage)) { // Message in Session, display
				html += "<p class=\"ewMessage\">" + sMessage + "</p>";
				ewr_Session[EWR_SESSION_MESSAGE] = ""; // Clear message in Session
			}

			// Warning message
			string sWarningMessage = WarningMessage;
			Message_Showing(ref sWarningMessage, "warning");
			if (ewr_NotEmpty(sWarningMessage)) { // Message in Session, display
				html += "<table class=\"ewMessageTable\"><tr><td class=\"ewWarningIcon\"></td><td class=\"ewWarningMessage\">" + sWarningMessage + "</td></tr></table>";
				ewr_Session[EWR_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
			}

			// Success message
			string sSuccessMessage = SuccessMessage;
			Message_Showing(ref sSuccessMessage, "success");
			if (ewr_NotEmpty(sSuccessMessage)) { // Message in Session, display
				html += "<table class=\"ewMessageTable\"><tr><td class=\"ewSuccessIcon\"></td><td class=\"ewSuccessMessage\">" + sSuccessMessage + "</td></tr></table>";
				ewr_Session[EWR_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
			}

			// Failure message
			string sErrorMessage = FailureMessage;
			Message_Showing(ref sErrorMessage, "failure");
			if (ewr_NotEmpty(sErrorMessage)) { // Message in Session, display
				html += "<table class=\"ewMessageTable\"><tr><td class=\"ewErrorIcon\"></td><td class=\"ewErrorMessage\">" + sErrorMessage + "</td></tr></table>";
				ewr_Session[EWR_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
			}		
			ewr_Write("<div class=\"ewMessageDialog\"" + ((hidden) ? " style=\"display: none;\"" : "") + ">" + html + "</div>");
		}

		public string PageHeader = "";

		public string PageFooter = "";

		// Show Page Header
		public void ShowPageHeader() {
			string sHeader = PageHeader;
			Page_DataRendering(ref sHeader);
			if (ewr_NotEmpty(sHeader)) // Header exists, display
				ewr_Write("<p class=\"aspnetreportmaker\">" + sHeader + "</p>");
		}

		// Show Page Footer
		public void ShowPageFooter() {
			string sFooter = PageFooter;
			Page_DataRendered(ref sFooter);
			if (ewr_NotEmpty(sFooter)) // Fotoer exists, display
				ewr_Write("<p class=\"aspnetreportmaker\">" + sFooter + "</p>");
		}

		// Validate page request
		public bool IsPageRequest {
			get {
				return true;
			}
		}

		//
		// Page class constructor
		//
		public crCanalDenuncias_summary_base() {	

			// User agent
			UserAgent = ewr_UserAgent();
			CurrentPage = this;

			// Language object
			if (ReportLanguage == null)
				ReportLanguage = new crLanguage();	

			// Table object (CanalDenuncias)
			//CanalDenuncias = this;
			// Initialize URLs

			ExportPrintUrl = PageUrl + "export=print";
			ExportExcelUrl = PageUrl + "export=excel";
			ExportWordUrl = PageUrl + "export=word";
			ExportPdfUrl = PageUrl + "export=pdf";

			// Start time
			StartTime = Environment.TickCount;

			// Open connection
			if (Conn == null)
				Conn = new C();

			// Export options
			ExportOptions = new crListOptions();
			ExportOptions.Tag = "span";
			ExportOptions.TagClassName = "ewExportOption";
		}

		// 
		//  Page_Init
		//
		public void Page_Init() {

			// Get export parameters
			if (ewr_NotEmpty(ewr_Get("export"))) {
				Export = ewr_Get("export");
			} else if (IsPost) {
				if (ewr_NotEmpty(ewr_Post("export")))
					Export = ewr_Post("export");
			}
			gsExport = Export; // Get export parameter, used in header
			gsExportFile = TableVar; // Get export file, used in header
			giChartCnt = 0; // Get chart count, used in header // AXR

			// Setup export options
			SetupExportOptions();

			// Global Page Loading event (in userfn*.cs)
			ewr_WebPage.Page_Loading();

			// Page Load event
			Page_Load();
		}

		// Set up export options
		public void SetupExportOptions() {

			// Printer friendly
			var item = ExportOptions.Add("print");
			item.Body = "<a href=\"" + ExportPrintUrl + "\">" + ReportLanguage.Phrase("PrinterFriendly") + "</a>";
			item.Visible = false;

			// Export to Excel
			item = ExportOptions.Add("excel");
			item.Body = "<a href=\"" + ExportExcelUrl + "\">" + ReportLanguage.Phrase("ExportToExcel") + "</a>";
			item.Visible = true; // AXR

			// Export to Word
			item = ExportOptions.Add("word");
			item.Body = "<a href=\"" + ExportWordUrl + "\">" + ReportLanguage.Phrase("ExportToWord") + "</a>";
			item.Visible = false;

			// Export to Pdf
			item = ExportOptions.Add("pdf");
			item.Body = "<a href=\"" + ExportPdfUrl + "\">" + ReportLanguage.Phrase("ExportToPDF") + "</a>";
			item.Visible = false;

			// Export to Email
			item = ExportOptions.Add("email");
			var exportid = ewr_Session.SessionID;
			var url = PageUrl; // + "export=email";	// AXR		
			item.Body = "<a id=\"emf_CanalDenuncias\" href=\"javascript:void(0);\" onclick=\"ewr_EmailDialogShow({lnk:'emf_CanalDenuncias',hdr:ewLanguage.Phrase('ExportToEmail'),url:'" + url + "',exportid:'" + exportid + "',el:this});\">" + ReportLanguage.Phrase("ExportToEmail") + "</a>";
			item.Visible = false;

			// Reset filter
			item = ExportOptions.Add("resetfilter");
			item.Body = "<a href=\"" + ewr_CurrentPage() + "?cmd=reset\">" + ReportLanguage.Phrase("ResetAllFilter") + "</a>";
			item.Visible = true;
			SetupExportOptionsExt();

			// Hide options for export
			if (ewr_NotEmpty(Export))
				ExportOptions.HideAllOptions();

			// Set up table class
			if (Export == "word" || Export == "excel" || Export == "pdf")
				ReportTableClass = "ewTable";
			else
				ReportTableClass = "ewTable ewTableSeparate";
		}

		//
		// Page_Terminate
		//
		public void Page_Terminate(string url = "") {

			// Page Unload event
			Page_Unload();

			// Global Page Unloaded event (in userfn*.cs)
			ewr_WebPage.Page_Unloaded();

			// Export
			if (ewr_NotEmpty(Export) && EWR_EXPORT.ContainsKey(Export)) {
				var html = ewr_WebPage.RenderPage("_header.vbhtml").ToString() +
					ewr_WebPage.Output.ToString() +
					ewr_WebPage.RenderPage("_footer.vbhtml").ToString(); 
				Invoke(EWR_EXPORT[Export], new object[] { html });
				if (Export == "email") { // Email
					ewr_Response.Clear();
					if (Conn != null) // Close connection
						Conn.Close();
					ewr_Response.Redirect(ewr_MapPath(ewr_CurrentPage(), false)); // ASPX
				}
			}

			// Close connection
			if (Conn != null)
				Conn.Close();

			// Gargage collection // ASPX
			ewr_GCollect();

			// Go to URL if specified
			if (ewr_NotEmpty(url)) {
				if (EWR_DEBUG_ENABLED)
					ewr_Response.Clear();
				ewr_Response.Redirect(ewr_MapPath(url, false)); // ASPX
			}

			//ewr_End();
		}

		// Temp variables
		public ewDataReader dr; // DataReader

		public List<OrderedDictionary> rs;

		public List<OrderedDictionary> rsgrp;

		public bool HasRow;

		public int GrpIndex = 0;

		public int RowIndex = 0;

		// Initialize common variables
		public crListOptions ExportOptions; // Export options

		// Paging variables
		public int RecCount = 0; // Record count

		public int StartGrp = 0; // Start group

		public int StopGrp = 0; // Stop group

		public int TotalGrps = 0; // Total groups

		public int GrpCount = 0; // Group count

		public int DisplayGrps = 15; // Groups per page

		public int GrpRange = 10;

		public dynamic Pager; // AXR

		public string Sort = "";

		public string Filter = "";

		public string PageFirstGroupFilter = "";

		public string UserIDFilter = "";

		public bool DrillDown = false;

		public bool DrillDownInPanel = false;

		public string DrillDownList = "";		

		// Clear field for ext filter
		public string ClearExtFilter = "";

		public string PopupName = "";

		public object PopupValue = "";		

		public bool FilterApplied;

		public bool SearchCommand = false;

		public bool ShowHeader;

		public int GrpFldCount = 0;

		public int SubGrpFldCount = 0;

		public int DtlFldCount = 0;

		public object[] Val = new object[16];

		public int[][] Cnt = new int[1][];

		public object[][] Smry = new object[1][];

		public object[][] Mn = new object[1][];

		public object[][] Mx = new object[1][];

		public int[] GrandCnt = new int[16];

		public object[] GrandSmry = new object[16];

		public object[] GrandMn = new object[16];

		public object[] GrandMx = new object[16];

		public bool[][] Col = new bool[16][];

		public int TotCount;

		public bool GrandSummarySetup = false;

		//
		// Page main
		//
		public void Page_Main() {

			// Aggregate variables		
			int nDtls = 16; // No. of fields
			int nGrps = 1; // No. of groups (level 0 used for grand total)
			for (int i = 0; i < nGrps; i++) {
				Cnt[i] = new int[nDtls];
				Smry[i] = new object[nDtls];
				Mn[i] = new object[nDtls];
				Mx[i] = new object[nDtls]; 
			}

			// Set up if accumulation required ({{Accum, SkipNullOrZero}, ...}) // AXR
			Col[0] = new bool[] {false, false}; // First column not used
			Col[1] = new bool[] {false, false};
			Col[2] = new bool[] {false, false};
			Col[3] = new bool[] {false, false};
			Col[4] = new bool[] {false, false};
			Col[5] = new bool[] {false, false};
			Col[6] = new bool[] {false, false};
			Col[7] = new bool[] {false, false};
			Col[8] = new bool[] {false, false};
			Col[9] = new bool[] {false, false};
			Col[10] = new bool[] {false, false};
			Col[11] = new bool[] {false, false};
			Col[12] = new bool[] {false, false};
			Col[13] = new bool[] {false, false};
			Col[14] = new bool[] {false, false};
			Col[15] = new bool[] {false, false};

			// Set up groups per page dynamically
			SetUpDisplayGrps();

			// Check if search command
			SearchCommand = (ewr_Get("cmd") == "search");

			// Load default filter values
			LoadDefaultFilters();

			// Load custom filters
			Page_FilterLoad();

			// Set up popup filter
			SetupPopup();

			// Load group db values if necessary
			LoadGroupDbValues();

			// Handle Ajax popup
			ProcessAjaxPopup();

			// Extended filter
			string sExtendedFilter = "";

			// Build extended filter
			sExtendedFilter = GetExtendedFilter();
			ewr_AddFilter(ref Filter, sExtendedFilter);

			// Build popup filter
			string sPopupFilter = GetPopupFilter();
			ewr_AddFilter(ref Filter, sPopupFilter);

			// Check if filter applied
			FilterApplied = CheckFilter();

			// Call Page Selecting event
			Page_Selecting(ref Filter);
			ExportOptions.GetItem("resetfilter").Visible = FilterApplied;

			// Get sort
			Sort = GetSort();

			// Get total count
			string sSql = ewr_BuildReportSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, SqlOrderBy, Filter, Sort);
			TotalGrps = GetCnt(sSql);
			if (DisplayGrps <= 0 || DrillDown) // Display all groups
				DisplayGrps = TotalGrps;
			StartGrp = 1;

			// Show header
			ShowHeader = (TotalGrps > 0);

			// Set up start position if not export all
			if (ExportAll && ewr_NotEmpty(Export))
			    DisplayGrps = TotalGrps;
			else
				SetUpStartGroup(); 

			// Hide all options if export
			if (ewr_NotEmpty(Export))
				ExportOptions.HideAllOptions();

			// Get current page records
			dr = GetRs(sSql, StartGrp, DisplayGrps);
			SetupFieldCount();
		}

		// Accummulate summary
		public void AccumulateSummary() {
			int cntx = Smry.Length;
			for (int ix = 0; ix < cntx; ix++) {
				int cnty = Smry[ix].Length;
				for (int iy = 1; iy < cnty; iy++) {					
					if (Col[iy][0]) { // Accumulate required
						object valwrk = Val[iy];
						if (Convert.IsDBNull(valwrk) || !ewr_IsNumeric(valwrk)) {
							if (Col[iy][1])
								Cnt[ix][iy]++;
						} else {
							if (!Col[iy][1] || Convert.ToDouble(valwrk) != 0) { 
								Cnt[ix][iy]++;
								Smry[ix][iy] = Convert.ToDouble(Smry[ix][iy]) + Convert.ToDouble(valwrk);
								if (Mn[ix][iy] == null) {
									Mn[ix][iy] = valwrk;
									Mx[ix][iy] = valwrk;
								} else {
									if (Convert.ToDouble(Mn[ix][iy]) > Convert.ToDouble(valwrk)) Mn[ix][iy] = valwrk;
									if (Convert.ToDouble(Mx[ix][iy]) < Convert.ToDouble(valwrk)) Mx[ix][iy] = valwrk;
								}
							}
						}
					}
				}
				Cnt[ix][0]++; // AXR
			}
		}

		// Reset level summary
		public void ResetLevelSummary(int lvl) {
			int cntx = Smry.Length;
			for (int ix = lvl; ix < cntx; ix++) {
				int cnty = Smry[ix].Length;
				for (int iy = 1; iy < cnty; iy++) {
					Cnt[ix][iy] = 0;
					if (Col[iy][0]) {
						Smry[ix][iy] = 0;
						Mn[ix][iy] = null;
						Mx[ix][iy] = null;
					}
				}
			}
			cntx = Smry.Length;
			for (int ix = lvl; ix < cntx; ix++)
				Cnt[ix][0] = 0;

			// Reset record count
			RecCount = 0;
		}

		// Accummulate grand summary
		public void AccumulateGrandSummary() { 
			TotCount++;
			int cntgs = GrandSmry.Length;
			for (int iy = 1; iy < cntgs; iy++) {
				if (Col[iy][0]) {
					object valwrk = Val[iy];
					if (Convert.IsDBNull(valwrk) || !ewr_IsNumeric(valwrk)) {
						if (!Col[iy][1])
							GrandCnt[iy]++;
					} else {
						if (!Col[iy][1] || Convert.ToDouble(valwrk) != 0) {
							GrandCnt[iy]++;
							GrandSmry[iy] = Convert.ToDouble(GrandSmry[iy]) + Convert.ToDouble(valwrk);
							if (ewr_Empty(GrandMn[iy])) {
								GrandMn[iy] = valwrk;
								GrandMx[iy] = valwrk;
							} else {
								if (Convert.ToDouble(GrandMn[iy]) > Convert.ToDouble(valwrk)) GrandMn[iy] = valwrk;
								if (Convert.ToDouble(GrandMx[iy]) < Convert.ToDouble(valwrk)) GrandMx[iy] = valwrk;
							}
						}
					}
				}
			}
		}

		// Get count
		public int GetCnt(string sql) {		
			try {
				object cnt = Conn.ExecuteScalar("SELECT COUNT(*) FROM (" + sql + ") AS EWR_TEMP_TABLE");
				if (cnt != null) {
					return ewr_ConvertToInt(cnt);
				} else {
					throw new Exception("Failed to get record count");
				}	
			} catch {
				using (var dr = Conn.OpenDataReader(sql)) {
					int rscnt = 0;
					if (dr != null && dr.HasRows) {
						while (dr.Read())
							rscnt++;
					}
					return rscnt;
				}				
			}
		}

		// Get rs
		public ewDataReader GetRs(string sql, int start, int grps) {	
			GrpIndex = -1;
			var dr = Conn.GetDataReader(sql);		
			for (int i = 1; i < start; i++) {
				HasRow = dr.Read();
				GrpIndex++;
				if (!HasRow)
					break;
			}				
			return dr;			
		}	

		// Get row values
		public void GetRow(int opt) {
			if (rs == null || RowIndex >= rs.Count)
				return;
			RowIndex = (opt == 1) ? 0 : RowIndex + 1;
			if (RowIndex < rs.Count) {
				var row = rs[RowIndex];
				id.DbValue = row["id"];
				rut.DbValue = row["rut"];
				nombre.DbValue = row["nombre"];
				apellido_P.DbValue = row["apellido_P"];
				apellido_M.DbValue = row["apellido_M"];
				_EMAIL.DbValue = row["EMAIL"];
				DIRECCION.DbValue = row["DIRECCION"];
				COMUNA.DbValue = row["COMUNA"];
				CIUDAD.DbValue = row["CIUDAD"];
				TelefonoContacto.DbValue = row["TelefonoContacto"];
				TipoDelito.DbValue = row["TipoDelito"];
				detalle.DbValue = row["detalle"];
				adjunto.DbValue = row["adjunto"];
				ip.DbValue = row["ip"];
				fecha.DbValue = row["fecha"];
				tipoUsuario.DbValue = row["tipoUsuario"];
				Val[1] = rut.CurrentValue;
				Val[2] = nombre.CurrentValue;
				Val[3] = apellido_P.CurrentValue;
				Val[4] = apellido_M.CurrentValue;
				Val[5] = _EMAIL.CurrentValue;
				Val[6] = DIRECCION.CurrentValue;
				Val[7] = COMUNA.CurrentValue;
				Val[8] = CIUDAD.CurrentValue;
				Val[9] = TelefonoContacto.CurrentValue;
				Val[10] = TipoDelito.CurrentValue;
				Val[11] = detalle.CurrentValue;
				Val[12] = adjunto.CurrentValue;
				Val[13] = ip.CurrentValue;
				Val[14] = fecha.CurrentValue;
				Val[15] = tipoUsuario.CurrentValue;
			} else {
				id.DbValue = "";
				rut.DbValue = "";
				nombre.DbValue = "";
				apellido_P.DbValue = "";
				apellido_M.DbValue = "";
				_EMAIL.DbValue = "";
				DIRECCION.DbValue = "";
				COMUNA.DbValue = "";
				CIUDAD.DbValue = "";
				TelefonoContacto.DbValue = "";
				TipoDelito.DbValue = "";
				detalle.DbValue = "";
				adjunto.DbValue = "";
				ip.DbValue = "";
				fecha.DbValue = "";
				tipoUsuario.DbValue = "";
			}
		}

		// Get row values from data reader // AXR
		public bool GetRow() {
			HasRow = (dr != null && dr.Read()); 
			if (HasRow) {
				GrpIndex++;			
				id.DbValue = dr["id"];
				rut.DbValue = dr["rut"];
				nombre.DbValue = dr["nombre"];
				apellido_P.DbValue = dr["apellido_P"];
				apellido_M.DbValue = dr["apellido_M"];
				_EMAIL.DbValue = dr["EMAIL"];
				DIRECCION.DbValue = dr["DIRECCION"];
				COMUNA.DbValue = dr["COMUNA"];
				CIUDAD.DbValue = dr["CIUDAD"];
				TelefonoContacto.DbValue = dr["TelefonoContacto"];
				TipoDelito.DbValue = dr["TipoDelito"];
				detalle.DbValue = dr["detalle"];
				adjunto.DbValue = dr["adjunto"];
				ip.DbValue = dr["ip"];
				fecha.DbValue = dr["fecha"];
				tipoUsuario.DbValue = dr["tipoUsuario"];
				Val[1] = rut.CurrentValue;
				Val[2] = nombre.CurrentValue;
				Val[3] = apellido_P.CurrentValue;
				Val[4] = apellido_M.CurrentValue;
				Val[5] = _EMAIL.CurrentValue;
				Val[6] = DIRECCION.CurrentValue;
				Val[7] = COMUNA.CurrentValue;
				Val[8] = CIUDAD.CurrentValue;
				Val[9] = TelefonoContacto.CurrentValue;
				Val[10] = TipoDelito.CurrentValue;
				Val[11] = detalle.CurrentValue;
				Val[12] = adjunto.CurrentValue;
				Val[13] = ip.CurrentValue;
				Val[14] = fecha.CurrentValue;
				Val[15] = tipoUsuario.CurrentValue;
			} else {				
				id.DbValue = "";
				rut.DbValue = "";
				nombre.DbValue = "";
				apellido_P.DbValue = "";
				apellido_M.DbValue = "";
				_EMAIL.DbValue = "";
				DIRECCION.DbValue = "";
				COMUNA.DbValue = "";
				CIUDAD.DbValue = "";
				TelefonoContacto.DbValue = "";
				TipoDelito.DbValue = "";
				detalle.DbValue = "";
				adjunto.DbValue = "";
				ip.DbValue = "";
				fecha.DbValue = "";
				tipoUsuario.DbValue = "";
			}
			return HasRow;		
		}

		//  Set up starting group
		public void SetUpStartGroup() { 

			// Exit if no groups
			if (DisplayGrps == 0) 
				return;

			// Check for a "start" parameter 
			if (ewr_NotEmpty(ewr_Get(EWR_TABLE_START_GROUP)) &&
				ewr_IsNumeric(ewr_Get(EWR_TABLE_START_GROUP))) { 
				StartGrp = ewr_ConvertToInt(ewr_Get(EWR_TABLE_START_GROUP)); 
				StartGroup = StartGrp; 
			} else if (ewr_NotEmpty(ewr_Get("pageno"))) {		
				if (ewr_IsNumeric(ewr_Get("pageno"))) {
					int nPageNo = ewr_ConvertToInt(ewr_Get("pageno"));  
					StartGrp = (nPageNo - 1) * DisplayGrps + 1; 
					if (StartGrp <= 0) { 
						StartGrp = 1; 
					} else if (StartGrp >= ((TotalGrps - 1) / DisplayGrps) * DisplayGrps + 1) { 
						StartGrp = ((TotalGrps - 1) / DisplayGrps) * DisplayGrps + 1; 
					} 
					StartGroup = StartGrp; 
				} else { 
					StartGrp = StartGroup;
				} 
			} else { 
				StartGrp = StartGroup;
			} 

			// Check if correct start group counter 
			if (StartGrp <= 0) { // Avoid invalid start group counter 
				StartGrp = 1; // Reset start group counter 
				StartGroup = StartGrp; 
			} else if (StartGrp > TotalGrps) { // Avoid starting group > total groups 
				StartGrp = ((TotalGrps - 1) / DisplayGrps) * DisplayGrps + 1; // Point to last page first group 
				StartGroup = StartGrp; 
			} else if ((StartGrp - 1) % DisplayGrps != 0) { 
				StartGrp = ((StartGrp - 1) / DisplayGrps) * DisplayGrps + 1; // Point to page boundary 
				StartGroup = StartGrp; 
			} 
		}	

		// Load group db values if necessary
		public void LoadGroupDbValues() {
		}

		// Process Ajax popup
		public void ProcessAjaxPopup() {
			crField fld = null;
			if (ewr_NotEmpty(ewr_Get("popup"))) {
				var popupname = ewr_Get("popup");

				// Check popup name
				// Output data as Json

				if (fld != null) {
					var jsdb = ewr_GetJsDb(fld, fld.FldType);
					ewr_Response.Clear();
					ewr_End(jsdb);
				}
			}
		}

		// Set up popup
		public void SetupPopup() {	
			string sSql = "";
			ewDataReader rswrk; 
			bool bNullValue;
			bool bEmptyValue;
			object grpval; 
			if (DrillDown)
				return;

			// Process post back form
			if (IsPost) {
				string sName = ewr_Post("popup"); // Get popup form name
				if (ewr_NotEmpty(sName)) {
					object arValues = new List<string>(ewr_Form.GetValues("sel_" + sName));
					int cntValues = ((List<string>)arValues).Count;
					if (cntValues > 0) {						
						if (ewr_Empty(((List<string>)arValues)[0])) // Select all
							arValues = EWR_INIT_VALUE;
						PopupName = sName;
						if (ewr_IsAdvancedFilterValue(arValues) || arValues == EWR_INIT_VALUE)
							PopupValue = arValues;
						if (!ewr_MatchedArray(arValues, ewr_Session["sel_" + sName])) {
							if (HasSessionFilterValues(sName))
								ClearExtFilter = sName; // Clear extended filter for this field
						}
						ewr_Session["sel_" + sName] = arValues;
						ewr_Session["rf_" + sName] = ewr_Post("rf_" + sName);
						ewr_Session["rt_" + sName] = ewr_Post("rt_" + sName);
						ResetPager();
					}
				}

			// Get 'reset' command
			} else if (ewr_NotEmpty(ewr_Get("cmd"))) { // Get reset cmd
				string sCmd = ewr_Get("cmd");
				if (ewr_SameText(sCmd, "reset")) {
					ResetPager();
				}
			}

			// Load selection criteria to array
		}

		// Reset pager
		public void ResetPager() {

			// Reset start position (reset command)
			StartGrp = 1;
			StartGroup = StartGrp;
		}

		// Set up number of groups displayed per page
		public void SetUpDisplayGrps() {
			string sWrk = ewr_Get(EWR_TABLE_GROUP_PER_PAGE);
			if (ewr_NotEmpty(sWrk)) {
				if (ewr_IsNumeric(sWrk)) {
					DisplayGrps = ewr_ConvertToInt(sWrk);
				} else {
					if (ewr_SameText(sWrk, "all")) { // Display all records
						DisplayGrps = -1; // All records
					} else {
						DisplayGrps = 15; // Non-numeric, load default
					}
				}
				GroupPerPage = DisplayGrps; // Save to session	

				// Reset start position (reset command)
				StartGrp = 1;
				StartGroup = StartGrp;
			} else {
				if (GroupPerPage >= -1) { // AXR
					DisplayGrps = GroupPerPage; // Restore from session
				} else {
					DisplayGrps = 15; // Load default
				}
			}
		}

		// Render row
		public void RenderRow() {
			if (RowTotalType == EWR_ROWTOTAL_GRAND && !GrandSummarySetup) { // Grand total
				var bGotCount = false;
				var bGotSummary = false;

				// Get total count from SQL directly
				string sSql = ewr_BuildReportSql(SqlSelectCount, SqlWhere, SqlGroupBy, SqlHaving, "", Filter, "");

				//var rstot = Conn.GetRows(sSql);
				var tot = Conn.ExecuteScalar(sSql); // AXR
				if (tot != null) { // AXR

					//TotCount = (rstot.Count > 1) ? rstot.Count : ewr_ConvertToInt(rstot[0][0]);
					TotCount = ewr_ConvertToInt(tot);
					bGotCount = true;
				} else {
					TotCount = 0;
				}				
				bGotSummary = true;

				// Accumulate grand summary from detail records
				if (!bGotCount || !bGotSummary) {	
					sSql = ewr_BuildReportSql(SqlSelect, SqlWhere, SqlGroupBy, SqlHaving, "", Filter, "");					
					using (dr = Conn.OpenDataReader(sSql)) {
						while (GetRow()) // AXR
							AccumulateGrandSummary();
					}	
				}
				GrandSummarySetup = true; // No need to set up again
			}

			// Call Row_Rendering event
			Row_Rendering();

			//
			// Render view codes
			//

			if (RowType == EWR_ROWTYPE_TOTAL) { // Summary row

				// rut
				rut.HrefValue = "";

				// nombre
				nombre.HrefValue = "";

				// apellido_P
				apellido_P.HrefValue = "";

				// apellido_M
				apellido_M.HrefValue = "";

				// EMAIL
				_EMAIL.HrefValue = "";

				// DIRECCION
				DIRECCION.HrefValue = "";

				// COMUNA
				COMUNA.HrefValue = "";

				// CIUDAD
				CIUDAD.HrefValue = "";

				// TelefonoContacto
				TelefonoContacto.HrefValue = "";

				// TipoDelito
				TipoDelito.HrefValue = "";

				// detalle
				detalle.HrefValue = "";

				// adjunto
				adjunto.HrefValue = "";

				// ip
				ip.HrefValue = "";

				// fecha
				fecha.HrefValue = "";

				// tipoUsuario
				tipoUsuario.HrefValue = "";
			} else {

				// rut
				rut.ViewValue = Convert.ToString(rut.CurrentValue);
				rut.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				rut.CellAttrs["style"] = "text-align:center;";

				// nombre
				nombre.ViewValue = Convert.ToString(nombre.CurrentValue);
				nombre.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";

				// apellido_P
				apellido_P.ViewValue = Convert.ToString(apellido_P.CurrentValue);
				apellido_P.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				apellido_P.CellAttrs["style"] = "text-align:center;";

				// apellido_M
				apellido_M.ViewValue = Convert.ToString(apellido_M.CurrentValue);
				apellido_M.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				apellido_M.CellAttrs["style"] = "text-align:center;";

				// EMAIL
				_EMAIL.ViewValue = Convert.ToString(_EMAIL.CurrentValue);
				_EMAIL.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				_EMAIL.CellAttrs["style"] = "text-align:center;";

				// DIRECCION
				DIRECCION.ViewValue = Convert.ToString(DIRECCION.CurrentValue);
				DIRECCION.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				DIRECCION.CellAttrs["style"] = "text-align:justify;";

				// COMUNA
				COMUNA.ViewValue = Convert.ToString(COMUNA.CurrentValue);
				COMUNA.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				COMUNA.CellAttrs["style"] = "text-align:center;";

				// CIUDAD
				CIUDAD.ViewValue = Convert.ToString(CIUDAD.CurrentValue);
				CIUDAD.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				CIUDAD.CellAttrs["style"] = "text-align:center;";

				// TelefonoContacto
				TelefonoContacto.ViewValue = Convert.ToString(TelefonoContacto.CurrentValue);
				TelefonoContacto.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				TelefonoContacto.CellAttrs["style"] = "text-align:center;";

				// TipoDelito
				TipoDelito.ViewValue = Convert.ToString(TipoDelito.CurrentValue);
				TipoDelito.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				TipoDelito.CellAttrs["style"] = "text-align:justify;";

				// detalle
				detalle.ViewValue = ewr_TruncateMemo(Convert.ToString(detalle.CurrentValue), 300, detalle.TruncateMemoRemoveHtml);
				detalle.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				detalle.CellAttrs["style"] = "text-align:justify;";

				// adjunto
				adjunto.ViewValue = Convert.ToString(adjunto.CurrentValue);
				adjunto.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				adjunto.CellAttrs["style"] = "text-align:center;";

				// ip
				ip.ViewValue = Convert.ToString(ip.CurrentValue);
				ip.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				ip.CellAttrs["style"] = "text-align:center;";

				// fecha
				fecha.ViewValue = Convert.ToString(fecha.CurrentValue);
				fecha.ViewValue = ewr_FormatDateTime(fecha.ViewValue, 7);
				fecha.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				fecha.CellAttrs["style"] = "text-align:center;";

				// tipoUsuario
				tipoUsuario.ViewValue = Convert.ToString(tipoUsuario.CurrentValue);
				tipoUsuario.CellAttrs["class"] = (RecCount % 2 != 1) ? "ewTableAltRow" : "ewTableRow";
				tipoUsuario.CellAttrs["style"] = "text-align:center;";

				// rut
				rut.HrefValue = "";

				// nombre
				nombre.HrefValue = "";

				// apellido_P
				apellido_P.HrefValue = "";

				// apellido_M
				apellido_M.HrefValue = "";

				// EMAIL
				_EMAIL.HrefValue = "";

				// DIRECCION
				DIRECCION.HrefValue = "";

				// COMUNA
				COMUNA.HrefValue = "";

				// CIUDAD
				CIUDAD.HrefValue = "";

				// TelefonoContacto
				TelefonoContacto.HrefValue = "";

				// TipoDelito
				TipoDelito.HrefValue = "";

				// detalle
				detalle.HrefValue = "";

				// adjunto
				adjunto.HrefValue = "";

				// ip
				ip.HrefValue = "";

				// fecha
				fecha.HrefValue = "";

				// tipoUsuario
				tipoUsuario.HrefValue = "";
			}

			// Call Cell_Rendered event
			if (RowType == EWR_ROWTYPE_TOTAL) { // Summary row
			} else {

				// rut
				Cell_Rendered(rut, rut.CurrentValue, ref rut.ViewValue, rut.ViewAttrs, rut.CellAttrs, ref rut.HrefValue, rut.LinkAttrs);

				// nombre
				Cell_Rendered(nombre, nombre.CurrentValue, ref nombre.ViewValue, nombre.ViewAttrs, nombre.CellAttrs, ref nombre.HrefValue, nombre.LinkAttrs);

				// apellido_P
				Cell_Rendered(apellido_P, apellido_P.CurrentValue, ref apellido_P.ViewValue, apellido_P.ViewAttrs, apellido_P.CellAttrs, ref apellido_P.HrefValue, apellido_P.LinkAttrs);

				// apellido_M
				Cell_Rendered(apellido_M, apellido_M.CurrentValue, ref apellido_M.ViewValue, apellido_M.ViewAttrs, apellido_M.CellAttrs, ref apellido_M.HrefValue, apellido_M.LinkAttrs);

				// EMAIL
				Cell_Rendered(_EMAIL, _EMAIL.CurrentValue, ref _EMAIL.ViewValue, _EMAIL.ViewAttrs, _EMAIL.CellAttrs, ref _EMAIL.HrefValue, _EMAIL.LinkAttrs);

				// DIRECCION
				Cell_Rendered(DIRECCION, DIRECCION.CurrentValue, ref DIRECCION.ViewValue, DIRECCION.ViewAttrs, DIRECCION.CellAttrs, ref DIRECCION.HrefValue, DIRECCION.LinkAttrs);

				// COMUNA
				Cell_Rendered(COMUNA, COMUNA.CurrentValue, ref COMUNA.ViewValue, COMUNA.ViewAttrs, COMUNA.CellAttrs, ref COMUNA.HrefValue, COMUNA.LinkAttrs);

				// CIUDAD
				Cell_Rendered(CIUDAD, CIUDAD.CurrentValue, ref CIUDAD.ViewValue, CIUDAD.ViewAttrs, CIUDAD.CellAttrs, ref CIUDAD.HrefValue, CIUDAD.LinkAttrs);

				// TelefonoContacto
				Cell_Rendered(TelefonoContacto, TelefonoContacto.CurrentValue, ref TelefonoContacto.ViewValue, TelefonoContacto.ViewAttrs, TelefonoContacto.CellAttrs, ref TelefonoContacto.HrefValue, TelefonoContacto.LinkAttrs);

				// TipoDelito
				Cell_Rendered(TipoDelito, TipoDelito.CurrentValue, ref TipoDelito.ViewValue, TipoDelito.ViewAttrs, TipoDelito.CellAttrs, ref TipoDelito.HrefValue, TipoDelito.LinkAttrs);

				// detalle
				Cell_Rendered(detalle, detalle.CurrentValue, ref detalle.ViewValue, detalle.ViewAttrs, detalle.CellAttrs, ref detalle.HrefValue, detalle.LinkAttrs);

				// adjunto
				Cell_Rendered(adjunto, adjunto.CurrentValue, ref adjunto.ViewValue, adjunto.ViewAttrs, adjunto.CellAttrs, ref adjunto.HrefValue, adjunto.LinkAttrs);

				// ip
				Cell_Rendered(ip, ip.CurrentValue, ref ip.ViewValue, ip.ViewAttrs, ip.CellAttrs, ref ip.HrefValue, ip.LinkAttrs);

				// fecha
				Cell_Rendered(fecha, fecha.CurrentValue, ref fecha.ViewValue, fecha.ViewAttrs, fecha.CellAttrs, ref fecha.HrefValue, fecha.LinkAttrs);

				// tipoUsuario
				Cell_Rendered(tipoUsuario, tipoUsuario.CurrentValue, ref tipoUsuario.ViewValue, tipoUsuario.ViewAttrs, tipoUsuario.CellAttrs, ref tipoUsuario.HrefValue, tipoUsuario.LinkAttrs);
			}

			// Call Row_Rendered event
			Row_Rendered();
			SetupFieldCount();
		}

		// Setup field count
		public void SetupFieldCount() {
			GrpFldCount = 0;
			SubGrpFldCount = 0;
			DtlFldCount = 0;
			if (rut.Visible)
				DtlFldCount += 1;
			if (nombre.Visible)
				DtlFldCount += 1;
			if (apellido_P.Visible)
				DtlFldCount += 1;
			if (apellido_M.Visible)
				DtlFldCount += 1;
			if (_EMAIL.Visible)
				DtlFldCount += 1;
			if (DIRECCION.Visible)
				DtlFldCount += 1;
			if (COMUNA.Visible)
				DtlFldCount += 1;
			if (CIUDAD.Visible)
				DtlFldCount += 1;
			if (TelefonoContacto.Visible)
				DtlFldCount += 1;
			if (TipoDelito.Visible)
				DtlFldCount += 1;
			if (detalle.Visible)
				DtlFldCount += 1;
			if (adjunto.Visible)
				DtlFldCount += 1;
			if (ip.Visible)
				DtlFldCount += 1;
			if (fecha.Visible)
				DtlFldCount += 1;
			if (tipoUsuario.Visible)
				DtlFldCount += 1;
		}

		// Set up export options
		public void SetupExportOptionsExt() {
		}

		// Return extended filter
		public string GetExtendedFilter() {
			string sFilter = "";
			if (DrillDown)
				return "";
			var bRestoreSession = true;
			var bSetupFilter = false;

			// Reset extended filter if filter changed
			if (IsPost) {

			// Reset search command
			} else if (ewr_SameText(ewr_Get("cmd"), "reset")) { // Reset search command

				// Load default values
				SetSessionFilterValues(Convert.ToString(rut.SearchValue), rut.SearchOperator, rut.SearchCondition, Convert.ToString(rut.SearchValue2), rut.SearchOperator2, "rut"); // rut
				SetSessionFilterValues(Convert.ToString(nombre.SearchValue), nombre.SearchOperator, nombre.SearchCondition, Convert.ToString(nombre.SearchValue2), nombre.SearchOperator2, "nombre"); // nombre
				SetSessionFilterValues(Convert.ToString(apellido_P.SearchValue), apellido_P.SearchOperator, apellido_P.SearchCondition, Convert.ToString(apellido_P.SearchValue2), apellido_P.SearchOperator2, "apellido_P"); // apellido_P
				SetSessionFilterValues(Convert.ToString(apellido_M.SearchValue), apellido_M.SearchOperator, apellido_M.SearchCondition, Convert.ToString(apellido_M.SearchValue2), apellido_M.SearchOperator2, "apellido_M"); // apellido_M
				SetSessionFilterValues(Convert.ToString(_EMAIL.SearchValue), _EMAIL.SearchOperator, _EMAIL.SearchCondition, Convert.ToString(_EMAIL.SearchValue2), _EMAIL.SearchOperator2, "_EMAIL"); // EMAIL
				SetSessionFilterValues(Convert.ToString(CIUDAD.SearchValue), CIUDAD.SearchOperator, CIUDAD.SearchCondition, Convert.ToString(CIUDAD.SearchValue2), CIUDAD.SearchOperator2, "CIUDAD"); // CIUDAD
				SetSessionDropDownValue(TipoDelito.DropDownValue, "TipoDelito"); // TipoDelito
				SetSessionFilterValues(Convert.ToString(fecha.SearchValue), fecha.SearchOperator, fecha.SearchCondition, Convert.ToString(fecha.SearchValue2), fecha.SearchOperator2, "fecha"); // fecha
				SetSessionDropDownValue(tipoUsuario.DropDownValue, "tipoUsuario"); // tipoUsuario

				//bSetupFilter = true; // No need to set up, just use default
			} else {
				bRestoreSession = !SearchCommand;

				// rut
				if (GetFilterValues(rut)) {
					bSetupFilter = true;
				}

				// nombre
				if (GetFilterValues(nombre)) {
					bSetupFilter = true;
				}

				// apellido_P
				if (GetFilterValues(apellido_P)) {
					bSetupFilter = true;
				}

				// apellido_M
				if (GetFilterValues(apellido_M)) {
					bSetupFilter = true;
				}

				// EMAIL
				if (GetFilterValues(_EMAIL)) {
					bSetupFilter = true;
				}

				// CIUDAD
				if (GetFilterValues(CIUDAD)) {
					bSetupFilter = true;
				}

				// TipoDelito
				if (GetDropDownValue(ref TipoDelito.DropDownValue, "TipoDelito")) {
					bSetupFilter = true;
				} else if (TipoDelito.DropDownValue != EWR_INIT_VALUE && ewr_Session["sv_CanalDenuncias_TipoDelito"] == null) {
					bSetupFilter = true;
				}

				// fecha
				if (GetFilterValues(fecha)) {
					bSetupFilter = true;
				}

				// tipoUsuario
				if (GetDropDownValue(ref tipoUsuario.DropDownValue, "tipoUsuario")) {
					bSetupFilter = true;
				} else if (tipoUsuario.DropDownValue != EWR_INIT_VALUE && ewr_Session["sv_CanalDenuncias_tipoUsuario"] == null) {
					bSetupFilter = true;
				}
				if (!ValidateForm()) {
					FailureMessage = gsFormError;
					return sFilter;
				}
			}

			// Restore session
			if (bRestoreSession) {
				GetSessionFilterValues(rut); // rut
				GetSessionFilterValues(nombre); // nombre
				GetSessionFilterValues(apellido_P); // apellido_P
				GetSessionFilterValues(apellido_M); // apellido_M
				GetSessionFilterValues(_EMAIL); // EMAIL
				GetSessionFilterValues(CIUDAD); // CIUDAD
				GetSessionDropDownValue(TipoDelito); // TipoDelito
				GetSessionFilterValues(fecha); // fecha
				GetSessionDropDownValue(tipoUsuario); // tipoUsuario
			}

			// Call page filter validated event
			Page_FilterValidated();

			// Build SQL
			BuildExtendedFilter(rut, ref sFilter, false, true); // rut
			BuildExtendedFilter(nombre, ref sFilter, false, true); // nombre
			BuildExtendedFilter(apellido_P, ref sFilter, false, true); // apellido_P
			BuildExtendedFilter(apellido_M, ref sFilter, false, true); // apellido_M
			BuildExtendedFilter(_EMAIL, ref sFilter, false, true); // EMAIL
			BuildExtendedFilter(CIUDAD, ref sFilter, false, true); // CIUDAD
			BuildDropDownFilter(TipoDelito, ref sFilter, "", false, true); // TipoDelito
			BuildExtendedFilter(fecha, ref sFilter, false, true); // fecha
			BuildDropDownFilter(tipoUsuario, ref sFilter, "", false, true); // tipoUsuario

			// Save parms to session
			SetSessionFilterValues(Convert.ToString(rut.SearchValue), rut.SearchOperator, rut.SearchCondition, Convert.ToString(rut.SearchValue2), rut.SearchOperator2, "rut"); // rut
			SetSessionFilterValues(Convert.ToString(nombre.SearchValue), nombre.SearchOperator, nombre.SearchCondition, Convert.ToString(nombre.SearchValue2), nombre.SearchOperator2, "nombre"); // nombre
			SetSessionFilterValues(Convert.ToString(apellido_P.SearchValue), apellido_P.SearchOperator, apellido_P.SearchCondition, Convert.ToString(apellido_P.SearchValue2), apellido_P.SearchOperator2, "apellido_P"); // apellido_P
			SetSessionFilterValues(Convert.ToString(apellido_M.SearchValue), apellido_M.SearchOperator, apellido_M.SearchCondition, Convert.ToString(apellido_M.SearchValue2), apellido_M.SearchOperator2, "apellido_M"); // apellido_M
			SetSessionFilterValues(Convert.ToString(_EMAIL.SearchValue), _EMAIL.SearchOperator, _EMAIL.SearchCondition, Convert.ToString(_EMAIL.SearchValue2), _EMAIL.SearchOperator2, "_EMAIL"); // EMAIL
			SetSessionFilterValues(Convert.ToString(CIUDAD.SearchValue), CIUDAD.SearchOperator, CIUDAD.SearchCondition, Convert.ToString(CIUDAD.SearchValue2), CIUDAD.SearchOperator2, "CIUDAD"); // CIUDAD
			SetSessionDropDownValue(TipoDelito.DropDownValue, "TipoDelito"); // TipoDelito
			SetSessionFilterValues(Convert.ToString(fecha.SearchValue), fecha.SearchOperator, fecha.SearchCondition, Convert.ToString(fecha.SearchValue2), fecha.SearchOperator2, "fecha"); // fecha
			SetSessionDropDownValue(tipoUsuario.DropDownValue, "tipoUsuario"); // tipoUsuario

			// Setup filter
			string sWrk;
			if (bSetupFilter) {
			}

			// TipoDelito
			ewr_LoadDropDownList(TipoDelito.DropDownList, TipoDelito.DropDownValue);

			// tipoUsuario
			ewr_LoadDropDownList(tipoUsuario.DropDownList, tipoUsuario.DropDownValue);
			return sFilter;
		}

		// Build dropdown filter
		public void BuildDropDownFilter(crField fld, ref string FilterClause, string FldOpr, bool Default = false, bool SaveFilter = false) {
			var FldVal = (Default) ? fld.DefaultDropDownValue : fld.DropDownValue;
			var sSql = "";
			if (ewr_IsList(FldVal)) {
				var arwrk = (IEnumerable<string>)FldVal;
				foreach (var val in arwrk) {
					var sWrk = GetDropDownFilter(fld, val, FldOpr);

					// Call Page Filtering event
					if (!val.StartsWith("@@"))
						Page_Filtering(fld, ref sWrk, "dropdown", FldOpr, val, "", "", "");
					if (ewr_NotEmpty(sWrk)) {
						if (ewr_NotEmpty(sSql))
							sSql += " OR " + sWrk;
						else
							sSql = sWrk;
					}
				}
			} else {
				var val = Convert.ToString(FldVal);
				sSql = GetDropDownFilter(fld, val, FldOpr);

				// Call Page Filtering event
				if (!val.StartsWith("@@"))
					Page_Filtering(fld, ref sSql, "dropdown", FldOpr, val, "", "", "");
			}
			if (ewr_NotEmpty(sSql)) {
				ewr_AddFilter(ref FilterClause, sSql);
				if (SaveFilter)
					fld.CurrentFilter = sSql;
			}
		}

		// Get dropdown filter 
		public string GetDropDownFilter(crField fld, string FldVal, string FldOpr) {
			string FldName = fld.FldName;
			string FldExpression = fld.FldExpression;
			int FldDataType = fld.FldDataType;
			string FldDelimiter = fld.FldDelimiter;
			string sWrk = ""; 
			if (FldVal == EWR_NULL_VALUE) { 
				sWrk = FldExpression + " IS NULL";
			} else if (FldVal == EWR_NOT_NULL_VALUE) {
				sWrk = FldExpression + " IS NOT NULL"; 
			} else if (FldVal == EWR_EMPTY_VALUE) { 
				sWrk = FldExpression + " = ''";
			} else if (FldVal == EWR_ALL_VALUE) {
				sWrk = "1 = 1"; 
			} else { 
				if (FldVal.StartsWith("@@")) { 
					sWrk = GetCustomFilter(fld, FldVal);
				} else if (ewr_NotEmpty(FldDelimiter) && ewr_NotEmpty(FldVal)) {
					sWrk = ewr_GetMultiSearchSql(FldExpression, FldVal.Trim()); 
				} else {
					if (ewr_NotEmpty(FldVal) && !ewr_SameStr(FldVal, EWR_INIT_VALUE)) { 
						if (FldDataType == EWR_DATATYPE_DATE && FldOpr != "") { 
							sWrk = ewr_DateFilterString(FldOpr, FldVal, FldDataType); 
						} else { 
							sWrk = ewr_FilterString("=", FldVal, FldDataType); 
						} 
					} 
					if (ewr_NotEmpty(sWrk)) 
						sWrk = FldExpression + sWrk; 
				} 
			} 
			return sWrk;
		}		

		// Get custom filter
		public string GetCustomFilter(crField fld, string FldVal) {
			string sWrk = "";
			foreach (var kvp in fld.AdvancedFilters) {
				var filter = kvp.Value; 
				if (filter.ID == FldVal && filter.Enabled) {
					string sFld = fld.FldExpression;
					string sFn = filter.FunctionName;
					string wrkid = filter.ID.StartsWith("@@") ? filter.ID.Substring(2) : filter.ID;
					if (ewr_NotEmpty(sFn))
						sWrk = Convert.ToString(Invoke(sFn, new object[] { sFld }));
					Page_Filtering(fld, ref sWrk, "custom", wrkid, "", "", "", "");
					break;
				}
			}
			return sWrk;
		}

		// Build extended filter
		public void BuildExtendedFilter(crField fld, ref string FilterClause, bool Def = false, bool SaveFilter = false) {
			string sWrk = ewr_GetExtendedFilter(fld, Def);
			if (!Def)
				Page_Filtering(fld, ref sWrk, "extended", fld.SearchOperator, Convert.ToString(fld.SearchValue), fld.SearchCondition, fld.SearchOperator2, Convert.ToString(fld.SearchValue2));
			if (ewr_NotEmpty(sWrk)) {
				ewr_AddFilter(ref FilterClause, sWrk);
				if (SaveFilter)
					fld.CurrentFilter = sWrk;
			}
		}

		// Get drop down value from querystring
		public bool GetDropDownValue(ref object sv, string parm) {
			if (IsPost)
				return false; // Skip post back
			if (ewr_Request.QueryString["sv_" + parm] != null) { 
				sv = new List<string>(ewr_Request.QueryString.GetValues("sv_" + parm)); // AXR
				return true;
			}
			return false;
		}

		// Get filter values from querystring 
		public bool GetFilterValues(crField fld) {				
			string parm = fld.FldVar.Substring(2);
			if (IsPost)
				return false; // Skip post back 
			bool got = false;				
			if (ewr_Request.QueryString["sv_" + parm] != null) { 
				fld.SearchValue = ewr_Get("sv_" + parm); 
				got = true; 
			} 
			if (ewr_Request.QueryString["so_" + parm] != null) { 
				fld.SearchOperator = ewr_Get("so_" + parm); 
				got = true;		
			} 
			if (ewr_Request.QueryString["sc_" + parm] != null) {  
				fld.SearchCondition = ewr_Get("sc_" + parm); 
				got = true;		
			} 
			if (ewr_Request.QueryString["sv2_" + parm] != null) {  
				fld.SearchValue2 = ewr_Get("sv2_" + parm); 
				got = true; 
			} 
			if (ewr_Request.QueryString["so2_" + parm] != null) {  
				fld.SearchOperator2 = ewr_Get("so2_" + parm); 
				got = true;		
			} 
			return got; 
		}

		// Set default ext filter
		public void SetDefaultExtFilter(crField fld, string so1, string sv1, string sc, string so2, string sv2) {
			fld.DefaultSearchValue = sv1; // Default ext filter value 1
			fld.DefaultSearchOperator = so1; // Default search operator 1
			fld.DefaultSearchCondition = sc; // Default search condition (if operator 2 is enabled)
			fld.DefaultSearchValue2 = sv2; // Default ext filter value 2 (if operator 2 is enabled)
			fld.DefaultSearchOperator2 = so2; // Default search operator 2 (if operator 2 is enabled)
		}

		// Apply default ext filter
		public void ApplyDefaultExtFilter(crField fld) {
			fld.SearchValue = fld.DefaultSearchValue;
			fld.SearchOperator = fld.DefaultSearchOperator;
			fld.SearchCondition = fld.DefaultSearchCondition;
			fld.SearchValue2 = fld.DefaultSearchValue2;
			fld.SearchOperator2 = fld.DefaultSearchOperator2;
		}

		// Check if Text Filter applied
		public bool TextFilterApplied(crField fld) {
			return (!ewr_SameStr(fld.SearchValue, fld.DefaultSearchValue) ||
				!ewr_SameStr(fld.SearchValue2, fld.DefaultSearchValue2) ||
				(ewr_NotEmpty(fld.SearchValue) && !ewr_SameStr(fld.SearchOperator, fld.DefaultSearchOperator)) ||
				(ewr_NotEmpty(fld.SearchValue2) && !ewr_SameStr(fld.SearchOperator2, fld.DefaultSearchOperator2)) ||
				!ewr_SameStr(fld.SearchCondition, fld.DefaultSearchCondition));
		}

		// Check if Non-Text Filter applied
		public bool NonTextFilterApplied(crField fld) {
			if (ewr_IsList(fld.DropDownValue)) {
				if (ewr_IsList(fld.DefaultDropDownValue)) {
					List<string> ar1 = (List<string>)fld.DropDownValue;
					List<string> ar2 = (List<string>)fld.DefaultDropDownValue;
					if (ar1.Count != ar2.Count) {
						return true;
					} else {
						return !ewr_MatchedArray(ar1.OrderBy(s => s), ar2.OrderBy(s => s));
					}
				} else {
					return true;
				}
			} else {
				string v1;
				if (ewr_IsList(fld.DefaultDropDownValue))
					return true;
				else
					v1 = Convert.ToString(fld.DefaultDropDownValue);
				if (v1 == EWR_INIT_VALUE)
					v1 = "";
				string v2 = Convert.ToString(fld.DropDownValue);
				if (v1 == EWR_INIT_VALUE)
					v1 = "";
				v2 = Convert.ToString(fld.DropDownValue);
				if (v2 == EWR_INIT_VALUE || v2 == EWR_ALL_VALUE)
					v2 = "";
				return (!ewr_SameStr(v1, v2));
			}
		}

		// Get dropdown value from Session 
		public void GetSessionDropDownValue(crField fld) {
			string parm = fld.FldVar.Substring(2);
			GetSessionValue(ref fld.DropDownValue, "sv_CanalDenuncias_" + parm);
		}

		// Get filter values from session
		public void GetSessionFilterValues(crField fld) {
			string parm = fld.FldVar.Substring(2);
			GetSessionValue(ref fld.SearchValue, "sv_CanalDenuncias_" + parm);
			GetSessionValue(ref fld.SearchOperator, "so_CanalDenuncias_" + parm);
			GetSessionValue(ref fld.SearchCondition, "sc_CanalDenuncias_" + parm);
			GetSessionValue(ref fld.SearchValue2, "sv2_CanalDenuncias_" + parm);
			GetSessionValue(ref fld.SearchOperator2, "so2_CanalDenuncias_" + parm);
		}

		// Get value from session // AXR
		public void GetSessionValue(ref object sv, string sn) {
			if (ewr_Session[sn] != null)
				sv = ewr_Session[sn];
		}

		// Get value from session // AXR
		public void GetSessionValue(ref string sv, string sn) {
			if (ewr_Session[sn] != null)
				sv = Convert.ToString(ewr_Session[sn]);
		}

		// Set dropdown value to session
		public void SetSessionDropDownValue(object sv, string parm) {
			ewr_Session["sv_CanalDenuncias_" + parm] = sv;
		}

		// Set filter values to session
		public void SetSessionFilterValues(string sv1, string so1, string sc, string sv2, string so2, string parm) {
			ewr_Session["sv_CanalDenuncias_" + parm] = sv1;
			ewr_Session["so_CanalDenuncias_" + parm] = so1;
			ewr_Session["sc_CanalDenuncias_" + parm] = sc;
			ewr_Session["sv2_CanalDenuncias_" + parm] = sv2;
			ewr_Session["so2_CanalDenuncias_" + parm] = so2;
		}

		// Check if has Session filter values 
		public bool HasSessionFilterValues(string parm) { 
			return (ewr_NotEmpty(ewr_Session["sv_" + parm]) && !ewr_SameStr(ewr_Session["sv_" + parm], EWR_INIT_VALUE)) ||
				(ewr_NotEmpty(ewr_Session["sv_" + parm]) && !ewr_SameStr(ewr_Session["sv_" + parm], EWR_INIT_VALUE)) ||
				(ewr_NotEmpty(ewr_Session["sv2_" + parm]) && !ewr_SameStr(ewr_Session["sv2_" + parm], EWR_INIT_VALUE)); 
		}

		// Check if dropdown filter
		public bool DropDownFilterExist(crField fld, string FldOpr) {
			string sWrk = "";
			BuildDropDownFilter(fld, ref sWrk, FldOpr);
			return ewr_NotEmpty(sWrk);
		}

		// Check if extended filter
		public bool ExtendedFilterExist(crField fld)	{
			string sExtWrk = "";
			BuildExtendedFilter(fld, ref sExtWrk);
			return ewr_NotEmpty(sExtWrk);
		}

		// Validate form
		public bool ValidateForm() {

			// Initialize form error message
			gsFormError = "";

			// Check if validation required
			if (!EWR_SERVER_VALIDATE)
				return ewr_Empty(gsFormError);
			if (!ewr_CheckEuroDate(Convert.ToString(fecha.SearchValue))) {
				if (ewr_NotEmpty(gsFormError)) {
					gsFormError += "<br />";
				}
				gsFormError += fecha.FldErrMsg;
			}
			if (!ewr_CheckEuroDate(Convert.ToString(fecha.SearchValue2))) {
				if (ewr_NotEmpty(gsFormError)) {
					gsFormError += "<br />";
				}
				gsFormError += fecha.FldErrMsg;
			}

			// Return validate result
			bool valid = ewr_Empty(gsFormError);

			// Call Form_CustomValidate event
			string sFormCustomError = "";
			valid = valid && Form_CustomValidate(ref sFormCustomError);
			if (ewr_NotEmpty(sFormCustomError)) {
				gsFormError += (ewr_NotEmpty(gsFormError)) ? "<div class=\"ewSpacer\">&nbsp;</div>" : "";
				gsFormError += sFormCustomError;
			}
			return valid;
		}

		// Clear selection stored in session
		public void ClearSessionSelection(string parm) {
			ewr_Session["sel_CanalDenuncias_" + parm] = "";
			ewr_Session["rf_CanalDenuncias_" + parm] = "";
			ewr_Session["rt_CanalDenuncias_" + parm] = "";
		}

		// Load selection from session
		public void LoadSelectionFromSession(string parm) {
			var fld = Fields[parm];
			fld.SelectionList = (List<string>)ewr_Session["sel_CanalDenuncias_" + parm];
			fld.RangeFrom = Convert.ToString(ewr_Session["rf_CanalDenuncias_" + parm]);
			fld.RangeTo = Convert.ToString(ewr_Session["rt_CanalDenuncias_" + parm]);
		}	

		// Load default value for filters
		public void LoadDefaultFilters() {	
			string sWrk;
		  	string sSql; 

			//
			// Set up default values for non Text filters
			//
			// TipoDelito

			TipoDelito.DefaultDropDownValue = GetCustomValue("DefaultDropDownValue", "TipoDelito"); // AXR
			if (!SearchCommand) TipoDelito.DropDownValue = TipoDelito.DefaultDropDownValue;

			// tipoUsuario
			tipoUsuario.DefaultDropDownValue = GetCustomValue("DefaultDropDownValue", "tipoUsuario"); // AXR
			if (!SearchCommand) tipoUsuario.DropDownValue = tipoUsuario.DefaultDropDownValue;

			/**
			* Set up default values for extended filters
			* SetDefaultExtFilter(fld, so1, sv1, sc, so2, sv2)
			* Parameters:
			* fld - Field object
			* so1 - Default search operator 1
			* sv1 - Default ext filter value 1
			* sc - Default search condition (if operator 2 is enabled)
			* so2 - Default search operator 2 (if operator 2 is enabled)
			* sv2 - Default ext filter value 2 (if operator 2 is enabled)
			*/

			// rut
			SetDefaultExtFilter(rut, "LIKE", Convert.ToString(GetCustomValue("FldDefault", "rut")), "AND", "=", null);
			if (!SearchCommand) ApplyDefaultExtFilter(rut);

			// nombre
			SetDefaultExtFilter(nombre, "LIKE", Convert.ToString(GetCustomValue("FldDefault", "nombre")), "AND", "=", null);
			if (!SearchCommand) ApplyDefaultExtFilter(nombre);

			// apellido_P
			SetDefaultExtFilter(apellido_P, "LIKE", Convert.ToString(GetCustomValue("FldDefault", "apellido_P")), "AND", "=", null);
			if (!SearchCommand) ApplyDefaultExtFilter(apellido_P);

			// apellido_M
			SetDefaultExtFilter(apellido_M, "LIKE", Convert.ToString(GetCustomValue("FldDefault", "apellido_M")), "AND", "=", null);
			if (!SearchCommand) ApplyDefaultExtFilter(apellido_M);

			// EMAIL
			SetDefaultExtFilter(_EMAIL, "LIKE", Convert.ToString(GetCustomValue("FldDefault", "_EMAIL")), "AND", "=", null);
			if (!SearchCommand) ApplyDefaultExtFilter(_EMAIL);

			// CIUDAD
			SetDefaultExtFilter(CIUDAD, "LIKE", Convert.ToString(GetCustomValue("FldDefault", "CIUDAD")), "AND", "=", null);
			if (!SearchCommand) ApplyDefaultExtFilter(CIUDAD);

			// fecha
			SetDefaultExtFilter(fecha, "BETWEEN", Convert.ToString(GetCustomValue("FldDefault", "fecha")), "AND", "=", Convert.ToString(GetCustomValue("FldDefault2", "fecha")));
			if (!SearchCommand) ApplyDefaultExtFilter(fecha);

			//
			// Set up default values for popup filters
			//

		}

		// Check if filter applied
		public bool CheckFilter() {

			// Check rut text filter
			if (TextFilterApplied(rut))
				return true;

			// Check nombre text filter
			if (TextFilterApplied(nombre))
				return true;

			// Check apellido_P text filter
			if (TextFilterApplied(apellido_P))
				return true;

			// Check apellido_M text filter
			if (TextFilterApplied(apellido_M))
				return true;

			// Check EMAIL text filter
			if (TextFilterApplied(_EMAIL))
				return true;

			// Check CIUDAD text filter
			if (TextFilterApplied(CIUDAD))
				return true;

			// Check TipoDelito extended filter
			if (NonTextFilterApplied(TipoDelito))
				return true;

			// Check fecha text filter
			if (TextFilterApplied(fecha))
				return true;

			// Check tipoUsuario extended filter
			if (NonTextFilterApplied(tipoUsuario))
				return true;
			return false;
		}

		// Show list of filters
		public void ShowFilterList() {
			string sFilterList = "";
			string sExtWrk = ""; 
		 	string sWrk = "";
			string sFilter = "";

			// rut
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(rut, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + rut.FldCaption + "</span>" + sFilter + "</div>";

			// nombre
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(nombre, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + nombre.FldCaption + "</span>" + sFilter + "</div>";

			// apellido_P
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(apellido_P, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + apellido_P.FldCaption + "</span>" + sFilter + "</div>";

			// apellido_M
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(apellido_M, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + apellido_M.FldCaption + "</span>" + sFilter + "</div>";

			// EMAIL
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(_EMAIL, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + _EMAIL.FldCaption + "</span>" + sFilter + "</div>";

			// CIUDAD
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(CIUDAD, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + CIUDAD.FldCaption + "</span>" + sFilter + "</div>";

			// TipoDelito
			sExtWrk = "";
			sWrk = "";
			BuildDropDownFilter(TipoDelito, ref sExtWrk, "");
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + TipoDelito.FldCaption + "</span>" + sFilter + "</div>";

			// fecha
			sExtWrk = "";
			sWrk = "";
			BuildExtendedFilter(fecha, ref sExtWrk);
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + fecha.FldCaption + "</span>" + sFilter + "</div>";

			// tipoUsuario
			sExtWrk = "";
			sWrk = "";
			BuildDropDownFilter(tipoUsuario, ref sExtWrk, "");
			sFilter = "";
			if (ewr_NotEmpty(sExtWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sExtWrk + "</span>";
			else if (ewr_NotEmpty(sWrk))
				sFilter += "<span class=\"ewFilterValue\">" + sWrk + "</span>";
			if (ewr_NotEmpty(sFilter))
				sFilterList += "<div><span class=\"ewFilterCaption\">" + tipoUsuario.FldCaption + "</span>" + sFilter + "</div>";

			// Show Filters
			if (ewr_NotEmpty(sFilterList)) {
				string sMessage = "<div>" + ReportLanguage.Phrase("CurrentFilters") + "</div>" + sFilterList;
				Message_Showing(ref sMessage, "");
				ewr_Write(sMessage);
			}
		}

		// Return popup filter
		public string GetPopupFilter() {
			string sWrk = "";
			if (DrillDown)
				return "";
			return sWrk;
		}

		// Return Sort parameters based on Sort Links clicked
		// Variables setup: ewr_Session[EWR_TABLE_SESSION_ORDER_BY], ewr_Session["sort_Table_Field"]
		public string GetSort() {
			if (DrillDown)
				return "[apellido_P] ASC, [apellido_M] ASC";

			// Check for a resetsort command
			if (ewr_NotEmpty(ewr_Get("cmd"))) {
				string sCmd = ewr_Get("cmd");
				if (ewr_SameText(sCmd, "resetsort")) {
					OrderBy = "";
					StartGroup = 1;
					rut.Sort = "";
					nombre.Sort = "";
					apellido_P.Sort = "";
					apellido_M.Sort = "";
					_EMAIL.Sort = "";
					DIRECCION.Sort = "";
					COMUNA.Sort = "";
					CIUDAD.Sort = "";
					TelefonoContacto.Sort = "";
					TipoDelito.Sort = "";
					detalle.Sort = "";
					adjunto.Sort = "";
					ip.Sort = "";
					fecha.Sort = "";
					tipoUsuario.Sort = "";
				}

			// Check for an Order parameter
			} else if (ewr_NotEmpty(ewr_Get("order"))) {
				CurrentOrder = ewr_Get("order");
				CurrentOrderType = ewr_Get("ordertype");
				var sSortSql = SortSql();
				OrderBy = sSortSql;
				StartGroup = 1;
			}

			// Set up default sort
			if (ewr_Empty(OrderBy)) {
				OrderBy = "[apellido_P] ASC, [apellido_M] ASC";
				apellido_P.Sort = "ASC";
				apellido_M.Sort = "ASC";
			}
			return OrderBy;
		}

	// Export to EXCEL
	public void ExportExcel(string html) {
		ewr_Response.ContentType = "application/vnd.ms-excel" + ((ewr_NotEmpty(EWR_CHARSET)) ? ";charset=" + EWR_CHARSET : "");
		ewr_AddHeader("Content-Disposition", "attachment; filename=" + gsExportFile + ".xls");
		ewr_Response.Write(html);
	}

		// Render chart content
		public string RenderChart(crChart Chart) {
			Chart.LoadChartParms();

			//ewr_Write("id: " + Chart.ID + "<br>");
			//ewr_Write("type: " + Chart.ChartType + "<br>");
			// Get chart xml

			var chartxml = Chart.ChartXml();
			return chartxml;
		}

	// Page Load event
	public virtual void Page_Load() {

		//ewr_Write("Page Load");
	}

	// Page Unload event
	public virtual void Page_Unload() {

		//ewr_Write("Page Unload");
	}

	// Message Showing event
	// type = ""|"success"|"failure"|"warning"
	public virtual void Message_Showing(ref string msg, string type) {

		// Note: Do not change msg outside the following 4 cases.
		if (type == "success") {

			//msg = "your success message";
		} else if (type == "failure") {

			//msg = "your failure message";
		} else if (type == "warning") {

			//msg = "your warning message";
		} else {

			//msg = "your message";
		}
	}

	// Page Data Rendering event
	public virtual void Page_DataRendering(ref string header) {

		// Example:
		//header = "your header";

	}

	// Page Data Rendered event
	public virtual void Page_DataRendered(ref string footer) {

		// Example:
		//footer = "your footer";

	}

		// Form Custom Validate event
		public virtual bool Form_CustomValidate(ref string CustomError) {

			// Return error message in CustomError
			return true;
		}
	}
}
