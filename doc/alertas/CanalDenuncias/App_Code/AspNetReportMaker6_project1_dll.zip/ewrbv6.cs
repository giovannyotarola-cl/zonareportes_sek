using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	// Blob View
	public static crrewbv rewbv;

	//
	// Page class
	//
	public class crrewbv {

		// 
		// Page main
		//
		public void Page_Main() {
			ewr_Response.Cache.SetCacheability(HttpCacheability.NoCache);
			int width = 0;
			int height = 0;
			int interpolation;

			// Get resize parameters
			bool resize = (ewr_NotEmpty(ewr_Get("resize")));		
			if (ewr_NotEmpty(ewr_Get("width")))
				width = ewr_ConvertToInt(ewr_Get("width"));
			if (ewr_NotEmpty(ewr_Get("height")))
				height = ewr_ConvertToInt(ewr_Get("height"));
			if (width <= 0 && height <= 0) {
				width = EWR_THUMBNAIL_DEFAULT_WIDTH;
				height = EWR_THUMBNAIL_DEFAULT_HEIGHT;
			}
			if (ewr_NotEmpty(ewr_Get("interpolation"))) {
				interpolation = ewr_ConvertToInt(ewr_Get("interpolation"));
			} else {
				interpolation = EWR_THUMBNAIL_DEFAULT_INTERPOLATION;
			}

			// Resize image from physical file
			if (ewr_NotEmpty(ewr_Get("fn"))) {
				string fn = ewr_Get("fn");
				fn = ewr_UploadPathEx(true, fn); // Physical path relative to root
				if (File.Exists(fn)) { // Does not support remote path
					string ext = Path.GetExtension(fn).Replace(".", "").ToLower();
					if ((new List<string>(EWR_IMAGE_ALLOWED_FILE_EXT.ToLower().Split(new char[] {','}))).Contains(ext)) {
						ewr_Response.ContentType = ewr_GetImageContentType(fn);
						ewr_BinaryWrite(ewr_ResizeFileToBinary(fn, ref width, ref height, interpolation));
					}
				}
			}
		}
	}
}
