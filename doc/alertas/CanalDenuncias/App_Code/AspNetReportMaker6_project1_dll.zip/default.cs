using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET WebPage class
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	// rptdefault
	public static dynamic rptdefault {
		get { return (dynamic)ewr_PageData["rptdefault"]; }
		set { ewr_PageData["rptdefault"] = value; }
	}

	//
	// Page class
	//
	public class crrptdefault_base<C, S>		
		where C : cConnectionBase, new()
		where S : cAdvancedSecurityBase, new()
	{

		// Page ID
		public string PageID = "rptdefault";

		// Project ID
		public string ProjectID = "{5E252714-15AD-4FF5-8F78-DA7E4D955D0D}";

		// Page object name
		public string PageObjName = "rptdefault";

		// Page name
		public string PageName {
			get { return ewr_CurrentPage(); }
		}

		// Page URL
		public string PageUrl {
			get {
				string PageUrl = ewr_CurrentPage() + "?";
				return PageUrl;
			}
		}

		// Message
		public string Message {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_MESSAGE] = msg;
			}
		}

		// Failure Message
		public string FailureMessage {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_FAILURE_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_FAILURE_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_FAILURE_MESSAGE] = msg;
			}
		}

		// Success Message
		public string SuccessMessage {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_SUCCESS_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_SUCCESS_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_SUCCESS_MESSAGE] = msg;
			}
		}

		// Warning Message
		public string WarningMessage {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_WARNING_MESSAGE]); }
			set {
				string msg = Convert.ToString(ewr_Session[EWR_SESSION_WARNING_MESSAGE]); 
				ewr_AddMessage(ref msg, value);
				ewr_Session[EWR_SESSION_WARNING_MESSAGE] = msg;
			}
		}

		// Show message
		public void ShowMessage() {
			bool hidden = false;
			string html = "";

			// Message
			string sMessage = Message;
			Message_Showing(ref sMessage, "");
			if (ewr_NotEmpty(sMessage)) { // Message in Session, display
				html += "<p class=\"ewMessage\">" + sMessage + "</p>";
				ewr_Session[EWR_SESSION_MESSAGE] = ""; // Clear message in Session
			}

			// Warning message
			string sWarningMessage = WarningMessage;
			Message_Showing(ref sWarningMessage, "warning");
			if (ewr_NotEmpty(sWarningMessage)) { // Message in Session, display
				html += "<table class=\"ewMessageTable\"><tr><td class=\"ewWarningIcon\"></td><td class=\"ewWarningMessage\">" + sWarningMessage + "</td></tr></table>";
				ewr_Session[EWR_SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
			}

			// Success message
			string sSuccessMessage = SuccessMessage;
			Message_Showing(ref sSuccessMessage, "success");
			if (ewr_NotEmpty(sSuccessMessage)) { // Message in Session, display
				html += "<table class=\"ewMessageTable\"><tr><td class=\"ewSuccessIcon\"></td><td class=\"ewSuccessMessage\">" + sSuccessMessage + "</td></tr></table>";
				ewr_Session[EWR_SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
			}

			// Failure message
			string sErrorMessage = FailureMessage;
			Message_Showing(ref sErrorMessage, "failure");
			if (ewr_NotEmpty(sErrorMessage)) { // Message in Session, display
				html += "<table class=\"ewMessageTable\"><tr><td class=\"ewErrorIcon\"></td><td class=\"ewErrorMessage\">" + sErrorMessage + "</td></tr></table>";
				ewr_Session[EWR_SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
			}		
			ewr_Write("<div class=\"ewMessageDialog\"" + ((hidden) ? " style=\"display: none;\"" : "") + ">" + html + "</div>");
		}

		//
		// Page class constructor
		//
		public crrptdefault_base() {	

			// User agent
			UserAgent = ewr_UserAgent();
			CurrentPage = this;

			// Language object
			if (ReportLanguage == null)
				ReportLanguage = new crLanguage();	

			// Start time
			StartTime = Environment.TickCount;

			// Open connection
			if (Conn == null)
				Conn = new C();
		}

		// 
		//  Page_Init
		//
		public void Page_Init() {

			// Global Page Loading event (in userfn*.cs)
			ewr_WebPage.Page_Loading();

			// Page Load event
			Page_Load();
		}

		//
		// Page_Terminate
		//
		public void Page_Terminate(string url = "") {

			// Page Unload event
			Page_Unload();

			// Global Page Unloaded event (in userfn*.cs)
			ewr_WebPage.Page_Unloaded();

			// Close connection
			if (Conn != null)
				Conn.Close();

			// Gargage collection // ASPX
			ewr_GCollect();

			// Go to URL if specified
			if (ewr_NotEmpty(url)) {
				if (EWR_DEBUG_ENABLED)
					ewr_Response.Clear();
				ewr_Response.Redirect(ewr_MapPath(url, false)); // ASPX
			}

			//ewr_End();
		}

		//
		// Page main
		//
		public void Page_Main() {
			Page_Terminate("CanalDenunciassmry.vbhtml"); // Exit and go to default page
		}

	// Page Load event
	public virtual void Page_Load() {

		//ewr_Write("Page Load");
	}

	// Page Unload event
	public virtual void Page_Unload() {

		//ewr_Write("Page Unload");
	}

	// Message Showing event
	// type = ""|"success"|"failure"|"warning"
	public virtual void Message_Showing(ref string msg, string type) {

		// Note: Do not change msg outside the following 4 cases.
		if (type == "success") {

			//msg = "your success message";
		} else if (type == "failure") {

			//msg = "your failure message";
		} else if (type == "warning") {

			//msg = "your warning message";
		} else {

			//msg = "your message";
		}
	}
	}
}
