using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Web;
using System.Web.WebPages;
using System.Web.Helpers;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.Common;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;
using System.Reflection;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Linq;
using System.Dynamic;
using System.DirectoryServices;
using Microsoft.VisualBasic;
using Microsoft.Web.Helpers;
using WebMatrix.Data;
using Newtonsoft.Json;
using System.Data.SqlClient;
using ewConnection = System.Data.SqlClient.SqlConnection;
using ewCommand = System.Data.SqlClient.SqlCommand;
using ewDataReader = System.Data.SqlClient.SqlDataReader;
using ewTransaction = System.Data.SqlClient.SqlTransaction;
using ewDbType = System.Data.SqlDbType;

//
// ASP.NET Report Maker 6 Project Class
// (C)2013 e.World Technology Ltd. All rights reserved.
//
public partial class AspNetReportMaker6_project1_base : WebPage {

	// Execute method
	public override void Execute() {
	}

	// IsPost
	public static bool IsPost {
		get { return ewr_Page.IsPost; }
	}

	// Current page
	public static AspNetReportMaker6_project1_base ewr_WebPage {
		get { return (AspNetReportMaker6_project1_base)WebPageContext.Current.Page; }
	}

	public static WebPage ewr_Page {
		get { return (WebPage)WebPageContext.Current.Page; }
	}

	// Page data
	public static IDictionary<Object, Object> ewr_PageData {
		get { return ewr_Page.PageData; }
	}

	// Request
	public static HttpRequestBase ewr_Request {
		get { return ewr_Page.Request; }
	}

	// Response
	public static HttpResponseBase ewr_Response {
		get { return ewr_Page.Response; }
	}

	// Server
	public static HttpServerUtilityBase ewr_Server {
		get { return ewr_Page.Server; }
	}

	// Form
	public static NameValueCollection ewr_Form {
		get { return ewr_Page.Request.Unvalidated().Form; }
	}

	// QueryString
	public static NameValueCollection ewr_QueryString {
		get { return ewr_Page.Request.Unvalidated().QueryString; }
	}

	// Files
	public static HttpFileCollectionBase ewr_Files {
		get { return ewr_Page.Request.Files; }
	}

	// Session
	public static HttpSessionStateBase ewr_Session {
		get { return ewr_Page.Session; }
	}	

	// Compare object as string
	public static bool ewr_SameStr(object v1, object v2)
	{
		return string.Equals(Convert.ToString(v1).Trim(), Convert.ToString(v2).Trim());
	}

	// Compare object as string (case insensitive)
	public static bool ewr_SameText(object v1, object v2)
	{
		return string.Equals(Convert.ToString(v1).Trim().ToUpperInvariant(), Convert.ToString(v2).Trim().ToUpperInvariant());
	}

	// Compare object as integer
	public static bool ewr_SameInt(object v1, object v2)
	{
		try {
			return (Convert.ToInt32(v1) == Convert.ToInt32(v2));
		} catch {
			return false;
		}
	}

	// Compare object as specified type
    public static bool ewr_Same<T>(object v1, object v2)
    {
        try {
			return EqualityComparer<T>.Default.Equals(Convert.ToString(v1).Trim().As<T>(), Convert.ToString(v2).Trim().As<T>());
		} catch {
			return false;
		}
    }

	// Compare file name without extension // ASPX
	public static bool ewr_SameFileName(string v1, string v2)
	{
		return string.Equals(Path.GetFileNameWithoutExtension(v1), Path.GetFileNameWithoutExtension(v2));
	}

	// Check if empty string
	public static bool ewr_Empty(object value)
	{
		return string.Equals(Convert.ToString(value).Trim(), string.Empty);
	}

	// Check if not empty string
	public static bool ewr_NotEmpty(object value)
	{
		return !ewr_Empty(value);
	}

	// Convert object to integer
	public static int ewr_ConvertToInt(object value)
	{
		try {
			return Convert.ToInt32(value);
		} catch {
			return 0;
		}
	}

	// Convert object to double
	public static double ewr_ConvertToDouble(object value)
	{
		try {
			return Convert.ToDouble(value);
		} catch {
			return 0;
		}
	}

	// Prepend CSS class name
	public static string ewr_PrependClass(string attr, string classname) {
		classname = classname.Trim();
		if (ewr_NotEmpty(classname)) {
			attr = attr.Trim();
			if (ewr_NotEmpty(attr))
				attr = " " + attr;
			attr = classname + attr;
		}
		return attr;
	}

	// Append CSS class name
	public static string ewr_AppendClass(string attr, string classname) {
		classname = classname.Trim();
		if (ewr_NotEmpty(classname)) {
			attr = attr.Trim();
			if (ewr_NotEmpty(attr))
				attr += " ";
			attr += classname;			
		}
		return attr;
	}

	// Add message
	public static void ewr_AddMessage(ref string msg, string newmsg) {
		if (ewr_NotEmpty(newmsg)) {
			if (ewr_NotEmpty(msg))
				msg += "<br />";
			msg += newmsg;
		}
	}

	// Join messages by "<br />" and return the combined message
	public static string ewr_JoinMessage(string msg, string newmsg) {
		if (ewr_NotEmpty(newmsg)) {
			if (ewr_NotEmpty(msg))
				msg += "<br />";
			msg += newmsg;
		}
		return msg;
	}

	// Add filter
	public static void ewr_AddFilter(ref string filter, string newfilter) {
		if (ewr_Empty(newfilter))
			return;
		if (ewr_NotEmpty(filter)) {
			filter = "(" + filter + ") AND (" + newfilter + ")";
		} else {
			filter = newfilter;
		}
	}

	// Join filters by "AND" and return the combined filter
	public static string ewr_JoinFilter(string filter, string newfilter) {
		if (ewr_Empty(newfilter))
			return filter;
		if (ewr_NotEmpty(filter)) {
			filter = "(" + filter + ") AND (" + newfilter + ")";
		} else {
			filter = newfilter;
		}
		return filter;
	}

	// Get user IP
	public static string ewr_CurrentUserIP() {
        string ipaddr = "";
        string host = ewr_ServerVar("SERVER_NAME");
        if (ewr_NotEmpty(host))
            ipaddr = ewr_GetIP4Address(host);
        if (ewr_Empty(ipaddr)) {
            host = ewr_Request.UserHostAddress;
			if (ewr_NotEmpty(host))
				ipaddr = ewr_GetIP4Address(host);
		}
		if (ewr_Empty(ipaddr)) {
            host = Dns.GetHostName();
			if (ewr_NotEmpty(host))
				ipaddr = ewr_GetIP4Address(host);
		}        
        return ipaddr;
	}

    // Get IPv4 Address
	public static string ewr_GetIP4Address(string host) {
        string ipaddr = String.Empty;
		try {
	        foreach (IPAddress IPA in Dns.GetHostAddresses(host)) {
	            if (IPA.AddressFamily.ToString() == "InterNetwork") {
	                ipaddr = IPA.ToString();
	                break;
	            }
	        }
		} catch {}
        return ipaddr;
    }

	// Get current date in default date format
	public static string ewr_CurrentDate(int namedformat = -1) {
		string DT;
		if (ewr_Contains(namedformat, new int[] {5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17})) {
			if (ewr_Contains(namedformat, new int[] {5, 9, 12, 15})) {
				DT = ewr_FormatDateTime(DateTime.Today, 5);
			} else if (ewr_Contains(namedformat, new int[] {6, 10, 13, 16})) {
				DT = ewr_FormatDateTime(DateTime.Today, 6);
			} else {
				DT = ewr_FormatDateTime(DateTime.Today, 7);
			}
			return DT;
		} else {
			return ewr_FormatDateTime(DateTime.Today, 5);
		}
	}

	// Get current time in hh:mm:ss format
	public static string ewr_CurrentTime() {
		DateTime DT;
		DT = DateTime.Now;
		return DT.ToString("HH':'mm':'ss");
	}

	// Get current date in default date format with
	// Current time in hh:mm:ss format
	public static string ewr_CurrentDateTime(int namedformat = -1) {
		string DT;
		if (ewr_Contains(namedformat, new int[] {5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17})) {
			if (ewr_Contains(namedformat, new int[] {5, 9, 12, 15})) {
				DT = ewr_FormatDateTime(DateTime.Now, 9);
			} else if (ewr_Contains(namedformat, new int[] {6, 10, 13, 16})) {
				DT = ewr_FormatDateTime(DateTime.Now, 10);
			} else {
				DT = ewr_FormatDateTime(DateTime.Now, 11);
			}
			return DT;
		} else {
			return ewr_FormatDateTime(DateTime.Now, 9);
		}		
	}

	// Remove XSS
	public static object ewr_RemoveXSS(object val) {
		string val_before, pattern, replacement;

		// Handle null value
		if (ewr_Empty(val)) return val;

		// Remove all non-printable characters. CR(0a) and LF(0b) and TAB(9) are allowed 
		// This prevents some character re-spacing such as <java\0script> 
		// Note that you have to handle splits with \n, \r, and \t later since they *are* allowed in some inputs

		Regex regEx = new Regex("([\\x00-\\x08][\\x0b-\\x0c][\\x0e-\\x20])", RegexOptions.IgnoreCase);

		// Create regular expression.
		val = regEx.Replace(Convert.ToString(val), "");

		// Straight replacements, the user should never need these since they're normal characters 
		// This prevents like <IMG SRC=&#X40&#X61&#X76&#X61&#X73&#X63&#X72&#X69&#X70&#X74&#X3A&#X61&#X6C&#X65&#X72&#X74&#X28&#X27&#X58&#X53&#X53&#X27&#X29> 

		string search = "abcdefghijklmnopqrstuvwxyz";
		search = search + "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		search = search + "1234567890!@#$%^&*()";
		search = search + "~`\";:?+/={}[]-_|'\\";
		for (int i = 0; i <= search.Length - 1; i++) {

			// ;? matches the ;, which is optional 
			// 0{0,7} matches any padded zeros, which are optional and go up to 8 chars 
			// &#x0040 @ search for the hex values

			regEx = new Regex("(&#[x|X]0{0,8}" + Conversion.Hex(Strings.Asc(search[i])) + ";?)");

			// With a ;
			val = regEx.Replace(Convert.ToString(val), Convert.ToString(search[i]));

			// &#00064 @ 0{0,7} matches '0' zero to seven times
			regEx = new Regex("(&#0{0,8}" + Strings.Asc(search[i]) + ";?)");

			// With a ;
			val = regEx.Replace(Convert.ToString(val), Convert.ToString(search[i]));
		}

		// Now the only remaining whitespace attacks are \t, \n, and \r
		bool Found = true;

		// Keep replacing as long as the previous round replaced something 
		while (Found) {
			val_before = Convert.ToString(val);
			for (int i = 0; i <= EWR_REMOVE_XSS_KEYWORDS.GetUpperBound(0); i++) {
				pattern = "";
				for (int j = 0; j <= EWR_REMOVE_XSS_KEYWORDS[i].Length - 1; j++) {
					if (j > 0) {
						pattern = pattern + "(";
						pattern = pattern + "(&#[x|X]0{0,8}([9][a][b]);?)?";
						pattern = pattern + "|(&#0{0,8}([9][10][13]);?)?";
						pattern = pattern + ")?";
					}
					pattern = pattern + EWR_REMOVE_XSS_KEYWORDS[i][j];
				}
				replacement = EWR_REMOVE_XSS_KEYWORDS[i].Substring(0, 2) + "<x>" + EWR_REMOVE_XSS_KEYWORDS[i].Substring(2);

				// Add in <> to nerf the tag
				regEx = new Regex(pattern);
				val = regEx.Replace(Convert.ToString(val), replacement);

				// Filter out the hex tags
				if (ewr_SameStr(val_before, val)) {

					// No replacements were made, so exit the loop
					Found = false;
				}
			}
		}
		return val;
	}	

	// Adjust text for caption
	public static string ewr_BtnCaption(string Caption) {
		int Min = 10;
		int Ln = Caption.Length;
		if (Ln < Min) {
			int Pad = Math.Abs(Conversion.Int((Min - Ln) / 2 * -1));
			return Caption.PadLeft(Ln + Pad).PadRight(Ln + Pad * 2);
		} else {
			return Caption;
		}
	}	

	//
	// Security shortcut functions
	//
	// Get current user name
	public static string CurrentUserName() {
		return Convert.ToString(ewr_Session[EWR_SESSION_USER_NAME]);
	}

	// Get current user ID
	public static string CurrentUserID() {
		return Convert.ToString(ewr_Session[EWR_SESSION_USER_ID]);
	}

	// Get current parent user ID
	public static string CurrentParentUserID() {
		return Convert.ToString(ewr_Session[EWR_SESSION_PARENT_USER_ID]);
	}

	// Get current user level
	public static int CurrentUserLevel() {
		return Convert.ToInt32(ewr_Session[EWR_SESSION_USER_LEVEL_ID]);
	}

	// Get current page ID
	public static string CurrentPageID() {
		return (CurrentPage != null) ? CurrentPage.PageID : "";
	}	

	// Check if user password expired
	public static bool IsPasswordExpired() {
		return ewr_SameStr(ewr_Session[EWR_SESSION_STATUS], "passwordexpired");
	}

	// Check if user is logging in (after changing password)
	public static bool IsLoggingIn() {
		return ewr_SameStr(ewr_Session[EWR_SESSION_STATUS], "loggingin");
	}	

	// Is Logged In
	public static bool IsLoggedIn() {
		return ewr_SameStr(ewr_Session[EWR_SESSION_STATUS], "login");
	}

	// Is System Admin
	public static bool IsSysAdmin() {
		return (ewr_ConvertToInt(ewr_Session[EWR_SESSION_SYS_ADMIN]) == 1);
	}

	// Get current project ID
	public static string CurrentProjectID() {
		if (CurrentPage != null)
			return CurrentPage.ProjectID;
		return EWR_PROJECT_ID;
	}

	// Get WebMatrix.Data.Database (Note: Does not work with Npgsql)
	public static Database ewr_Database() {
		return Database.OpenConnectionString(EWR_DB_CONNECTION_STRING, EWR_DB_PROVIDER_NAME);
	}

	// Get IEnumerable<Object> using WebMatrix.Data.Database.Query
	public static IEnumerable<Object> ewr_Query(string commandText, params Object[] parameters) {
		var db = ewr_Database();
		return (db != null) ? db.Query(commandText, parameters) : null;
	}	

	// Encrypt
	public static string ewr_Encrypt(object Data, string Key = EWR_RANDOM_KEY) {	
		if (ewr_Empty(Data))
			return "";
		byte[] Results = {};
		try {
			System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();
			MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
			byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Key));
			TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
			TDESAlgorithm.Key = TDESKey;
			TDESAlgorithm.Mode = CipherMode.ECB;
			TDESAlgorithm.Padding = PaddingMode.PKCS7;		
			try {
				byte[] DataToEncrypt = UTF8.GetBytes(Convert.ToString(Data));
				ICryptoTransform Encryptor = TDESAlgorithm.CreateEncryptor();
				Results = Encryptor.TransformFinalBlock(DataToEncrypt, 0, DataToEncrypt.Length);
			} finally {                
				TDESAlgorithm.Clear();
				HashProvider.Clear();
			}
		} catch {}
		return Convert.ToBase64String(Results).Replace("+", "_2B").Replace("/", "_2F").Replace("=", "_2E");		
	}

	// Decrypt
	public static string ewr_Decrypt(object Data, string Key = EWR_RANDOM_KEY) {
		if (ewr_Empty(Data))
			return "";
		byte[] Results = {};
		System.Text.UTF8Encoding UTF8 = new System.Text.UTF8Encoding();
		try {			
			MD5CryptoServiceProvider HashProvider = new MD5CryptoServiceProvider();
			byte[] TDESKey = HashProvider.ComputeHash(UTF8.GetBytes(Key));
			TripleDESCryptoServiceProvider TDESAlgorithm = new TripleDESCryptoServiceProvider();
			TDESAlgorithm.Key = TDESKey;
			TDESAlgorithm.Mode = CipherMode.ECB;
			TDESAlgorithm.Padding = PaddingMode.PKCS7;
			string sData = Convert.ToString(Data).Replace("_2B", "+").Replace("_2F", "/").Replace("_2E", "=");		
			try {
				byte[] DataToDecrypt = Convert.FromBase64String(sData);
				ICryptoTransform Decryptor = TDESAlgorithm.CreateDecryptor();
				Results = Decryptor.TransformFinalBlock(DataToDecrypt, 0, DataToDecrypt.Length);
			} finally {
				TDESAlgorithm.Clear();
				HashProvider.Clear();
			}
		} catch {}
		return UTF8.GetString(Results);
	}	

	// Get image content type
	public static string ewr_GetImageContentType(string fn) {	
		string ext = Path.GetExtension(fn).Replace(".", "").ToLower();
		if (ext == "gif") { // gif
			return "image/gif";
		} else if (ext == "jpg" || ext == "jpeg" || ext == "jpe") { // jpg
			return "image/jpeg";
		} else if (ext == "png") { // png
			return "image/png";
		} else {
			return "image/bmp";
		}
	}

	// Read global debug message
	public static string ewr_DebugMsg() {
		string msg = (ewr_NotEmpty(gsDebugMsg)) ? "<p>" + gsDebugMsg + "</p>" : "";
		gsDebugMsg = "";
		return msg;
	}

	// Write global debug message
	public static void ewr_SetDebugMsg(string v) {
		if (ewr_NotEmpty(gsDebugMsg))
			gsDebugMsg += "<br>";
		gsDebugMsg += v;
	}

	//
	//  Language class
	//
	public class crLanguage : IDisposable {

		public string LanguageId;

		public XmlDocument objDOM;

		public Dictionary<string, string> Col; // Note: key is case-insensitive.

		public string LanguageFolder = EWR_LANGUAGE_FOLDER;		

		// Constructor
		public crLanguage(string langfolder = "", string langid = "")
		{
			if (ewr_NotEmpty(langfolder))
				LanguageFolder = langfolder;

			// Set up file list
			LoadFileList();

			// Set up language id
			if (ewr_NotEmpty(langid)) { // Set up language id
				LanguageId = langid;
				ewr_Session[EWR_SESSION_LANGUAGE_ID] = LanguageId;
			} else if (ewr_NotEmpty(ewr_Get("language"))) {
				LanguageId = ewr_Get("language");
				ewr_Session[EWR_SESSION_LANGUAGE_ID] = LanguageId;
			} else if (ewr_NotEmpty(ewr_Session[EWR_SESSION_LANGUAGE_ID])) {
				LanguageId = Convert.ToString(ewr_Session[EWR_SESSION_LANGUAGE_ID]);
			} else {
				LanguageId = EWR_LANGUAGE_DEFAULT_ID;
			}
			gsLanguage = LanguageId;
			Load(LanguageId);
		}

		// Terminate
		public void Dispose()
		{
			objDOM = null;
		}

		// Load language file list
		private void LoadFileList()
		{
			if (ewr_IsList(EWR_LANGUAGE_FILE)) {
				for (int i = 0; i < EWR_LANGUAGE_FILE.Count; i++)
					EWR_LANGUAGE_FILE[i][1] = LoadFileDesc(ewr_MapPath(LanguageFolder + EWR_LANGUAGE_FILE[i][2]));
			}
		}

		// Load language file description
		private string LoadFileDesc(string File)
		{
			var xmlr = new XmlTextReader(File);
			xmlr.WhitespaceHandling = WhitespaceHandling.None;
			try {
				while (!xmlr.EOF) {
					xmlr.Read();
					if (xmlr.IsStartElement() && xmlr.Name == "ew-language")
						return xmlr.GetAttribute("desc");
				}
			} finally {
				xmlr.Close();
			}
			return "";
		}

		// Load language file
		private void Load(string id)
		{
			string sFileName = GetFileName(id);
			if (ewr_Empty(sFileName))
				sFileName = GetFileName(EWR_LANGUAGE_DEFAULT_ID);
			if (ewr_Empty(sFileName)) return; 
			if (EWR_USE_DOM_XML) {
				objDOM = new XmlDocument();
				objDOM.Load(sFileName);
			} else {
				if (ewr_Session[EWR_PROJECT_NAME + "_" + sFileName] != null) {
					Col = (Dictionary<string, string>)ewr_Session[EWR_PROJECT_NAME + "_" + sFileName];
				} else {
					Col = new Dictionary<string, string>();
					XmlToCollection(sFileName);
					ewr_Session[EWR_PROJECT_NAME + "_" + sFileName] = Col;
				}
			}

			// Set up locale / currency format for language
			EWR_USE_SYSTEM_LOCALE = LocalePhrase("use_system_locale") != "0";
			if (!EWR_USE_SYSTEM_LOCALE) {
				string decimal_point = LocalePhrase("decimal_point");	
				if (ewr_NotEmpty(decimal_point))
					EWR_DECIMAL_POINT = decimal_point;
				string thousands_sep = LocalePhrase("thousands_sep");
				EWR_THOUSANDS_SEP = thousands_sep;
				string currency_symbol = LocalePhrase("currency_symbol");
				if (ewr_NotEmpty(currency_symbol))
					EWR_CURRENCY_SYMBOL = currency_symbol;
			}
		}

		// Convert XML to Collection
		private void XmlToCollection(string File)
		{
			string Key = "/";
			var OldKey = new List<string>();
			int Index;
			var xmlr = new XmlTextReader(File);
			xmlr.WhitespaceHandling = WhitespaceHandling.None;
			try {
				while (!xmlr.EOF) {
					xmlr.Read();
					string Name = xmlr.Name;
					string Id = xmlr.GetAttribute("id");
					if (Name == "ew-language")
						continue; 
					switch (xmlr.NodeType) {
						case XmlNodeType.Element:
							if (xmlr.IsStartElement() && !xmlr.IsEmptyElement) {
								OldKey.Add(Key);
								Key += Name + "/";
								if (Id != null)
									Key += Id + "/"; 
							}
							if (Id != null && xmlr.IsEmptyElement) { // phrase
								Id = Name + "/" + Id;
								if (xmlr.GetAttribute("client") == "1")
									Id += "/1"; 
								if (Id != null)
									Col[Key + Id] = xmlr.GetAttribute("value"); 
							}
							break;
						case XmlNodeType.EndElement:
							Key = OldKey.Last();
							OldKey.RemoveAt(OldKey.Count - 1);								
							break;
					}
				}
			} finally {
				xmlr.Close();
			}
		}

		// Get language file name
		private string GetFileName(string Id)
		{
			if (ewr_IsList(EWR_LANGUAGE_FILE)) {
				foreach (string[] langfile in EWR_LANGUAGE_FILE) {
					if (langfile[0] == Id)
						return ewr_MapPath(LanguageFolder + langfile[2]);
				}
			}
			return "";
		}

		// Get node attribute
		private string GetNodeAtt(XmlNode Node, string Att)
		{
			if (Node != null) {
				return ((XmlElement)Node).GetAttribute(Att);
			} else {
				return "";
			}
		}

		// Set node attribute
		private void SetNodeAtt(XmlNode Node, string Att, string Value)
		{
			if (Node != null)
				((XmlElement)Node).SetAttribute(Att, Value);
		}

		// Get phrase
		public string LocalePhrase(string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//locale/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/locale/phrase/" + Id)) {
					return Col["/locale/phrase/" + Id];
				} else if (Col.ContainsKey("/locale/phrase/" + Id + "/1")) {
					return Col["/locale/phrase/" + Id + "/1"];
				} else {
					return "";
				}
			}
		}

		// Set phrase
		public void SetLocalePhrase(string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//locale/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				if (Col.ContainsKey("/locale/phrase/" + Id)) {
					Col["/locale/phrase/" + Id] = Value;
				} else if (Col.ContainsKey("/locale/phrase/" + Id + "/1")) {
					Col["/locale/phrase/" + Id + "/1"] = Value;
				}
			}
		}

		// Get phrase
		public string Phrase(string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//global/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/global/phrase/" + Id)) {
					return Col["/global/phrase/" + Id];
				} else if (Col.ContainsKey("/global/phrase/" + Id + "/1")) {
					return Col["/global/phrase/" + Id + "/1"];
				} else {
					return "";
				}
			}
		}

		// Set phrase
		public void SetPhrase(string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//global/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				if (Col.ContainsKey("/global/phrase/" + Id)) {
					Col["/global/phrase/" + Id] = Value;
				} else if (Col.ContainsKey("/global/phrase/" + Id + "/1")) {
					Col["/global/phrase/" + Id + "/1"] = Value;
				}
			}
		}

		// Get project phrase
		public string ProjectPhrase(string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/project/phrase/" + Id))
					return Col["/project/phrase/" + Id];
				return "";
			}
		}

		// Set project phrase
		public void SetProjectPhrase(string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/phrase[@id='" + Id + "']"), "value", Value);
			} else {				
				Col["/project/phrase/" + Id] = Value;
			}
		}

		// Get menu phrase
		public string MenuPhrase(string MenuId, string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/menu[@id='" + MenuId.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/project/menu/" + MenuId.ToLower() + "/phrase/" + Id))
					return Col["/project/menu/" + MenuId.ToLower() + "/phrase/" + Id];
				return "";
			}
		}

		// Set menu phrase
		public void SetMenuPhrase(string MenuId, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/menu[@id='" + MenuId.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				Col["/project/menu/" + MenuId.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Get table phrase
		public string TablePhrase(string TblVar, string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/project/table/" + TblVar.ToLower() + "/phrase/" + Id))
					return Col["/project/table/" + TblVar.ToLower() + "/phrase/" + Id];
				return "";
			}
		}

		// Set table phrase
		public void SetTablePhrase(string TblVar, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);
			} else {
				Col["/project/table/" + TblVar.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Get chart phrase
		public string ChartPhrase(string TblVar, string FldVar, string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/chart[@id='" + FldVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/project/table/" + TblVar.ToLower() + "/chart/" + FldVar.ToLower() + "/phrase/" + Id))
					return Col["/project/table/" + TblVar.ToLower() + "/chart/" + FldVar.ToLower() + "/phrase/" + Id];
				return "";
			}
		}

		// Set chart phrase
		public void SetChartPhrase(string TblVar, string FldVar, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/chart[@id='" + FldVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);	
			} else {
				Col["/project/table/" + TblVar.ToLower() + "/chart/" + FldVar.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Get field phrase
		public string FieldPhrase(string TblVar, string FldVar, string Id)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				return GetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/field[@id='" + FldVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value");
			} else {
				if (Col.ContainsKey("/project/table/" + TblVar.ToLower() + "/field/" + FldVar.ToLower() + "/phrase/" + Id))
					return Col["/project/table/" + TblVar.ToLower() + "/field/" + FldVar.ToLower() + "/phrase/" + Id];
				return "";
			}
		}

		// Set field phrase
		public void SetFieldPhrase(string TblVar, string FldVar, string Id, string Value)
		{
			Id = Id.ToLower();
			if (EWR_USE_DOM_XML) {
				SetNodeAtt(objDOM.SelectSingleNode("//project/table[@id='" + TblVar.ToLower() + "']/field[@id='" + FldVar.ToLower() + "']/phrase[@id='" + Id + "']"), "value", Value);	
			} else {
				Col["/project/table/" + TblVar.ToLower() + "/field/" + FldVar.ToLower() + "/phrase/" + Id] = Value;
			}
		}

		// Output XML as JSON
		public string XmlToJSON(string XPath)
		{
			XmlNodeList NodeList = objDOM.SelectNodes(XPath);
			string Str = "{";
			foreach (XmlNode Node in NodeList) {
				string Id = GetNodeAtt(Node, "id");
				string Value = GetNodeAtt(Node, "value");
				Str += "\"" + ewr_JsEncode2(Id) + "\":\"" + ewr_JsEncode2(Value) + "\",";
			}
			if (Str.EndsWith(","))
				Str = Str.Substring(0, Str.Length - 1); 
			Str += "}\r\n";
			return Str;
		}

		// Output collection as JSON
		public string CollectionToJSON(string Prefix, string Suffix)
		{
			string Id;
			int Pos;
			string Str = "{";
			foreach (string Name in Col.Keys) {
				if (Name.StartsWith(Prefix)) {
					if (ewr_NotEmpty(Suffix) && Name.EndsWith(Suffix)) {
						Pos = Name.LastIndexOf(Suffix);
						Id = Name.Substring(Prefix.Length, Pos - Prefix.Length);
					} else {
						Id = Name.Substring(Prefix.Length);
					}
					Str += "\"" + ewr_JsEncode2(Id) + "\":\"" + ewr_JsEncode2(Col[Name]) + "\",";
				}
			}
			if (Str.EndsWith(","))
				Str = Str.Substring(0, Str.Length - 1); 
			Str += "}\r\n";
			return Str;
		}

		// Output all phrases as JSON
		public string AllToJSON()
		{
			if (EWR_USE_DOM_XML) {
				return "var ewLanguage = new ewr_Language(" + XmlToJSON("//global/phrase") + ");";
			} else {
				return "var ewLanguage = new ewr_Language(" + CollectionToJSON("/global/phrase/", "") + ");";
			}
		}

		// Output client phrases as JSON
		public string ToJSON()
		{
			if (EWR_USE_DOM_XML) {
				return "var ewLanguage = new ewr_Language(" + XmlToJSON("//global/phrase[@client='1']") + ");";
			} else {
				return "var ewLanguage = new ewr_Language(" + CollectionToJSON("/global/phrase/", "/1") + ");";
			}
		}
	}

	//
	//  XML document class
	//
	public class crXMLDocument : IDisposable
	{

		public string Encoding = "";

		public string RootTagName = "table";

		public string SubTblName = "";

		public string RowTagName = "row";

		public XmlDocument XmlDoc;

		public XmlElement XmlTbl;

		public XmlElement XmlSubTbl;

		public XmlElement XmlRow;

		public XmlElement XmlFld;

		// Constructor
		public crXMLDocument()
		{
			XmlDoc = new XmlDocument();
		}

		public XmlDocument Load(string phyfile) {
			if (File.Exists(phyfile)) {
				XmlDoc.Load(phyfile);
				return XmlDoc;
			}
			return null;
		}

		public XmlElement DocumentElement {
			get {
				return (XmlDoc != null) ? XmlDoc.DocumentElement : null;
			}
		}

		public string GetAttribute(XmlElement element, string name) {
			return (element != null) ? element.GetAttribute(name) : "";
		}

		public void SetAttribute(XmlElement element, string name, object value) {
			if (element != null)
				element.SetAttribute(name, Convert.ToString(value));
	    }

		// Create XML element // AXR
		public XmlElement CreateElement(string name) {
			return XmlDoc.CreateElement(name);
		}

		// Get elements by tag name // AXR
		public XmlNodeList GetElementsByTagName(string name) {
			return XmlDoc.GetElementsByTagName(name);
		}

		// Append XML element to target element // AXR
		public void AppendChild(XmlElement parent, XmlElement child) {
			if (parent != null && child != null)
				parent.AppendChild(child);
		}

		// Append XML element to root // AXR
		public void AppendChildToRoot(XmlElement child) {
			AppendChild(XmlTbl, child);
		}

		// Set attribute // AXR
		public void SetAttribute(XmlElement element, DictionaryEntry kvp) {
			if (element != null)
				element.SetAttribute(Convert.ToString(kvp.Key), Convert.ToString(kvp.Value));
		}

		// Set attribute // AXR
		public void SetAttribute(XmlElement element, KeyValuePair<string, object> kvp) {
			if (element != null)
				element.SetAttribute(kvp.Key, Convert.ToString(kvp.Value));
		}

		public XmlElement SelectSingleNode(string query) {
			var node = XmlDoc.SelectSingleNode(query);
			return (node != null) ? (XmlElement)node : null;
		}

		public XmlNodeList SelectNodes(string query) {
			return XmlDoc.SelectNodes(query);
		}

		// Add root
		public void AddRoot(string rootname)
		{
			RootTagName = ewr_XmlTagName(rootname);
			XmlTbl = XmlDoc.CreateElement(RootTagName);
			XmlDoc.AppendChild(XmlTbl);
		}

		// Add row
		public void AddRow(string tablename = "", string rowname = "")
		{
			if (ewr_NotEmpty(rowname))
				RowTagName = ewr_XmlTagName(rowname);
			XmlRow = XmlDoc.CreateElement(RowTagName);
			if (ewr_Empty(tablename)) {
				if (XmlTbl != null)
					XmlTbl.AppendChild(XmlRow);
			} else {
				if (ewr_Empty(SubTblName)) {
					SubTblName = ewr_XmlTagName(tablename);
					XmlSubTbl = XmlDoc.CreateElement(SubTblName);
					XmlTbl.AppendChild(XmlSubTbl);
				}
				if (XmlSubTbl != null)
					XmlSubTbl.AppendChild(XmlRow);
			}
		}

		// Add row by name
		public void AddRowEx(string Name)
		{
			XmlRow = XmlDoc.CreateElement(Name);
			XmlTbl.AppendChild(XmlRow);
		}

		// Add field
		public void AddField(string name, object value)
		{
			XmlFld = XmlDoc.CreateElement(ewr_XmlTagName(name));
			XmlRow.AppendChild(XmlFld);
			XmlFld.AppendChild(XmlDoc.CreateTextNode(Convert.ToString(value)));
		}

		// XML
		public string XML()
		{
			return XmlDoc.OuterXml;
		}

		// Output
		public void Output()
		{
			ewr_Response.Clear(); 
			ewr_Response.ContentType = "text/xml";
			string PI = "<?xml version=\"1.0\"";
			if (ewr_NotEmpty(Encoding))
				PI += " encoding=\"" + Encoding + "\"";
			PI += " ?>";
			ewr_Write(PI + XmlDoc.OuterXml);
		}

		// Output XML for debug
		public void Print()
		{
			ewr_Response.Clear(); 
			ewr_Response.ContentType = "text/plain";
			ewr_Write(ewr_HtmlEncode(XmlDoc.OuterXml));
		}

		// Terminate
		public void Dispose()
		{
			XmlFld = null;
			XmlRow = null;
			XmlTbl = null;
			XmlDoc = null;
		}
	}

	//
	// Email class
	//
	public class crEmail
	{

		public string Sender = ""; // Sender		

		public string Recipient = ""; // Recipient		

		public string Cc = ""; // Cc		

		public string Bcc = ""; // Bcc		

		public string Subject = ""; // Subject		

		public string Format = ""; // Format		

		public string Content = ""; // Content

		public string AttachmentContent = ""; // Attachement content

		public string AttachmentFileName = ""; // Attachment file name

		public List<string> EmbeddedImages = new List<string>(); // Embedded image

		public string Charset = ""; // Charset

		public string SendErrNumber = ""; // Send error number

		public string SendErrDescription = ""; // Send error description

		public bool EnableSsl = ewr_SameText(EWR_SMTP_SECURE_OPTION, "SSL"); // Send secure option

		// Load email from template
		public void Load(string fn)
		{
			string sWrk = ewr_LoadTxt(fn);

			// Load text file content
			sWrk = sWrk.Replace("\r\n", "\n");

			// Convert to Lf
			sWrk = sWrk.Replace("\r", "\n");

			// Convert to Lf
			if (ewr_NotEmpty(sWrk)) {
				int i = sWrk.IndexOf("\n" + "\n");

				// Locate header and mail content
				if (i > 0) {
					string sHeader = sWrk.Substring(0, i + 1);
					Content = sWrk.Substring(i + 2);
					string[] arrHeader = sHeader.Split(new char[] {'\n'});
					for (int j = 0; j <= arrHeader.GetUpperBound(0); j++) {
						i = arrHeader[j].IndexOf(":");
						if (i > 0) {
							string sName = arrHeader[j].Substring(0, i).Trim();
							string sValue = arrHeader[j].Substring(i + 1).Trim();
							switch (sName.ToLower()) {
								case "subject":
									Subject = sValue;
									break;
								case "from":
									Sender = sValue;
									break;
								case "to":
									Recipient = sValue;
									break;
								case "cc":
									Cc = sValue;
									break;
								case "bcc":
									Bcc = sValue;
									break;
								case "format":
									Format = sValue;
									break;
							}
						}
					}
				}
			}
		}

		// Replace sender
		public void ReplaceSender(string ASender)
		{
			Sender = Sender.Replace("<!--$From-->", ASender);
		}

		// Replace recipient
		public void ReplaceRecipient(string ARecipient)
		{
			Recipient = Recipient.Replace("<!--$To-->", ARecipient);
		}

		// Add cc email
		public void AddCc(string ACc)
		{
			if (ewr_NotEmpty(ACc)) {
				if (ewr_NotEmpty(Cc)) Cc = Cc + ";"; 
				Cc = Cc + ACc;
			}
		}

		// Add bcc email
		public void AddBcc(string ABcc)
		{
			if (ewr_NotEmpty(ABcc)) {
				if (ewr_NotEmpty(Bcc)) Bcc = Bcc + ";"; 
				Bcc = Bcc + ABcc;
			}
		}

		// Replace subject
		public void ReplaceSubject(string ASubject)
		{
			Subject = Subject.Replace("<!--$Subject-->", ASubject);
		}

		// Replace content
		public void ReplaceContent(string Find, string ReplaceWith)
		{
			Content = Content.Replace(Find, ReplaceWith);
		}

		// Method to add embedded image
		public void AddEmbeddedImage(string image) {
			if (ewr_NotEmpty(image))
				EmbeddedImages.Add(image);
		}

		// Send email
		public bool Send()
		{
			bool bSend = ewr_SendEmail(Sender, Recipient, Cc, Bcc, Subject, Content, Format, Charset, EnableSsl, AttachmentFileName, AttachmentContent, EmbeddedImages);
			if (!bSend)
				SendErrDescription = gsEmailErrDesc; // Send error description
			return bSend;
		}
	}

	//
	// Class for Pager item
	//
	public class crPagerItem
	{

		public string Text;

		public int Start;

		public bool Enabled;

		// Constructor
		public crPagerItem(int AStart, string AText, bool AEnabled)
		{
			Text = AText;
			Start = AStart;
			Enabled = AEnabled;
		}

		// Constructor
		public crPagerItem()
		{

			// Do nothing
		}
	}

	//
	// Class for PrevNext pager
	//
	public class crPager
	{

		public crPagerItem NextButton;

		public crPagerItem FirstButton;

		public crPagerItem PrevButton;

		public crPagerItem LastButton;

		public int PageSize;		

		public int FromIndex;

		public int ToIndex;

		public int RecordCount;

		public bool Visible;
	}

	//
	// Class for Numeric pager
	//
	public class crNumericPager : crPager
	{

		public List<crPagerItem> Items = new List<crPagerItem>();

		public int Count;

		public int Range;

		public int ButtonCount;

		// Constructor
		public crNumericPager(int AFromIndex, int APageSize, int ARecordCount, int ARange)
		{
			FromIndex = AFromIndex;
			PageSize = APageSize;
			RecordCount = ARecordCount;
			Range = ARange;
			FirstButton = new crPagerItem();
			PrevButton = new crPagerItem();
			NextButton = new crPagerItem();
			LastButton = new crPagerItem();
			Visible = true;
			Init();
		}

		// Init pager
		public void Init()
		{
			if (FromIndex > RecordCount) FromIndex = RecordCount; 
			ToIndex = FromIndex + PageSize - 1;
			if (ToIndex > RecordCount) ToIndex = RecordCount; 
			Count = 0;
			SetupNumericPager();

			// Update button count
			ButtonCount = Count + 1;
			if (FirstButton.Enabled) ButtonCount = ButtonCount + 1; 
			if (PrevButton.Enabled) ButtonCount = ButtonCount + 1; 
			if (NextButton.Enabled) ButtonCount = ButtonCount + 1; 
			if (LastButton.Enabled) ButtonCount = ButtonCount + 1; 
		}

		// Add pager item
		private void AddPagerItem(int StartIndex, string Text, bool Enabled)
		{
			Items.Add(new crPagerItem(StartIndex, Text, Enabled));
			Count = Items.Count;
		}

		// Setup pager items
		private void SetupNumericPager()
		{
			bool HasPrev;
			bool NoNext;
			int dy2;
			int dx2;
			int y;
			int x;
			int dx1;
			int dy1;
			int ny;
			int TempIndex;
			if (RecordCount > PageSize) {
				NoNext = (RecordCount < (FromIndex + PageSize));
				HasPrev = (FromIndex > 1);

				// First Button
				TempIndex = 1;
				FirstButton.Start = TempIndex;
				FirstButton.Enabled = (FromIndex > TempIndex);

				// Prev Button
				TempIndex = FromIndex - PageSize;
				if (TempIndex < 1) TempIndex = 1; 
				PrevButton.Start = TempIndex;
				PrevButton.Enabled = HasPrev;

				// Page links
				if (HasPrev | !NoNext) {
					x = 1;
					y = 1;
					dx1 = ((FromIndex - 1) / (PageSize * Range)) * PageSize * Range + 1;
					dy1 = ((FromIndex - 1) / (PageSize * Range)) * Range + 1;
					if ((dx1 + PageSize * Range - 1) > RecordCount) {
						dx2 = (RecordCount / PageSize) * PageSize + 1;
						dy2 = (RecordCount / PageSize) + 1;
					} else {
						dx2 = dx1 + PageSize * Range - 1;
						dy2 = dy1 + Range - 1;
					}
					while (x <= RecordCount) {
						if (x >= dx1 & x <= dx2) {
							AddPagerItem(x, Convert.ToString(y), FromIndex != x);
							x = x + PageSize;
							y = y + 1;
						}
else if (x >= (dx1 - PageSize * Range) & x <= (dx2 + PageSize * Range)) {
							if (x + Range * PageSize < RecordCount) {
								AddPagerItem(x, y + "-" + (y + Range - 1), true);
							} else {
								ny = (RecordCount - 1) / PageSize + 1;
								if (ny == y) {
									AddPagerItem(x, Convert.ToString(y), true);
								} else {
									AddPagerItem(x, y + "-" + ny, true);
								}
							}
							x = x + Range * PageSize;
							y = y + Range;
						} else {
							x = x + Range * PageSize;
							y = y + Range;
						}
					}
				}

				// Next Button
				NextButton.Start = FromIndex + PageSize;
				TempIndex = FromIndex + PageSize;
				NextButton.Start = TempIndex;
				NextButton.Enabled = !NoNext;

				// Last Button
				TempIndex = ((RecordCount - 1) / PageSize) * PageSize + 1;
				LastButton.Start = TempIndex;
				LastButton.Enabled = (FromIndex < TempIndex);
			}
		}
	}

	//
	// Class for PrevNext pager
	//
	public class crPrevNextPager : crPager
	{

		public int PageCount;

		public int CurrentPage;

		// Constructor
		public crPrevNextPager(int AFromIndex, int APageSize, int ARecordCount)
		{
			FromIndex = AFromIndex;
			PageSize = APageSize;
			RecordCount = ARecordCount;
			FirstButton = new crPagerItem();
			PrevButton = new crPagerItem();
			NextButton = new crPagerItem();
			LastButton = new crPagerItem();
			Visible = true;
			Init();
		}

		// Method to init pager
		public void Init()
		{
			int TempIndex;
			if (PageSize > 0) {
				CurrentPage = (FromIndex - 1) / PageSize + 1;
				PageCount = (RecordCount - 1) / PageSize + 1;
				if (FromIndex > RecordCount) FromIndex = RecordCount; 
				ToIndex = FromIndex + PageSize - 1;
				if (ToIndex > RecordCount) ToIndex = RecordCount; 

				// First Button
				TempIndex = 1;
				FirstButton.Start = TempIndex;
				FirstButton.Enabled = (TempIndex != FromIndex);

				// Prev Button
				TempIndex = FromIndex - PageSize;
				if (TempIndex < 1) TempIndex = 1; 
				PrevButton.Start = TempIndex;
				PrevButton.Enabled = (TempIndex != FromIndex);

				// Next Button
				TempIndex = FromIndex + PageSize;
				if (TempIndex > RecordCount) TempIndex = FromIndex; 
				NextButton.Start = TempIndex;
				NextButton.Enabled = (TempIndex != FromIndex);

				// Last Button
				TempIndex = ((RecordCount - 1) / PageSize) * PageSize + 1;
				LastButton.Start = TempIndex;
				LastButton.Enabled = (TempIndex != FromIndex);
			}
		}
	}

	//
	// Table base class
	//
	public class crTableBase {

		public string TableVar = "";

		public string TableName = "";

		public string TableType = "";

		private string _TableCaption = "";

		public bool ShowCurrentFilter = EWR_SHOW_CURRENT_FILTER;

		public bool ShowDrillDownFilter = EWR_SHOW_DRILLDOWN_FILTER;

		public bool UseDrillDownPanel = EWR_USE_DRILLDOWN_PANEL; // Use drill down panel

		public string CurrentOrder = ""; // Current order

		public string CurrentOrderType = ""; // Current order type	

		// Table caption
		public string TableCaption {
			get {
				if (ewr_NotEmpty(_TableCaption))
					return _TableCaption;
				else
					return ReportLanguage.TablePhrase(TableVar, "TblCaption");
			}
			set { _TableCaption = value; }
		}

		// Group Per Page
		public int GroupPerPage { // AXR
			get {
				var gpp = ewr_Session[EWR_PROJECT_VAR + "_" + TableVar + "_grpperpage"];
				return (gpp != null) ? ewr_ConvertToInt(gpp) : -2; // -2 => use default
			}
			set { ewr_Session[EWR_PROJECT_VAR + "_" + TableVar + "_grpperpage"] = value; }
		}	

		// Start Group
		public int StartGroup {
			get { return ewr_ConvertToInt(ewr_Session[EWR_PROJECT_VAR + "_" + TableVar + "_start"]); }
			set { ewr_Session[EWR_PROJECT_VAR + "_" + TableVar + "_start"] = value; }
		}	

		// Order By
		public string OrderBy {
			get { return Convert.ToString(ewr_Session[EWR_PROJECT_VAR + "_" + TableVar + "_orderby"]); }
			set { ewr_Session[EWR_PROJECT_VAR + "_" + TableVar + "_orderby"] = value; }
		}

		public Dictionary<string, crField> Fields = new Dictionary<string, crField>();

		public string Export = ""; // Export

		public bool ExportAll;

		public int ExportPageBreakCount = 1; // Export page break count

		public bool ExportChartPageBreak = true; // Page break for chart when export

		public string PageBreakContent = "<div class=\"ewPageBreak\">&nbsp;</div>"; // Page break content

		public bool UseTokenInUrl = EWR_USE_TOKEN_IN_URL;

		public int RowType; // Row type

		public int RowTotalType; // Row total type

		public int RowTotalSubType; // Row total subtype

		public int RowGroupLevel; // Row group level

		public Dictionary<string, string> RowAttrs = new Dictionary<string, string>(); // ASPX

		// Reset attributes for table object
		public void ResetAttrs() {
	    	RowAttrs.Clear();
			foreach (var kvp in Fields)
				kvp.Value.ResetAttrs();
		}		

		// Row Attributes
		public string RowAttributes {
			get {
				string sAtt = "";
				foreach (var Attr in RowAttrs)
					sAtt += " " + Attr.Key + "=\"" + Attr.Value.Trim() + "\"";
				return sAtt;
			}
		}

		// Get field object by name
		public crField FieldByName(string Name) {
			if (Fields.ContainsKey(Name))
				return Fields[Name];			
			return null;
		}
	}

	// class for crosstab
	public class crTableCrosstab : crTableBase {

		// Summary cells
		public List<Dictionary<string, string>> SummaryCellAttrs = new List<Dictionary<string, string>>();

		public List<Dictionary<string, string>> SummaryViewAttrs = new List<Dictionary<string, string>>();

		public List<Dictionary<string, string>> SummaryLinkAttrs = new List<Dictionary<string, string>>();

		public object[] SummaryCurrentValue;

		public string[] SummaryViewValue;

		// Summary cell attributes
		public string SummaryCellAttributes(int i) {
			string sAtt = "";
			foreach (var Attrs in SummaryCellAttrs) {
				foreach (var kvp in Attrs) {
					if (ewr_NotEmpty(kvp.Value))
						sAtt += " " + kvp.Key + "=\"" + Convert.ToString(kvp.Value).Trim() + "\"";
				}
			}
			return sAtt;
		}

		// Summary view attributes
		public string SummaryViewAttributes(int i) {
			string sAtt = "";
			foreach (var Attrs in SummaryViewAttrs) {
				foreach (var kvp in Attrs) {
					if (ewr_NotEmpty(kvp.Value))
						sAtt += " " + kvp.Key + "=\"" + Convert.ToString(kvp.Value).Trim() + "\"";
				}
			}
			return sAtt;
		}

		// Summary link attributes
		public string SummaryLinkAttributes(int i) {
			string sAtt = "";
			foreach (var Attrs in SummaryViewAttrs) {
				foreach (var kvp in Attrs) {
					if (ewr_NotEmpty(kvp.Value))
						sAtt += " " + kvp.Key + "=\"" + Convert.ToString(kvp.Value).Trim() + "\"";
				}
				if (Attrs.ContainsKey("onclick") && ewr_NotEmpty(Attrs["onclick"]) && ewr_Empty(Attrs["href"]))
					sAtt += " href=\"javascript:void(0);\"";
			}
			return sAtt;
		}
	}

	//
	// Field class
	//
	public class crField {

		public string TblName; // Table name

		public string TblVar; // Table variable name

		public string FldName; // Field name

		public string FldVar; // Field variable name

		public string FldExpression; // Field expression (used in SQL)

		public string FldDefaultErrMsg; // Default error message

		public int FldType; // Field type

		public int FldDataType; // ASP.NET Maker Field type

		public int FldDateTimeFormat; // Date time format

		public int Count; // Count

		public object SumValue; // Sum

		public object AvgValue; // Average

		public object MinValue; // Minimum

		public object MaxValue; // Maximum

		public object CntValue; // Count

		public string SumViewValue; // Sum

		public string AvgViewValue; // Average

		public string MinViewValue; // Minimum

		public string MaxViewValue; // Maximum

		public string CntViewValue; // Count

		public object OldValue; // Old Value

		public object CurrentValue; // Current value

		public string ViewValue; // View value

		public string HrefValue; // Href value

		public string m_FormValue; // Form value

		public string m_QueryStringValue; // QueryString value

		public object m_DbValue; // Database value		

		public string DrillDownUrl = ""; // Drill down URL

		public string CurrentFilter = ""; // Current filter in use

		public int ImageWidth = 0; // Image width

		public int ImageHeight = 0; // Image height

		public bool ImageResize = false; // Image resize

		public bool Sortable = true; // Sortable

		public int GroupingFieldId = 0; // Grouping field id

		public string UploadPath = EWR_UPLOAD_DEST_PATH; // Upload path // AXR		

		public bool TruncateMemoRemoveHtml = false; // Remove HTML from memo field 		

		public int DefaultDecimalPrecision = EWR_DEFAULT_DECIMAL_PRECISION;

		public Dictionary<string, string> CellAttrs = new Dictionary<string, string>(); // Cell custom attributes

		public Dictionary<string, string> ViewAttrs = new Dictionary<string, string>(); // View custom attributes

		public Dictionary<string, string> LinkAttrs = new Dictionary<string, string>(); // Href attributes

		public Dictionary<string, string> EditAttrs = new Dictionary<string, string>(); // Edit attributes

		public string FldGroupByType; // Group By Type

		public string FldGroupInt; // Group Interval

		public string FldGroupSql; // Group SQL

		public Hashtable GroupDbValues =  new Hashtable(); // Group DB Values

		public string GroupViewValue; // Group View Value		

		public object GroupSummaryOldValue; // Group Summary Old Value

		public object GroupSummaryValue; // Group Summary Value

		public string GroupSummaryViewValue; // Group Summary View Value

		public string SqlSelect; // Field SELECT

		public string SqlGroupBy; // Field GROUP BY

		public string SqlOrderBy; // Field ORDER BY

		public OrderedDictionary ValueList = new OrderedDictionary(); // Value List		

		public List<string> SelectionList = new List<string>(); // Selection List

		public List<string> DefaultSelectionList = new List<string>(); // Default Selection List

		public Dictionary<string, crAdvancedFilter> AdvancedFilters = new Dictionary<string, crAdvancedFilter>(); // Advanced Filters

		public string RangeFrom; // Range From

		public string RangeTo; // Range To

		public List<string> DropDownList = new List<string>(); // Dropdown List

		public object DropDownValue; // Dropdown Value		

		public object DefaultDropDownValue; // Default Dropdown Value

		public string DateFilter; // Date Filter

		public object SearchValue = ""; // Search Value 1

		public object SearchValue2 = ""; // Search Value 2

		public string SearchOperator = "="; // Search Operator 1

		public string SearchOperator2 = "="; // Search Operator 2

		public string SearchCondition = "AND"; // Search Condition

		public object DefaultSearchValue = ""; // Default Search Value 1

		public object DefaultSearchValue2 = ""; // Default Search Value 2

		public string DefaultSearchOperator = "="; // Default Search Operator 1

		public string DefaultSearchOperator2 = "="; // Default Search Operator 2

		public string DefaultSearchCondition = "AND"; // Default Search Condition		

		public string FldDelimiter = ""; // Field delimiter (e.g. comma) for delimiter separated value

		public bool Visible = true; // Visible

		private string _Caption = "";

		// Constructor
		public crField(string tblvar, string tblname, string fldvar, string fldname, string fldexpression, int fldtype, int flddatatype, int flddtfmt) {
			TblVar = tblvar;
			TblName = tblname;
			FldVar = fldvar;
			FldName = fldname;
			FldExpression = fldexpression;
			FldType = fldtype;
			FldDataType = flddatatype;
			FldDateTimeFormat = flddtfmt;
		}

		// Field caption
		public string FldCaption {
			get {
				if (ewr_NotEmpty(_Caption))
					return _Caption;
				else
					return ReportLanguage.FieldPhrase(TblVar, FldVar.Substring(2), "FldCaption");
			}
			set {
				_Caption = value;
			}
		}

		// Field title
		public string FldTitle {
			get {
				return ReportLanguage.FieldPhrase(TblVar, FldVar.Substring(2), "FldTitle");
			}
		}

		// Field image alt
		public string FldAlt {
			get {
				return ReportLanguage.FieldPhrase(TblVar, FldVar.Substring(2), "FldAlt");
			}
		}

		// Field error message
		public string FldErrMsg {
			get {
				var err = ReportLanguage.FieldPhrase(TblVar, FldVar.Substring(2), "FldErrMsg");
				if (ewr_Empty(err))
					err = FldDefaultErrMsg + " - " + FldCaption;
				return err;
			}
		}

		// Reset attributes for field object
		public void ResetAttrs() {
			CellAttrs.Clear();
			ViewAttrs.Clear();
		}

		// View Attributes
		public string ViewAttributes {
			get {
				string sAtt = "";
				if (ewr_ConvertToInt(ImageWidth) > 0 && (!ImageResize || (ImageResize && ewr_ConvertToInt(ImageHeight) <= 0)))
					sAtt += " width=\"" + ewr_ConvertToInt(ImageWidth) + "\"";
				if (ewr_ConvertToInt(ImageHeight) > 0 && (!ImageResize || (ImageResize && ewr_ConvertToInt(ImageWidth) <= 0)))
					sAtt += " height=\"" + ewr_ConvertToInt(ImageHeight) + "\"";
				foreach (var attr in ViewAttrs) {
					if (ewr_NotEmpty(attr.Value))
						sAtt += " " + attr.Key + "=\"" + attr.Value.Trim() + "\"";
				}
				return sAtt;
			}
		}

		// Link Attributes
		public string LinkAttributes {
			get {
				string sAtt = "";
				string sHref = HrefValue.Trim();
				foreach (var attr in LinkAttrs) {
					if (ewr_NotEmpty(attr.Value)) {
						if (attr.Key == "href")
							sHref += " " + attr.Value.Trim();
						else
							sAtt += " " + attr.Key + "=\"" + attr.Value.Trim() + "\"";
					}
				}
				if (ewr_NotEmpty(sHref))
					sAtt += " href=\"" + sHref.Trim() + "\"";
				else if (LinkAttrs.ContainsKey("onclick") && ewr_NotEmpty(LinkAttrs["onclick"]))
					sAtt += " href=\"javascript:void(0);\"";
				return sAtt;
			}
		}

		// Cell attributes
		public string CellAttributes {
			get { 		
				string sAtt = "";
				foreach (var attr in CellAttrs) {
					if (ewr_NotEmpty(attr.Value))
						sAtt += " " + attr.Key + "=\"" + attr.Value.Trim() + "\"";
				}
				return sAtt;
			}
		}

		// Edit Attributes
		public string EditAttributes {
			get {
				string sAtt = "";
				foreach (var attr in EditAttrs) {
					if (ewr_NotEmpty(attr.Value))
						sAtt += " " + attr.Key + "=\"" + attr.Value.Trim() + "\"";
				}
				return sAtt;
			}
		}

		// Sort
		public string Sort {
			get { return Convert.ToString(ewr_Session[EWR_PROJECT_NAME + "_" + TblVar + "_" + EWR_TABLE_SORT + "_" + FldVar]); }
			set {
				if (ewr_Session[EWR_PROJECT_NAME + "_" + TblVar + "_" + EWR_TABLE_SORT + "_" + FldVar] != value)	{
					ewr_Session[EWR_PROJECT_NAME + "_" + TblVar + "_" + EWR_TABLE_SORT + "_" + FldVar] = value;
				}
			}
		}

		// Reverse sort
		public string ReverseSort() {
			return (Sort == "ASC") ? "DESC" : "ASC";
		}

		// List view value
		public string ListViewValue {
			get {
				if (ewr_Empty(ViewValue)) {
					return "&nbsp;";
				} else {
					string value = ViewValue.Trim();
					string value2 = Regex.Replace(value, "<[^img][^>]*>" , String.Empty); // Remove all except non-empty image tag
					return (ewr_NotEmpty(value2)) ? ViewValue : "&nbsp;";	
				}
			}
		}

		// Form value	
		public string FormValue {
			get { return m_FormValue; }
			set {
				m_FormValue = value;
				CurrentValue = m_FormValue;
			}
		}

		// QueryString value
		public string QueryStringValue {
			get { return m_QueryStringValue; }
			set {
				m_QueryStringValue = value;
				CurrentValue = m_QueryStringValue;
			}
		}

		// Database value
		public object DbValue {
			get { return m_DbValue; }
			set {
				OldValue = m_DbValue;
				m_DbValue = value;
				if (EWR_IS_MSSQL && (FldType == 131 || FldType == 139)) // MS SQL adNumeric/adVarNumeric field
					m_DbValue = ewr_ConvertToDouble(value);				
				CurrentValue = m_DbValue;
			}
		}

		// Group value
		public object GroupValue {
			get { return GetGroupValue(CurrentValue); }
		}

		// Group old value
		public object GroupOldValue {
			get { return GetGroupValue(OldValue); }
		}

		// Get group value
		public object GetGroupValue(object v) {
			if (GroupingFieldId == 1) {
				return v;
			} else if (GroupDbValues.Count > 0) {
				return GroupDbValues[v];
			} else if (ewr_NotEmpty(FldGroupByType) && !ewr_SameStr(FldGroupByType, "n")) {
				return ewr_GroupValue(this, v);
			} else {
				return v;
			}
		}
	}

	// Javascript for drill down
	public static string ewr_DrillDownJs(string url, string id, string hdr, bool usepanel = true, string objid = "", bool evt = true) {
		if (ewr_Empty(url)) {
			return "";
		} else {
			if (usepanel) {
				var obj = (ewr_Empty(objid)) ? "this" : "'" + ewr_JsEncode(objid) + "'";
				if (evt)
					return "ewr_ShowDrillDown(event, " + obj + ", '" + ewr_JsEncode(url) + "', '" + ewr_JsEncode(id) + "', '" + ewr_JsEncode(hdr) + "'); return false;";
				else
					return "ewr_ShowDrillDown(null, " + obj + ", '" + ewr_JsEncode(url) + "', '" + ewr_JsEncode(id) + "', '" + ewr_JsEncode(hdr) + "');";
			} else {
				url = url.Replace("?d=1&", "?d=2&"); // Change d parameter to 2
				return "ewr_Redirect('" + ewr_JsEncode(url) + "');";
			}
		}
	}

	//
	// Chart parameter class
	//
	public class crChartParm {

		public string Key = "";

		public object Value = null;

		public bool Output = true;

		public crChartParm(string k, object v, bool o = true) {
			Key = k;
			Value = v;
			Output = o;		
		}
	}

	//
	// Chart class
	//
	public class crChart {

		public string TblName = ""; // Table name

		public string TblVar = ""; // Table variable name

		public string ChartName = ""; // Chart name

		public string ChartVar = ""; // Chart variable name

		public string ChartXFldName = ""; // Chart X Field name

		public string ChartYFldName = ""; // Chart Y Field name

		public string ChartSFldName = ""; // Chart Series Field name

		public int ChartType; // Chart Type

		public string ChartSortType = ""; // Chart Sort Type

		public string ChartSummaryType = ""; // Chart Summary Type

		public int ChartWidth; // Chart Width

		public int ChartHeight; // Chart Height

		public string ChartAlign = ""; // Chart Align

		public string ChartDrillDownUrl = ""; // Chart drill down URL

		public bool UseDrillDownPanel = EWR_USE_DRILLDOWN_PANEL; // Use drill down panel

		public int ChartDefaultDecimalPrecision = EWR_DEFAULT_DECIMAL_PRECISION;

		public string SqlSelect = "";

		public string SqlGroupBy = "";

		public string SqlOrderBy = "";

		public string XAxisDateFormat = "";

		public string NameDateFormat = "";

		public string SeriesDateType = "";

		public string SqlSelectSeries = "";

		public string SqlGroupBySeries = "";

		public string SqlOrderBySeries = "";

		public string ID = "";

		public Dictionary<string, crChartParm> Parms = new Dictionary<string, crChartParm>();

		public List<object[]> Trends = new List<object[]>();

		public List<OrderedDictionary> Data = new List<OrderedDictionary>();

		public List<OrderedDictionary> ViewData = new List<OrderedDictionary>();

		public List<object> Series = new List<object>();

		public Regex RegexColor = new Regex("^#([a-fA-F0-9]{6}|[a-fA-F0-9]{3})$");

		public XmlDocument XmlDoc;

		public XmlElement XmlRoot;

		private string _Caption = "";

		// Constructor
		public crChart(string tblvar, string tblname, string chartvar, string chartname, string xfld, string yfld, string sfld, int type, string smrytype, int width, int height, string align = "") {
			TblVar = tblvar;
			TblName = tblname;
			ChartVar = chartvar;
			ChartName = chartname;
			ChartXFldName = xfld;
			ChartYFldName = yfld;
			ChartSFldName = sfld;
			ChartType = type;
			ChartSummaryType = smrytype;
			ChartWidth = width;
			ChartHeight = height;
			ChartAlign = align;
			XmlDoc = new XmlDocument();
		}

		// Constructor for crGantt // AXR
		public crChart() {}		

		// Chart caption		
		public string ChartCaption {
			get {
				if (ewr_NotEmpty(_Caption))
					return _Caption;
				else
					return ReportLanguage.ChartPhrase(TblVar, ChartVar, "ChartCaption");
			}
			set{
				_Caption = value;
			}	
		}

		// xaxisname
		public string ChartXAxisName {			
			get { return ReportLanguage.ChartPhrase(TblVar, ChartVar, "ChartXAxisName"); }
		}

		// yaxisname
		public string ChartYAxisName {			
			get { return ReportLanguage.ChartPhrase(TblVar, ChartVar, "ChartYAxisName"); }
		}

		// PYAxisName
		public string ChartPYAxisName {			
			get { return ReportLanguage.ChartPhrase(TblVar, ChartVar, "ChartPYAxisName"); }
		}

		// SYAxisName
		public string ChartSYAxisName {			
			get { return ReportLanguage.ChartPhrase(TblVar, ChartVar, "ChartSYAxisName"); }
		}

		// Sort
		public string Sort {
			get {
				return Convert.ToString(ewr_Session[EWR_PROJECT_VAR + "_" + TblVar + "_" + EWR_TABLE_SORTCHART + "_" + ChartVar]);
			}
			set {
				if (!ewr_SameStr(ewr_Session[EWR_PROJECT_VAR + "_" + TblVar + "_" + EWR_TABLE_SORTCHART + "_" + ChartVar], value))
					ewr_Session[EWR_PROJECT_VAR + "_" + TblVar + "_" + EWR_TABLE_SORTCHART + "_" + ChartVar] = value;
			}
		}

		// Set chart parameters
		public void SetChartParm(string name, object value, bool output) {
			Parms[name] = new crChartParm(name, value, output);
		}

		// Set chart parameters
		public void SetChartParms(List<crChartParm> parms) {
			if (parms != null) {
				foreach (var parm in parms) {
					if (parm.Output == null)
						parm.Output = true;
					Parms[parm.Key] = parm;
				}
			}
		}

		// Set up default chart parm
		public void SetupDefaultChartParm(string key, object value) {
			object parm = LoadParm(key);
			if (parm == null) {
				Parms[key] = new crChartParm(key, value, true);
			} else if (parm == "") {
				SaveParm(key, value);
			}
		}

		// Load chart parm
		public object LoadParm(string key) {
			if (Parms.ContainsKey(key))
				return Parms[key].Value;
			return null;
		}

		// Save chart parm
		public void SaveParm(string key, object value) {
			if (Parms.ContainsKey(key)) {
				Parms[key].Value = value;
			} else {
				Parms[key] = new crChartParm(key, value, true);
			}
		}

		// Load chart parms	
		public void LoadChartParms() {

			// Initialize default values
			SetupDefaultChartParm("caption", "Chart");

			// Show names/values/hover
			SetupDefaultChartParm("shownames", "1"); // Default show names
			SetupDefaultChartParm("showvalues", "1"); // Default show values
			SetupDefaultChartParm("showhover", "1"); // Default show hover

			// Process chart parms
			ProcessChartParms(Parms);

			// Get showvalues/showhovercap
			string cht_showValues = Convert.ToString(LoadParm("showvalues"));
			string cht_showHoverCap = Convert.ToString(LoadParm("showhovercap"));

			// Format percent for Pie charts
			string cht_showPercentageValues = Convert.ToString(LoadParm("showPercentageValues"));
			string cht_showPercentageInLabel = Convert.ToString(LoadParm("showPercentageInLabel"));
			int cht_type = ewr_ConvertToInt(LoadParm("type"));
			if (cht_type == 2 || cht_type == 6 || cht_type == 8 || cht_type == 101) {
				if ((cht_showHoverCap == "1" && cht_showPercentageValues == "1") ||
				(cht_showValues == "1" && cht_showPercentageInLabel == "1")) {
					SetupDefaultChartParm("formatNumber", "1");
					SaveParm("formatNumber", "1");
				}
			} else if (cht_type == 20) {
				SetupDefaultChartParm("bearBorderColor", "E33C3C");
				SetupDefaultChartParm("bearFillColor", "E33C3C");
			}

			// Hide legend for single series (Bar 3D / Column 2D / Line 2D / Area 2D)
			var scrollchart = (ewr_ConvertToInt(LoadParm("numVisiblePlot")) > 0 && (cht_type == 1 || cht_type == 4 || cht_type == 7)) ? 1 : 0;
			var cht_single_series = (cht_type == 104 || scrollchart == 1) ? 1 : 0;
			if (cht_single_series == 1) {
				SetupDefaultChartParm("showLegend", "0");
				SaveParm("showLegend", "0");
			}
		}

		// Load view data
		public void LoadViewData() {
			string sdt = SeriesDateType;
			string xdt = XAxisDateFormat;
			string ndt = (ChartType == 20) ? NameDateFormat : "";
			if (ewr_NotEmpty(sdt))
				xdt = sdt;
			ViewData.Clear();
			if (ewr_Empty(sdt) && ewr_Empty(xdt) && ewr_Empty(ndt)) { // No formatting, just copy
				ViewData = Data;
			} else if (ewr_IsList(Data)) { // Format data
				for (var i = 0; i < Data.Count; i++) {
					var temp = new OrderedDictionary();
					var chartrow = Data[i];
					var cntRow = chartrow.Count;
					temp.Add(0, ewr_ChartXValue(chartrow[0], xdt)); // X value
					temp.Add(1, ewr_ChartSeriesValue(chartrow[1], sdt)); // Series value
					for (var j = 2; j < cntRow; j++) {
						if (ewr_NotEmpty(ndt) && j == cntRow - 1)
							temp.Add(j, ewr_ChartXValue(chartrow[j], ndt)); // Name value
						else
							temp.Add(j, chartrow[j]); // Y values
					}
					ViewData.Add(temp);
				}
			}
		}

		// Chart Xml
		public string ChartXml() {
			LoadViewData();
			ewr_WebPage.Chart_Rendering(this);
			int cht_type = ewr_ConvertToInt(LoadParm("type"));

			// Format line color for Multi-Series Column Dual Y chart
			string cht_lineColor = (cht_type == 18 || cht_type == 19) ? Convert.ToString(LoadParm("lineColor")) : "";
			List<object> chartseries = Series;
			List<OrderedDictionary> chartdata = ViewData;
			int cht_series = ((cht_type >= 9 && cht_type <= 19) || (cht_type >= 102 && cht_type <= 103)) ? 1 : 0; // cht_series = 1 (Multi series charts)
			string cht_series_type = Convert.ToString(LoadParm("seriestype"));
			int cht_alpha = ewr_ConvertToInt(LoadParm("alpha"));

			// Hide legend for single series (Bar 3D / Column 2D / Line 2D / Area 2D)
			int scrollchart = (ewr_ConvertToInt(LoadParm("numVisiblePlot")) > 0 && (cht_type == 1 || cht_type == 4 || cht_type == 7)) ? 1 : 0;
			int cht_single_series = (cht_type == 104 || scrollchart == 1) ? 1 : 0;
			if (ewr_IsList(chartdata)) {
				WriteChartHeader(); // Write chart header

				// Candlestick
				if (cht_type == 20) {

					// Write candlestick cat
					if (chartdata[0].Count >= 7) {
						var cats = XmlDoc.CreateElement("categories");
						XmlRoot.AppendChild(cats);
						int cntcat = chartdata.Count;
						for (var i = 0; i < cntcat; i++) {
							var xindex = i + 1;
							object name = chartdata[i][6];
							if (ewr_NotEmpty(name))
								WriteChartCandlestickCatContent(cats, xindex, Convert.ToString(name));
						}
					}

					// Write candlestick data
					var data = XmlDoc.CreateElement("data");
					XmlRoot.AppendChild(data);
					for (var i = 0; i < chartdata.Count; i++) {
						OrderedDictionary temp = chartdata[i];
						double open = ewr_ConvertToDouble(temp[2]);
						double high = ewr_ConvertToDouble(temp[3]);
						double low = ewr_ConvertToDouble(temp[4]);
						double close = ewr_ConvertToDouble(temp[5]);
						int xindex = i + 1;
						string lnk = GetChartLink(ChartDrillDownUrl, Data[i]);
						WriteChartCandlestickContent(data, open, high, low, close, xindex, lnk);
					}

				// Multi series
				} else if (cht_series == 1) {

					// Multi-Y values
					if (cht_series_type == "1") {

						// Write cat
						var cats = XmlDoc.CreateElement("categories");
						XmlRoot.AppendChild(cats);
						var cntcat = chartdata.Count;
						for (var i = 0; i < cntcat; i++) {
							string name = ChartFormatName(chartdata[i][0]);
							WriteChartCatContent(cats, name);
						}

						// Write series
						OrderedDictionary temp = chartdata[0];
						var cntseries = chartseries.Count;
						if (cntseries > temp.Count - 2)
							cntseries = temp.Count - 2;						
						for (var i = 0; i < cntseries; i++) {
							string color = GetPaletteColor(i);
							bool bShowSeries = EWR_CHART_SHOW_BLANK_SERIES;
							var dataset = XmlDoc.CreateElement("dataset");
							WriteChartSeriesHeader(dataset, chartseries[i], color, cht_alpha, cht_lineColor);
							bool bWriteSeriesHeader = true;
							for (var j = 0; j < chartdata.Count; j++) {
								double val = ewr_ConvertToDouble(chartdata[j][i+2]);								
								if (val != 0)
									bShowSeries = true;
								string lnk = GetChartLink(ChartDrillDownUrl, Data[j]);
								WriteChartSeriesContent(dataset, val, "", "", lnk);
							}
							if (bShowSeries)
								XmlRoot.AppendChild(dataset);
						}

					// Series field
					} else {

						// Get series names
						int nSeries = 0;
						if (ewr_IsList(chartseries))
							nSeries = chartseries.Count;

						// Write cat
						var cats = XmlDoc.CreateElement("categories");
						XmlRoot.AppendChild(cats);
						List<string> chartcats = new List<string>();
						for (var i = 0; i < chartdata.Count; i++) {
							string name = Convert.ToString(chartdata[i][0]);
							if (!chartcats.Contains(name)) {
								WriteChartCatContent(cats, name);
								chartcats.Add(name);
							}
						}

						// Write series
						for (var i = 0; i < nSeries; i++) {
							string seriesname = (ewr_IsList(chartseries[i])) ? Convert.ToString(((List<object>)chartseries[i])[0]) : Convert.ToString(chartseries[i]);
							string color = GetPaletteColor(i);
							bool bShowSeries = EWR_CHART_SHOW_BLANK_SERIES;
							var dataset = XmlDoc.CreateElement("dataset");
							WriteChartSeriesHeader(dataset, chartseries[i], color, cht_alpha, cht_lineColor);
							int cntcats = chartcats.Count;
							for (var j = 0; j < cntcats; j++) {
								double val = 0;
								string lnk = "";
								for (var k = 0; k < chartdata.Count; k++) {
									if (ewr_SameStr(chartdata[k][0], chartcats[j]) && ewr_SameStr(chartdata[k][1], seriesname)) {
										val = ewr_ConvertToDouble(chartdata[k][2]);										
										if (val != 0)
											bShowSeries = true;
										lnk = GetChartLink(ChartDrillDownUrl, Data[k]);
										break;
									}
								}
								WriteChartSeriesContent(dataset, val, "", "", lnk);
							}
							if (bShowSeries)
								XmlRoot.AppendChild(dataset);
						}
					}

				// Show single series
				} else if (cht_single_series == 1) {

					// Write multiple cats
					var cats = XmlDoc.CreateElement("categories");
					XmlRoot.AppendChild(cats);
					int cntcat = chartdata.Count;
					for (var i = 0; i < cntcat; i++) {
						string name = ChartFormatName(chartdata[i][0]);
						if (ewr_NotEmpty(chartdata[i][1])) 
							name += ", " + chartdata[i][1];
						WriteChartCatContent(cats, name);
					}

					// Write series
					string toolTipSep = Convert.ToString(LoadParm("toolTipSepChar"));
					if (ewr_Empty(toolTipSep))
						toolTipSep = ":";
					var dataset = XmlDoc.CreateElement("dataset");
					WriteChartSeriesHeader(dataset, "", "", cht_alpha, cht_lineColor);
					for (var i = 0; i < chartdata.Count; i++) {
						string name = ChartFormatName(chartdata[i][0]);
						if (ewr_NotEmpty(chartdata[i][1])) 
							name += ", " + chartdata[i][1];
						double val = ewr_ConvertToDouble(chartdata[i][2]);
						string color = GetPaletteColor(i);
						string toolText = name + toolTipSep + ChartFormatNumber(val);
						string lnk = GetChartLink(ChartDrillDownUrl, Data[i]);
						WriteChartSeriesContent(dataset, val, color, cht_alpha, lnk, toolText);
						XmlRoot.AppendChild(dataset);
					}

				// Single series
				} else {
					for (var i = 0; i < chartdata.Count; i++) {
						string name = ChartFormatName(chartdata[i][0]);
						string color = GetPaletteColor(i);
						if (ewr_NotEmpty(chartdata[i][1])) 
							name += ", " + chartdata[i][1];
						double val = ewr_ConvertToDouble(chartdata[i][2]);
						string lnk = GetChartLink(ChartDrillDownUrl, Data[i]);
						WriteChartContent(XmlRoot, name, val, color, cht_alpha, lnk); // Get chart content
					}
				}

				// Get trend lines
				WriteChartTrendLines();
			}
			string wrk = XmlDoc.OuterXml;
			ewr_WebPage.Chart_Rendered(this, ref wrk);
			return (XmlRoot != null) ? wrk : "";

			// ewr_Trace(wrk);
		}

		// Show chart (FusionCharts Free)
		// typ: chart type (1/2/3/4/...)
		// id: chart id
		// parms: "bgcolor=FFFFFF|..."
		// trends: trend lines
		public string ShowChartFCF(string xml) {
			int typ = ChartType;
			string id = ID;
			var parms = Parms;
			var trends = Trends;
			var data = Data;
			var series = Series;
			int width = ChartWidth;
			int height = ChartHeight;
			string align = ChartAlign;
			if (ewr_ConvertToInt(typ) <= 0)
				typ = 1;
			string chartswf = "";
			switch (typ) {

			// Single Series
				case 1:	chartswf = "FCF_Column2D.swf"; break; // Column 2D
				case 2:	chartswf = "FCF_Pie2D.swf"; break; // Pie 2D
				case 3:	chartswf = "FCF_Bar2D.swf"; break; // Bar 2D
				case 4: chartswf = "FCF_Line.swf"; break; // Line 2D
				case 5: chartswf = "FCF_Column3D.swf"; break; // Column 3D
				case 6: chartswf = "FCF_Pie3D.swf"; break; // Pie 3D
				case 7: chartswf = "FCF_Area2D.swf"; break; // Area 2D
				case 8: chartswf = "FCF_Doughnut2D.swf"; break; // Doughnut 2D

			// Multi Series
				case 9: chartswf = "FCF_MSColumn2D.swf"; break; // Multi-series Column 2D
				case 10: chartswf = "FCF_MSColumn3D.swf"; break; // Multi-series Column 3D
				case 11: chartswf = "FCF_MSLine.swf"; break; // Multi-series Line 2D
				case 12: chartswf = "FCF_MSArea2D.swf"; break; // Multi-series Area 2D
				case 13: chartswf = "FCF_MSBar2D.swf"; break; // Multi-series Bar 2D

			// Stacked
				case 14: chartswf = "FCF_StackedColumn2D.swf"; break; // Stacked Column 2D
				case 15: chartswf = "FCF_StackedColumn3D.swf"; break; // Stacked Column 3D
				case 16: chartswf = "FCF_StackedArea2D.swf"; break; // Stacked Area 2D
				case 17: chartswf = "FCF_StackedBar2D.swf"; break; // Stacked Bar 2D

			// Combination
				case 18: chartswf = "FCF_MSColumn2DLineDY.swf"; break; // Multi-series Column 2D Line Dual Y Chart
				case 19: chartswf = "FCF_MSColumn3DLineDY.swf"; break; // Multi-series Column 3D Line Dual Y Chart

			// Financial
				case 20: chartswf = "FCF_Candlestick.swf"; break; // Candlestick

			// Other
				case 21: chartswf = "FCF_Gantt.swf"; break; // Gantt
				case 22: chartswf = "FCF_Funnel.swf"; break; // Funnel

			// Additional FusionCharts
				case 101: chartswf = "FCF_Doughnut2D.swf"; break; // Doughnut 3D, switch back to 2D
				case 102: chartswf = "FCF_MSBar2D.swf"; break; // Multi-series Bar 3D, switch back to 2D
				case 103: chartswf = "FCF_StackedBar2D.swf"; break; // Stacked Bar 3D, switch back to 2D
				case 104: chartswf = "FCF_Bar2D.swf"; break; // Bar 3D, switch back to 2D

			// Default
				default: chartswf = "FCF_Column2D.swf"; break; // Default = Column 2D
			}

			// Set width, height and align
			int wrkwidth;
			int wrkheight;
			string wrkalign;
			if (ewr_IsNumeric(width) && ewr_IsNumeric(height)) {
				wrkwidth = width;
				wrkheight = height;
			} else { // default
				wrkwidth = EWR_CHART_WIDTH;
				wrkheight = EWR_CHART_HEIGHT;
			}
			if (ewr_SameStr(align, "left") || ewr_SameStr(align, "right")) {
				wrkalign = align.ToLower();
			} else {
				wrkalign = EWR_CHART_ALIGN; // default
			}

			// Output JavaScript for FCF
			string chartxml = xml;
			string wrk = "";
			if (chartxml == "") chartxml = "<graph/>"; // Empty chart
			if (ewr_IsMobile()) {
				wrk = "<div>" + ReportLanguage.Phrase("BrowserNoFlashSupport") + "</div>";
			} else {
				wrk = "<script type=\"text/javascript\">\n";

				//wrk += "if (ewrEnv.ua.ios) {\n";
				//wrk += "document.write(ewLanguage.Phrase(\"BrowserNoFlashSupport\"));\n";
				//wrk += "} else {\n";

				wrk += "var chartwidth = \"" + wrkwidth + "\";\n";
				wrk += "var chartheight = \"" + wrkheight + "\";\n";

				//wrk += "var chartalign = \"" + wrkalign + "\";\n";
				wrk += "var chartxml = \"" + ewr_EscapeJs(chartxml) + "\";\n";
				wrk += "var chartid = \"div_" + id + "\";\n";
				wrk += "var chartswf = \"" + EWR_FUSIONCHARTS_FREE_CHART_PATH + chartswf + "\";\n";
				wrk += "var cht_" + id + " = new FusionChartsFree(chartswf, \"chart_" + id + "\", chartwidth, chartheight);\n";
				wrk += "cht_" + id + ".addParam(\"wmode\", \"transparent\");\n";
				wrk += "cht_" + id + ".setDataXML(chartxml);\n";
				wrk += "var f = " + CurrentPage.PageObjName + ".Chart_Rendering;\n";
				wrk += "if (typeof f == \"function\") f(cht_" + id + ", 'chart_" + id + "');\n";
				wrk += "cht_" + id + ".render(chartid);\n";
				wrk += "f = " + CurrentPage.PageObjName + ".Chart_Rendered;\n";
				wrk += "if (typeof f == \"function\") f(cht_" + id + ", 'chart_" + id + "');\n";

				//wrk += "}\n";
				wrk += "</script>\n";
			}

			// Add debug xml
			if (EWR_DEBUG_ENABLED)
				wrk += "<div class=\"ewSpacer\">(Chart XML): " + ewr_HtmlEncode(chartxml) + "</div>";
			return wrk;
		}

		// Show Chart Xml
		public void ShowChartXml() {

			// Build chart content
			string sChartContent = ChartXml();
			ewr_Response.AddHeader("Content-Type", "text/xml; charset=UTF-8");

			// Write utf-8 BOM
			ewr_Response.BinaryWrite(new byte[]{0xEF, 0xBB, 0xBF});

			// Write utf-8 encoding
			ewr_Write("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");

			// Write content
			ewr_Write(sChartContent);
		}

		// Show Chart Text
		public void ShowChartText() {

			// Build chart content
			string sChartContent = ChartXml();
			ewr_Response.AddHeader("Content-Type", "text/xml; charset=UTF-8");

			// Write content
			ewr_Write(sChartContent);
		}

		// Get color
		public string GetPaletteColor(int i) {
			string colorpalette = Convert.ToString(LoadParm("colorpalette"));
			string[] ar_cht_colorpalette = colorpalette.Split(new char[] {'|'});
			int cntar = ar_cht_colorpalette.Length;
			return ar_cht_colorpalette[i % cntar];
		}

		// Convert to HTML color
		public string ColorCode(string c) {
			if (ewr_NotEmpty(c)) {

				// remove #
				string color = c.Replace("#", "");

				// fill to 6 digits
				return color.PadLeft(6, '0');
			} else {
				return "";
			}
		}

		// Output chart header
		public void WriteChartHeader() {
			var chartElement = (ChartType == 20 || (EWR_FUSIONCHARTS_FREE && ChartType != 21 && ChartType != 22)) ? "graph" : "chart";
			var chart = XmlDoc.CreateElement(chartElement);
			XmlRoot = chart;
			XmlDoc.AppendChild(chart);			
			foreach (var kvp in Parms) {
				if (kvp.Value.Output)
					WriteAtt(chart, kvp.Key, kvp.Value.Value);
			}
		}

		// Get TrendLine XML
		// <trendlines>
		//    <line startvalue='0.8' displayValue='Good' color='FF0000' thickness='1' isTrendZone='0'/>
		//    <line startvalue='-0.4' displayValue='Bad' color='009999' thickness='1' isTrendZone='0'/>
		// </trendlines>
		public void WriteChartTrendLines() {
			var cht_trends = Trends;
			foreach (object[] trend in Trends) {
				var trends = XmlDoc.CreateElement("trendlines");
				XmlRoot.AppendChild(trends);

				// Get all trend lines
				WriteChartTrendLine(trends, trend[0], trend[1], trend[2], trend[3], trend[4], trend[5], trend[6], trend[7]);
			}
		}

		// Output trend line
		public void WriteChartTrendLine(XmlElement node, object startval, object endval, object color, object dispval, object thickness, object trendzone, object showontop, object alpha) {
			var line = XmlDoc.CreateElement("line");
			WriteAtt(line, "startValue", startval); // Starting y value
			if (ewr_ConvertToInt(endval) != 0)
				WriteAtt(line, "endValue", endval); // Ending y value
			WriteAtt(line, "color", CheckColorCode(color)); // Color
			if (ewr_NotEmpty(dispval))
				WriteAtt(line, "displayValue", dispval); // Display value
			if (ewr_ConvertToInt(thickness) > 0)
				WriteAtt(line, "thickness", thickness); // Thickness
			WriteAtt(line, "isTrendZone", trendzone); // Display trend as zone or line
			WriteAtt(line, "showOnTop", showontop); // Show on top
			if (ewr_ConvertToInt(alpha) > 0)
				WriteAtt(line, "alpha", alpha); // Alpha
			node.AppendChild(line);
		}

		// Series header/footer XML (multi series)
		public void WriteChartSeriesHeader(XmlElement node, object series, string color, int alpha, string linecolor) {
			object seriesname = (ewr_IsList(series)) ? ((object[])series)[0] : series;
			if (Convert.IsDBNull(seriesname)) {
				seriesname = ReportLanguage.Phrase("NullLabel");
			} else if (ewr_Empty(seriesname)) {
				seriesname = ReportLanguage.Phrase("EmptyLabel");
			}
			WriteAtt(node, "seriesname", seriesname);
			if (ewr_IsList(series)) {
				if (((object[])series)[1] == "S" && ewr_NotEmpty(linecolor))
					WriteAtt(node, "color", ColorCode(linecolor));
				else
					WriteAtt(node, "color", ColorCode(color));
			} else {
					WriteAtt(node, "color", ColorCode(color));
			}
			WriteAtt(node, "alpha", alpha);
			if (ewr_IsList(series))
				WriteAtt(node, "parentYAxis", ((object[])series)[1]);
			ewr_WebPage.Chart_DataRendered(this, node);
		}

		// Series content XML (multi series)
		public void WriteChartSeriesContent(XmlElement node, double val, string color = "", object alpha = null, string lnk = "", string toolText = "") {
			var set = XmlDoc.CreateElement("set");
			WriteAtt(set, "value", ChartFormatNumber(val));
			if (ewr_NotEmpty(color))
				WriteAtt(set, "color", ColorCode(color));
			if (ewr_NotEmpty(alpha))
				WriteAtt(set, "alpha", alpha);
			if (ewr_NotEmpty(lnk))
				WriteAtt(set, "link", lnk);
			if (ewr_NotEmpty(toolText))
				WriteAtt(set, "toolText", toolText);
			ewr_WebPage.Chart_DataRendered(this, set);
			node.AppendChild(set);
		}

		// Category content XML (Candlestick category)
		public void WriteChartCandlestickCatContent(XmlElement node, int xindex, string name) {
			var cat = XmlDoc.CreateElement("category");
			WriteAtt(cat, "name", name);
			WriteAtt(cat, "xindex", xindex);
			WriteAtt(cat, "showline", "1");
			ewr_WebPage.Chart_DataRendered(this, cat);
			node.AppendChild(cat);
		}

		// Chart content XML (Candlestick)
		public void WriteChartCandlestickContent(XmlElement node, double open, double high, double low, double close, int xindex, string lnk = "") {
			var set = XmlDoc.CreateElement("set");
			WriteAtt(set, "open", ChartFormatNumber(open));
			WriteAtt(set, "high", ChartFormatNumber(high));
			WriteAtt(set, "low", ChartFormatNumber(low));
			WriteAtt(set, "close", ChartFormatNumber(close));
			if (ewr_NotEmpty(xindex))
				WriteAtt(set, "xindex", xindex);
			if (ewr_NotEmpty(lnk))
				WriteAtt(set, "link", lnk);
			ewr_WebPage.Chart_DataRendered(this, set);
			node.AppendChild(set);
		}

		// Format name for chart
		public string ChartFormatName(object name) {			
			if (Convert.IsDBNull(name)) {
				return ReportLanguage.Phrase("NullLabel");
			} else if (ewr_Empty(name)) {
				return ReportLanguage.Phrase("EmptyLabel");
			} else {
				return Convert.ToString(name);
			}
		}

		// Write attribute
		public void WriteAtt(XmlElement node, string name, object value) {
			var val = CheckColorCode(value);
			val = ChartEncode(val);
			if (node.HasAttribute(name)) {
				node.GetAttributeNode(name).Value = val;
			} else {
				var att = XmlDoc.CreateAttribute(name);
				att.Value = val;
				node.Attributes.Append(att);
			}
		}

		// Check color code
		public string CheckColorCode(object val) {
			string value = Convert.ToString(val);
			if (RegexColor.IsMatch(value)) {
				return value.Substring(1);
			} else {
				return value;
			}
		}

		// Process chart parms
		public void ProcessChartParms(Dictionary<string, crChartParm> Parms) {
			if (ewr_SameStr(LoadParm("type"), 104))
				SaveParm("type", 3); // Bar 3D, Switch back to Bar 2D

			// Remove numVisiblePlot (scroll charts)
			if (Parms.ContainsKey("numVisiblePlot"))
				Parms.Remove("numVisiblePlot");
		}

		// Encode special characters for FusionChartsFree
		// + => %2B
		public string ChartEncode(string val) {
			return val.Replace("+", "%2B");
		}

		// Format number for chart
		public string ChartFormatNumber(double v) {
			object cht_decimalprecision = LoadParm("decimalPrecision");
			if (cht_decimalprecision == null) {
				if (ChartDefaultDecimalPrecision >= 0)
					cht_decimalprecision = ChartDefaultDecimalPrecision; // Use default precision
				else
					cht_decimalprecision = ((v - Convert.ToInt32(v)) == 0) ? 0 : Convert.ToString(Math.Abs(v - Convert.ToInt32(v))).Length - 2; // Use original decimal precision
			}
			return v.ToString("F" + Convert.ToString(cht_decimalprecision));
		}

		// Category content XML (multi series)
		public void WriteChartCatContent(XmlNode node, string name) {
			var cat = XmlDoc.CreateElement("category");
			WriteAtt(cat, "name", name);
			ewr_WebPage.Chart_DataRendered(this, cat);
			node.AppendChild(cat);
		}

		// Chart content XML
		public void WriteChartContent(XmlNode node, string name, double val, string color, object alpha, string lnk) {
			object cht_shownames = LoadParm("shownames");
			var set = XmlDoc.CreateElement("set");
			WriteAtt(set, "name", name);
			WriteAtt(set, "value", ChartFormatNumber(val));
			WriteAtt(set, "color", ColorCode(color));
			WriteAtt(set, "alpha", alpha);
			if (ewr_NotEmpty(lnk))
				WriteAtt(set, "link", lnk);
			if (cht_shownames == "1")
				WriteAtt(set, "showName", "1");
			ewr_WebPage.Chart_DataRendered(this, set);
			node.AppendChild(set);
		}

		// Get chart link
		public string GetChartLink(string src, OrderedDictionary row) {
			if (ewr_NotEmpty(src) && row != null) {
				var cntrow = row.Count;
				var lnk = src;
				var sdt = SeriesDateType;
				var xdt = XAxisDateFormat;
				var ndt = (ChartType == 20) ? NameDateFormat : "";
				if (ewr_NotEmpty(sdt))
					xdt = sdt;
				var tblcaption = "";
				Match m = Regex.Match(lnk, "&t=([^&]+)&"); 
				if (m.Success)
					tblcaption = ReportLanguage.TablePhrase(m.Groups[1].Value, "TblCaption");
				for (var i = 0; i < cntrow; i++) {

					// Link format: %i:Parameter:FieldType%
					m = Regex.Match(lnk, "%" + Convert.ToString(i) + @":([^%:]*):([\d]+)%");
					if (m.Success) {
						var fldtype = ewr_FieldDataType(ewr_ConvertToInt(m.Groups[2].Value));
						if (i == 0) { // Format X SQL
							lnk = lnk.Replace(m.Groups[0].Value, ewr_Encrypt(ewr_ChartXSQL("@" + m.Groups[1].Value, fldtype, row[i], xdt)));
						} else if (i == 1) { // Format Series SQL
							lnk = lnk.Replace(m.Groups[0].Value, ewr_Encrypt(ewr_ChartSeriesSQL("@" + m.Groups[1].Value, fldtype, row[i], sdt)));
						} else {
							lnk = lnk.Replace(m.Groups[0].Value, ewr_Encrypt("@" + m.Groups[1].Value + " = " + ewr_QuotedValue(row[i], fldtype)));
						}
					}
				}
				return "javascript:" + ewr_DrillDownJs(lnk, ID, tblcaption, UseDrillDownPanel, "div_" + ID, false);
			} else {
				return "";
			}
		}
	}

	//
	// Column class
	//
	public class crCrosstabColumn {

		public string Caption = "";

		public object Value;

		public bool Visible = true;

		public crCrosstabColumn(object val, string cap, bool vis = true) {
			Caption = cap;
			Value = val;
			Visible = vis;
		}
	}

	//
	// Advanced filter class
	//
	public class crAdvancedFilter {

		public string ID;

		public string Name;

		public string FunctionName;

		public bool Enabled = true;

		public crAdvancedFilter(string filterid, string filtername, string filterfunc) {
			ID = filterid;
			Name = filtername;
			FunctionName = filterfunc;
		}
	}

	// Menu class
	public class cMenuBase
	{

		public object Id;

		public bool IsMobile = false;

		public bool IsRoot = false;

		public ArrayList ItemData = new ArrayList(); // ArrayList of cMenuItem

		// Constructor
		public cMenuBase(object MenuId, bool Mobile = false)
		{
			Id = MenuId;
			IsMobile = Mobile;
		}

		// Add a menu item
		public void AddMenuItem(int Id, string Text, string Url, int ParentId = -1, string Src = "", bool Allowed = true, bool GroupTitle = false)
		{
			cMenuItem oParentMenu = null;
			var item = new cMenuItem(Id, Text, Url, ParentId, Src, Allowed, GroupTitle);
			if (!MenuItem_Adding(ref item))
				return;
			if (item.ParentId < 0) {
				AddItem(ref item);
			} else {
				if (FindItem(item.ParentId, ref oParentMenu))
					oParentMenu.AddItem(ref item, IsMobile);
			}
		}

		// Get menu item count
		public int Count
		{
			get { return ItemData.Count; }
		}

		// Add item to internal ArrayList
		public void AddItem(ref cMenuItem item)
		{
			ItemData.Add(item);
		}

		// Clear all menu items
		public void Clear() {
			ItemData.Clear();
		}

		// Find item
		public bool FindItem(int id, ref cMenuItem outitem)
		{
			bool result = false;
			foreach (cMenuItem item in ItemData) {
				if (item.Id == id) {
					outitem = item;
					return true;
				} else if (item.SubMenu != null) {
					if (item.SubMenu.FindItem(id, ref outitem))
						return true;
				}
			}
			return result;
		}

		// Find item
		public bool FindItemByText(string txt, ref cMenuItem outitem)
		{
			bool result = false;
			foreach (cMenuItem item in ItemData) {
				if (item.Text == txt) {
					outitem = item;
					return true;
				} else if (item.SubMenu != null) {
					if (item.SubMenu.FindItemByText(txt, ref outitem))
						return true;
				}
			}
			return result;
		}

		// Move item to position
		public void MoveItem(string Text, int Pos)
		{
			int oldpos = 0;
			int newpos = Pos;
			bool bfound = false;
			if (Pos < 0) {
				Pos = 0;
			} else if (Pos >= ItemData.Count) {
				Pos = ItemData.Count - 1;
			}
			cMenuItem CurItem = null;
			foreach (cMenuItem item in ItemData) {
				if (ewr_SameStr(item.Text, Text)) {
					CurItem = item;
					break;
				}
			}
			if (CurItem != null) {
				bfound = true;
				oldpos = ItemData.IndexOf(CurItem);
			} else {
				bfound = false;
			}
			if (bfound && Pos != oldpos) {
				ItemData.RemoveAt(oldpos); // Remove old item
				if (oldpos < Pos)
					newpos -= 1; // Adjust new position
				ItemData.Insert(newpos, CurItem); // Insert new item
			}
		}

		// Check if a menu item should be shown
		public bool RenderItem(cMenuItem item) {
			if (item.SubMenu != null) {
				foreach (cMenuItem subitem in item.SubMenu.ItemData) {
					if (item.SubMenu.RenderItem(subitem))
						return true;
				}
			}
			return (item.Allowed && ewr_NotEmpty(item.Url));
		}

		// Check if this menu should be rendered
		public bool RenderMenu() {
			foreach (cMenuItem item in ItemData) {
				if (RenderItem(item))
					return true;
			}
			return false;
		}

		// Render the menu
		public void Render() {
			Render(false);
		}

		// Render the menu
		public virtual string Render(bool ret) {

//			var m = this;
//			if (IsRoot)
//				Menu_Rendering(m);

			if (!RenderMenu())
				return "";
			string str = "";	
			if (!IsMobile) {	
				str = "<div";
				if (ewr_NotEmpty(Id)) {
					if (ewr_IsNumeric(Id)) {
						str += " id=\"menu_" + Id + "\"";
					} else {
						str += " id=\"" + Id + "\"";
					}
				}
				str += " class=\"" + ((IsRoot) ? EWR_MENUBAR_CLASSNAME : EWR_MENU_CLASSNAME) + "\">";
				str += "<div class=\"bd" + ((IsRoot) ? " first-of-type" : "") + "\">\n";
			}			
			bool gopen = false; // Group open status
			int gcnt = 0; // Group count
			int i = 0; // Menu item count
			string classfot = " class=\"first-of-type\"";
			foreach (cMenuItem item in ItemData) {
				if (RenderItem(item)) {	
					i++;

					// Begin a group
					if (i == 1 && !item.GroupTitle) {
						gcnt++;
						if (!IsMobile)
							str += "<ul " + classfot + ">\n";
						gopen = true;
					}
					string aclass = (IsRoot) ? EWR_MENUBAR_ITEM_LABEL_CLASSNAME : EWR_MENU_ITEM_LABEL_CLASSNAME;
					string liclass = (IsRoot) ? EWR_MENUBAR_ITEM_CLASSNAME : EWR_MENU_ITEM_CLASSNAME;
					if (item.GroupTitle && ewr_NotEmpty(EWR_MENU_ITEM_CLASSNAME)) { // Group title
						gcnt++;
						if (i > 1 && gopen) {
							if (!IsMobile)
								str += "</ul>\n"; // End last group
							gopen = false;
						}

						// Begin a new group with title
						if (ewr_NotEmpty(item.Text)) {
							if (IsMobile)
								str += "<li data-role=\"list-divider\">" + item.Text + "</li>\n";
							else
								str += "<h6" + ((gcnt == 1) ? classfot : "") + ">" + item.Text + "</h6>\n";
						}
						if (!IsMobile)
							str += "<ul" + ((gcnt == 1) ? classfot : "") + ">\n";
						gopen = true;
						if (item.SubMenu != null) {
							foreach (cMenuItem subitem in item.SubMenu.ItemData) {
								if (RenderItem(subitem))
									str += subitem.Render(aclass, liclass, IsMobile) + "\n"; // Create <LI>
							}
						}
						if (!IsMobile)
							str += "</ul>\n"; // End the group
						gopen = false;
					} else { // Menu item
						if (!gopen) { // Begin a group if no opened group
							gcnt++;
							if (!IsMobile)
								str += "<ul" + ((gcnt == 1) ? classfot : "") + ">\n";
							gopen = true;
						}
						if (IsRoot && i == 1) // For horizontal menu
							liclass += " first-of-type";
						str += item.Render(aclass, liclass, IsMobile) + "\n"; // Create <LI>
					}
				}
			}
			if (gopen)
				if (!IsMobile)
					str += "</ul>\n"; // End last group
			if (IsMobile)
				str = "<ul data-role=\"listview\" data-filter=\"true\" class=\"first-of-type\">" + str + "</ul>\n";
			else
				str += "</div></div>\n";
			if (ret) // Return as string
				return str;
			ewr_Write(str); // Output
			return "";
		}

		// MenuItem_Adding 
		public virtual bool MenuItem_Adding(ref cMenuItem Item) {
			return true;
		}

//		// Menu_Rendering 
//		public virtual void Menu_Rendering(ref cMenuBase Menu) {
//		}

	}

	// Menu item class
	public class cMenuItem
	{

		public int Id;

		public string Text;

		public string Url;

		public int ParentId;

		public cMenuBase SubMenu = null;

		public string Source = "";

		public bool Allowed = true;

		public string Target = "";

		public bool GroupTitle = false;

		// Constructor
		public cMenuItem(int aId, string aText, string aUrl, int aParentId = -1, string aSource = "", bool aAllowed = true, bool aGroupTitle = false)
		{
			Id = aId;
			Text = aText;
			Url = aUrl;
			ParentId = aParentId;
			Source = aSource;
			Allowed = aAllowed;
			GroupTitle = aGroupTitle;			
		}

		// Add submenu item
		public void AddItem(ref cMenuItem item, bool mobile = false)
		{
			if (SubMenu == null)
				SubMenu = new cMenuBase(Id, mobile);				
			SubMenu.AddItem(ref item);
		}

		// Render
		public string Render(string aclass, string liclass, bool mobile = false) {

			// Create <A>
			Dictionary<string, string> attrs;
			if (mobile)
				attrs = new Dictionary<string, string>() {{"class", aclass}, {"rel","external"}, {"href", Url.Replace("#", "?chart=")}, {"target", Target}};
			else
				attrs = new Dictionary<string, string>() {{"class", aclass}, {"href", Url}, {"target", Target}};
			string innerhtml = ewr_HtmlElement("a", attrs, Text, true);
			if (SubMenu != null) {
				if (mobile && ewr_NotEmpty(Url))
					innerhtml += innerhtml;
				innerhtml += SubMenu.Render(true);
			}

			// Create <LI>
			attrs.Clear();
			attrs.Add("class", liclass);
			return ewr_HtmlElement("li", attrs, innerhtml, true);
		}
	}

	//
	//  List option collection class
	//	
	public class crListOptions
	{

		public List<crListOption> Items = new List<crListOption>();

		public string CustomItem = "";

		public string Tag = "td";

		public string TagClassName = "";

		public string TableVar = "";

		public string RowCnt = "";

		public string ScriptType = "block";

		public string ScriptId = "";

		public string ScriptClassName = "";

		public string JavaScript = "";

		public int RowSpan = 1;

		// Add and return a new option
		public crListOption Add(string Name)
		{
			crListOption item = new crListOption(Name);
			item.Parent = this;
			Items.Add(item);
			return item;
		}

		// Load default settings
		public void LoadDefault()
		{
			CustomItem = "";
			foreach (var item in Items)
				item.Body = "";
		}

		// Hide all options
		public void HideAllOptions()
		{
			foreach (var item in Items)
				item.Visible = false;
		}

		// Show all options
		public void ShowAllOptions()
		{
			foreach (var item in Items)
				item.Visible = true;
		}

		// Get item by name (predefined names: view/edit/copy/delete/detail_<DetailTable>/userpermission/checkbox)
		public crListOption GetItem(string name)
		{
			return Items.Find(delegate(crListOption item) {
                return (item.Name == name);
            });
		}

		// Get item by name
		public crListOption this[string name] {
			get {
				return GetItem(name);
			}
		}

		// Get item by index
		public crListOption this[int index] {
			get {
				return Items[index];
			}
		}

		// Get item index by name (predefined names: view/edit/copy/delete/detail_<DetailTable>/userpermission/checkbox)
		public int GetItemIndex(string name)
		{
			return Items.FindIndex(delegate(crListOption item) {
                return (item.Name == name);
            });
		}		

		// Move item to position
		public void MoveItem(string Name, int Pos)
		{	
			int newpos = Pos;
			if (Pos < 0) {
				Pos = 0;
			} else if (Pos >= Items.Count) {
				Pos = Items.Count - 1;
			}
			var CurItem = GetItem(Name);
			int oldpos = GetItemIndex(Name);
			if (oldpos > -1 && Pos != oldpos) {
				Items.RemoveAt(oldpos); // Remove old item
				if (oldpos < Pos)
					newpos--; // Adjust new position
				Items.Insert(newpos, CurItem); // Insert new item
			}
		}

		// Render list options
		public void Render(string aPart, string aPos = "", object aRowCnt = null, string aScriptType = "block", string aScriptId = "", string aScriptClassName = "") {
			if (ewr_NotEmpty(aScriptId)) {
				RenderEx(aPart, aPos, aRowCnt, "block", aScriptId, aScriptClassName); // original block for ew_ShowTemplates
				RenderEx(aPart, aPos, aRowCnt, "blocknotd", aScriptId);
				RenderEx(aPart, aPos, aRowCnt, "single", aScriptId);
			} else {
				RenderEx(aPart, aPos, aRowCnt, aScriptType, aScriptId, aScriptClassName);
			}
		}

		// Render list options
		public void RenderEx(string aPart, string aPos = "", object aRowCnt = null, string aScriptType = "block", string aScriptId = "", string aScriptClassName = "") {
			RowCnt = Convert.ToString(aRowCnt);
			ScriptType = aScriptType;
			ScriptId = aScriptId;
			ScriptClassName = aScriptClassName;
			JavaScript = "";
			Tag = (ewr_NotEmpty(aPos)) ? "td" : "span";
			if (ewr_NotEmpty(CustomItem)) {
				crListOption opt = null;
				int cnt = 0;
				foreach (var item in Items) {
					if (item.Visible && (ewr_NotEmpty(ScriptId) || ShowPos(item.OnLeft, aPos)))
						cnt++;
					if (item.Name == CustomItem)
						opt = item;
				}
				if (opt != null && cnt > 0) {
					if (ewr_NotEmpty(ScriptId) || ShowPos(opt.OnLeft, aPos)) {
						ewr_Write(opt.Render(aPart, cnt));
					} else {
						ewr_Write(opt.Render("", cnt));
					}
				}
			} else {
				foreach (var item in Items) {
					if (item.Visible && (ewr_NotEmpty(ScriptId) || ShowPos(item.OnLeft, aPos)))
						ewr_Write(item.Render(aPart, 1));
				}
			}
		}		

		// Show position
		private bool ShowPos(bool OnLeft, string Pos)
		{
			return (OnLeft && Pos == "left") || (!OnLeft && Pos == "right") || (Pos == "");
		}

		// Concat options and return concatenated HTML
		// pattern - regular expression pattern for matching the option names, e.g. "^detail_"
		public string Concat(string pattern, string separator = "") {
			var ar = new List<string>();
			foreach (var item in Items) {
				if (Regex.IsMatch(item.Name, pattern) && ewr_NotEmpty(item.Body))
					ar.Add(item.Body);
			}
			return String.Join(separator, ar);
		}

		// Merge options to the first option and return it
		// pattern - regular expression pattern for matching the option names, e.g. "^detail_"
		public crListOption Merge(string pattern, string separator = "") {
			crListOption first = null;
			foreach (var item in Items) {
				if (Regex.IsMatch(item.Name, pattern)) {
					if (first == null) {
						first = item;
						first.Body = Concat(pattern, separator);
					} else {
						item.Visible = false;
					}
				}
			}
			return first;
		}
	}

	//
	//  List option class
	//	
	public class crListOption
	{

		public string Name = "";

		public bool OnLeft = false;

		public string CssStyle = "";

		public string CssClass = "";

		public bool Visible = true;

		public string Header = "";

		public string Body = "";

		public string Footer = "";

		public string Tag = "td";

		public string Separator = "";

		public crListOptions Parent;

		// Constructor
		public crListOption(string aName)
		{
			Name = aName;
		}

		// Move
		public void MoveTo(int Pos) {
			Parent.MoveItem(Name, Pos);
		}

		// Render
		public string Render(string Part, int ColSpan = 1) {
			var tagclass = Parent.TagClassName;
			var value = "";
			if (Part == "header") {
				if (tagclass == "") tagclass = "ewListOptionHeader";
				value = Header;
			} else if (Part == "body") {
				if (tagclass == "") {
					if (Parent.Tag == "td")
						tagclass = "ewListOptionBody";
					else
						tagclass = "ewListOptionBody2";
				}
				value = Body;
			} else if (Part == "footer") {
				if (tagclass == "") tagclass = "ewListOptionFooter";
				value = Footer;
			} else {
				value = Part;
			}
			if (ewr_Empty(value) && Parent.Tag == "span" && ewr_Empty(Parent.ScriptId))
				return "";
			var res = (ewr_NotEmpty(value)) ? value : "&nbsp;";
			ewr_AppendClass(tagclass, CssClass);
			var attrs = new Dictionary<string, string>() {{"class", tagclass}, {"style", CssStyle}};
			if (ewr_SameText(Parent.Tag, "td") && Parent.RowSpan > 1)
				attrs["rowspan"] = Convert.ToString(Parent.RowSpan);
			if (ewr_SameText(Parent.Tag, "td") && ColSpan > 1)
				attrs["colspan"] = Convert.ToString(ColSpan);
			var name = Parent.TableVar + "_" + Name;
			if (Part == "header")
				res = "<span id=\"elh_" + name + "\" class=\"" + name + "\">" + res + "</span>";
			else if (Part == "body")
				res = "<span id=\"el" + Parent.RowCnt + "_" + name + "\" class=\"" + name + "\">" + res + "</span>";
			else if (Part == "footer")
				res = "<span id=\"elf_" + name + "\" class=\"" + name + "\">" + res + "</span>";
			res = ewr_HtmlElement(Parent.Tag, attrs, res);

//			if (ewr_NotEmpty(Parent.ScriptId)) {
//				var js = ewr_ExtractScript(ref res, Parent.ScriptClassName + "_js");
//				if (Parent.ScriptType == "single") {
//					if (Part == "header")
//						res = "<script id=\"tpoh_" + Parent.ScriptId + "_" + Name + "\" type=\"text/html\">" + res + "</script>";
//					else if (Part == "body")
//						res = "<script id=\"tpob" + Parent.RowCnt + "_" + Parent.ScriptId + "_" + Name + "\" type=\"text/html\">" + res + "</script>";
//					else if (Part == "footer")
//						res = "<script id=\"tpof_" + Parent.ScriptId + "_" + Name + "\" type=\"text/html\">" + res + "</script>";
//				}
//				if (ewr_NotEmpty(js))
//					if (Parent.ScriptType == "single")
//						res += js;
//					else
//						Parent.JavaScript += js;
//			}

			return res;
		}
	}

	//
	// CSS parser
	//
	public class crCssParser
	{

		public Dictionary<string, Dictionary<string, string>> css;

		// Constructor
		public crCssParser()
		{
			css = new Dictionary<string, Dictionary<string, string>>();
		}

		// Clear all styles
		public void Clear()
		{
			foreach (var kvp in css)
				kvp.Value.Clear();
			css.Clear();
		}

		// add a section
		public void Add(string key, string codestr)
		{
			key = key.ToLower().Trim();
			if (key == "")
				return;
			codestr = codestr.ToLower();
			if (!css.ContainsKey(key))
				css[key] = new Dictionary<string, string>();
			string[] codes = codestr.Split(new char[] { ';' });
			if (codes.Length > 0)
			{
				foreach (string code in codes)
				{
					string sCode = code.ToLower();
					string[] arCode = code.Split(new char[] { ':' });
					string codekey = arCode[0];
					string codevalue = "";
					if (arCode.Length > 1)
						codevalue = arCode[1];
					if (codekey.Length > 0)
					{
						css[key][codekey.Trim()] = codevalue.Trim();
					}
				}
			}
		}

		// explode a string into two
		private void Explode(string str, char sep, ref string str1, ref string str2)
		{
			string[] ar = str.Split(new char[] { sep });
			str1 = ar[0];
			if (ar.Length > 1)
				str2 = ar[1];
		}

		// Get a style
		public string Get(string key, string property)
		{
			key = key.ToLower();

			property = property.ToLower();
			string tag = "", subtag = "", cls = "", id = "";
			Explode(key, ':', ref tag, ref subtag);
			Explode(tag, '.', ref tag, ref cls);
			Explode(tag, '#', ref tag, ref id);
			string result = "";
			foreach (var kvp in css) {
				string _tag = kvp.Key;
				Dictionary<string, string> value = kvp.Value;
				string _subtag = "", _cls = "", _id = "";
				Explode(_tag, ':', ref _tag, ref _subtag);
				Explode(_tag, '.', ref _tag, ref _cls);
				Explode(_tag, '#', ref _tag, ref _id);
				bool tagmatch = (tag == _tag || _tag.Length == 0);
				bool subtagmatch = (subtag == _subtag || _subtag.Length == 0);
				bool classmatch = (cls == _cls || _cls.Length == 0);
				bool idmatch = (id == _id);
				if (tagmatch && subtagmatch && classmatch && idmatch)
				{
					string temp = _tag;
					if (temp.Length > 0 && _cls.Length > 0)
					{
						temp += "." + _cls;
					}
					else if (temp.Length == 0)
					{
						temp = "." + _cls;
					}
					if (temp.Length > 0 && _subtag.Length > 0)
					{
						temp += ":" + _subtag;
					}
					else if (temp.Length == 0)
					{
						temp = ":" + _subtag;
					}
					if (css[temp].ContainsKey(property))
						result = css[temp][property];
				}
			}
			return result;
		}

		// Get section as dictionary
		public Dictionary<string, string> GetSection(string key)
		{
			key = key.ToLower();
			string tag = "", subtag = "", cls = "", id = "";
			Explode(key, ':', ref tag, ref subtag);
			Explode(tag, '.', ref tag, ref cls);
			Explode(tag, '#', ref tag, ref id);
			Dictionary<string, string> result = new Dictionary<string, string>();
			foreach (var kvp in css) {
				string _tag = kvp.Key;
				Dictionary<string, string> value = kvp.Value;
				string _subtag = "", _cls = "", _id = "";
				Explode(_tag, ':', ref _tag, ref _subtag);
				Explode(_tag, '.', ref _tag, ref _cls);
				Explode(_tag, '#', ref _tag, ref _id);
				bool tagmatch = (tag == _tag || _tag.Length == 0);
				bool subtagmatch = (subtag == _subtag || _subtag.Length == 0);
				bool classmatch = (cls == _cls || _cls.Length == 0);
				bool idmatch = (id == _id);
				if (tagmatch && subtagmatch && classmatch && idmatch)
				{
					string temp = _tag;
					if (temp.Length > 0 && _cls.Length > 0)
					{
						temp += "." + _cls;
					}
					else if (temp.Length == 0)
					{
						temp = "." + _cls;
					}
					if (temp.Length > 0 && _subtag.Length > 0)
					{
						temp += ":" + _subtag;
					}
					else if (temp.Length == 0)
					{
						temp = ":" + _subtag;
					}
					foreach (KeyValuePair<string, string> kv in css[temp])
					{
						result[kv.Key] = kv.Value;
					}
				}
			}
			return result;
		}

		// Get section as string
		public string GetSectionString(string key)
		{
			Dictionary<string, string> dict = GetSection(key);
			string result = "";
			foreach (var kv in dict)
				result += kv.Key + ":" + kv.Value + ";"; // no spaces
			return result;
		}

		// Parse string
		public bool ParseStr(string str)
		{
			Clear();

			// Remove comments
			str = Regex.Replace(str, @"\/\*(.*)?\*\/", "");

			// Parse the csscode
			string[] parts = str.Split(new char[] { '}' });
			if (parts.Length > 0)
			{
				foreach (string part in parts)
				{
					string keystr = "", codestr = "";
					Explode(part, '{', ref keystr, ref codestr);
					string[] keys = keystr.Split(new char[] { ',' });
					if (keys.Length > 0)
					{
						foreach (string akey in keys)
						{
							string key = akey;
							if (key.Length > 0)
							{
								key = key.Replace("\n", "");
								key = key.Replace("\\", "");
								Add(key, codestr.Trim());
							}
						}
					}
				}
			}
			return (css.Count > 0);
		}

		// Parse a stylesheet
		public bool ParseFile(string filename)
		{
			Clear();
			if (File.Exists(filename))
			{
				return ParseStr(File.ReadAllText(filename));
			}
			else
			{
				return false;
			}
		}

		// Get CSS string
		public string GetCSS()
		{
			string result = "";
			foreach (var kvp in css)
			{
				result += kvp.Key + " {\n";
				foreach (KeyValuePair<string, string> kv in kvp.Value)
				{
					result += "  " + kv.Key + ": " + kv.Value + ";\n";
				}
				result += "}\n\n";
			}
			return result;
		}
	}

	//
	// Advanced Security class
	//
	public class cAdvancedSecurityBase {

		private List<string[]> UserLevel = new List<string[]>();

		private List<string[]> UserLevelPriv = new List<string[]>();

		private List<int> UserLevelID = new List<int>();

		private List<string> UserID = new List<string>{};

		// Current User Level ID / User Level
		public int CurrentUserLevelID;

		public int CurrentUserLevel;

		// Current User ID / Parent User ID
		public string CurrentUserID;

		public string CurrentParentUserID;		

		// Init
		public cAdvancedSecurityBase() {

			// Init User Level
			CurrentUserLevelID = SessionUserLevelID;
			if (ewr_IsNumeric(CurrentUserLevelID)) {
				if (CurrentUserLevelID >= -1)					
					UserLevelID.Add(CurrentUserLevelID);
			}

			// Init User ID
			CurrentUserID = Convert.ToString(SessionUserID);
			CurrentParentUserID = Convert.ToString(SessionParentUserID);

			// Load user level (for TablePermission_Loading event)
			LoadUserLevel();
		}		

		// Session User ID
		public object SessionUserID {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_USER_ID]); }
			set {
				ewr_Session[EWR_SESSION_USER_ID] = Convert.ToString(value).Trim();
				CurrentUserID = Convert.ToString(value).Trim();
			}
		}

		// Session parent User ID
		public object SessionParentUserID {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_PARENT_USER_ID]); }
			set {
				ewr_Session[EWR_SESSION_PARENT_USER_ID] = Convert.ToString(value).Trim();
				CurrentParentUserID = Convert.ToString(value).Trim();
			}
		}

		// Current user name
		public string CurrentUserName {
			get { return Convert.ToString(ewr_Session[EWR_SESSION_USER_NAME]); }
			set { ewr_Session[EWR_SESSION_USER_NAME] = value; }
		}

		// Session User Level ID		
		public int SessionUserLevelID {
			get { return Convert.ToInt32(ewr_Session[EWR_SESSION_USER_LEVEL_ID]); }
			set {
				ewr_Session[EWR_SESSION_USER_LEVEL_ID] = value;
				CurrentUserLevelID = value;
				if (ewr_IsNumeric(CurrentUserLevelID)) {
					if (CurrentUserLevelID >= -1) {					
						UserLevelID.Clear();
						UserLevelID.Add(CurrentUserLevelID);
					}
				}
			}
		}

		// Session User Level value	
		public int SessionUserLevel {
			get { return Convert.ToInt32(ewr_Session[EWR_SESSION_USER_LEVEL]); }
			set {
				ewr_Session[EWR_SESSION_USER_LEVEL] = value;
				CurrentUserLevel = value;
				if (ewr_IsNumeric(CurrentUserLevelID)) {
					if (CurrentUserLevelID >= -1) {
						UserLevelID.Clear();
						UserLevelID.Add(CurrentUserLevelID);
					}
				}
			}
		}

		// Can list
		public bool CanList {
			get { return ((CurrentUserLevel & EWR_ALLOW_LIST) == EWR_ALLOW_LIST); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EWR_ALLOW_LIST);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EWR_ALLOW_LIST));
				}
			}
		}

		// Can report		
		public bool CanReport {
			get { return ((CurrentUserLevel & EWR_ALLOW_REPORT) == EWR_ALLOW_REPORT); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EWR_ALLOW_REPORT);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EWR_ALLOW_REPORT));
				}
			}
		}

		// Can admin		
		public bool CanAdmin {
			get { return ((CurrentUserLevel & EWR_ALLOW_ADMIN) == EWR_ALLOW_ADMIN); }
			set {
				if (value) {
					CurrentUserLevel = (CurrentUserLevel | EWR_ALLOW_ADMIN);
				} else {
					CurrentUserLevel = (CurrentUserLevel & (~EWR_ALLOW_ADMIN));
				}
			}
		}

		// Last URL
		public string LastUrl {
			get { return ewr_Cookie["lasturl"]; }
		}

		// Save last URL
		public void SaveLastUrl()
		{
			string s = ewr_ServerVar("SCRIPT_NAME");
			string q = ewr_ServerVar("QUERY_STRING");
			if (ewr_NotEmpty(q)) s = s + "?" + q; 
			if (LastUrl == s) s = ""; 
			ewr_Cookie["lasturl"] = s;
		}

		// Auto login
		public bool AutoLogin()
		{
			if (ewr_SameStr(ewr_Cookie["autologin"], "autologin")) {
				string sUsr = ewr_Cookie["username"];
				string sPwd = ewr_Cookie["password"];
				sUsr = ewr_Decrypt(sUsr);
				sPwd = ewr_Decrypt(sPwd);
				bool bValid = ValidateUser(sUsr, sPwd, true);
				return bValid;
			} else {
				return false;
			}
		}	

		// Validate user
		public bool ValidateUser(string usr, string pwd, bool autologin)
		{
			bool result = false;
			string sFilter;
			string sSql;
			bool CustomValidateUser = false;

			// Call User Custom Validate event
			if (EWR_USE_CUSTOM_LOGIN) {
				CustomValidateUser = User_CustomValidate(ref usr, ref pwd);
				if (CustomValidateUser) {
					ewr_Session[EWR_SESSION_STATUS] = "login";
					CurrentUserName = usr; // Load user name
				}
			}
			if (CustomValidateUser)
				return CustomValidateUser;
			if (!result && !IsPasswordExpired())
				ewr_Session[EWR_SESSION_STATUS] = ""; // Clear login status 
			return result;
		}

		// No user level security
		public void SetUpUserLevel() {
		}

		// Add user permission
		public void AddUserPermission(string UserLevelName, string TableName, int UserPermission)
		{
			string UserLevelID = "";

			// Get user level ID from user name
			if (ewr_IsList(UserLevel)) {
				foreach (string[] row in UserLevel) {
					if (ewr_SameStr(UserLevelName, row[1])) {
						UserLevelID = Convert.ToString(row[0]);
						break;
					}
				}
			}
			if (ewr_IsList(UserLevelPriv) && ewr_NotEmpty(UserLevelID)) {
				foreach (string[] row in UserLevelPriv) {
					if (ewr_SameStr(row[0], EWR_PROJECT_ID + TableName) && ewr_SameStr(row[1], UserLevelID)) {
						row[2] = Convert.ToString(ewr_ConvertToInt(row[2]) | UserPermission);	// Add permission
						break;
					}
				}
			}
		}

		// Delete user permission
		public void DeleteUserPermission(string UserLevelName, string TableName, int UserPermission)
		{
			string UserLevelID = "";

			// Get user level ID from user name
			if (ewr_IsList(UserLevel)) {
				foreach (string[] Row in UserLevel) {
					if (ewr_SameStr(UserLevelName, Row[1])) {
						UserLevelID = Convert.ToString(Row[0]);
						break;
					}
				}
			}
			if (ewr_IsList(UserLevelPriv) && ewr_NotEmpty(UserLevelID)) {
				foreach (string[] Row in UserLevelPriv) {
					if (ewr_SameStr(Row[0], EWR_PROJECT_ID + TableName) && ewr_SameStr(Row[1], UserLevelID)) {
						Row[2] = Convert.ToString(ewr_ConvertToInt(Row[2]) & (127 - UserPermission));	// Remove permission
						break;
					}
				}
			}
		}

		// Load current user level
		public void LoadCurrentUserLevel(string Table)
		{
			LoadUserLevel();
			SessionUserLevel = CurrentUserLevelPriv(Table);
		}

		// Get current user privilege
		private int CurrentUserLevelPriv(string TableName)
		{
			int result = 0;
			if (IsLoggedIn) {
				foreach (int id in UserLevelID)
					result = result | GetUserLevelPrivEx(TableName, id);
			}
			return result;
		}

		// Get user level ID by user level name
		public int GetUserLevelID(string UserLevelName)
		{
			if (ewr_SameStr(UserLevelName, "Administrator")) {
				return -1;
			} else if (ewr_NotEmpty(UserLevelName)) {
				if (ewr_IsList(UserLevel)) {
					foreach (string[] Row in UserLevel) {
						if (ewr_SameStr(Row[1], UserLevelName))
							return ewr_ConvertToInt(Row[0]);
					}
				}
			}
			return -2;	// Unknown
		}

		// Add Add User Level by name (for use with TablePermission_Loading)
		public void AddUserLevel(string UserLevelName)
		{
			if (ewr_Empty(UserLevelName))
				return;
			int id = GetUserLevelID(UserLevelName);
			AddUserLevelID(id);
		}

		// Add User Level by ID (for use with TablePermission_Loading)
		public void AddUserLevelID(int id)
		{
			if (!ewr_IsNumeric(id) || id < -1)
				return;
			if (UserLevelID.IndexOf(id) < 0)
				UserLevelID.Add(id);	
		}

		// Delete User Level by name (for use with TablePermission_Loading)
		public void DeleteUserLevel(string UserLevelName)
		{
			if (ewr_Empty(UserLevelName)) return;
			int id = GetUserLevelID(UserLevelName);
			DeleteUserLevelID(id);
		}

		// Delete User Level by ID (for use with TablePermission_Loading)
		public void DeleteUserLevelID(int id) {
			if (!ewr_IsNumeric(id) || id < -1)
				return;
			int index = UserLevelID.IndexOf(id);
			if (index > -1)
				UserLevelID.RemoveAt(index);	
		}

		// User level list
		public string UserLevelList()
		{
			return String.Join(", ", UserLevelID);
		}

		// User level name list
		public string UserLevelNameList()
		{
			string List = "";			
			foreach (int id in UserLevelID) {
				if (ewr_NotEmpty(List)) List += ", "; 
				List += ewr_QuotedValue(GetUserLevelName(id), EWR_DATATYPE_STRING);
			}
			return List;
		}

		// Get user privilege based on table name and user level
		public int GetUserLevelPrivEx(string TableName, int UserLevelID)
		{
			if (ewr_SameStr(UserLevelID, "-1")) { // System Administrator				

//				if (EWR_USER_LEVEL_COMPAT) {
//					return 31;	// Use old user level values
//				} else {

					return 127;	// Use new user level values (separate View/Search)

//				}
			} else if (UserLevelID >= 0) {
				if (ewr_IsList(UserLevelPriv)) {
					foreach (string[] Row in UserLevelPriv) {
						if (ewr_SameStr(Row[0], TableName) && ewr_SameStr(Row[1], UserLevelID))
							return ewr_ConvertToInt(Row[2]);
					}
				}
			}
			return 0;
		}

		// Get current user level name
		public string CurrentUserLevelName
		{
			get {
				return GetUserLevelName(CurrentUserLevelID);
			}
		}

		// Get user level name based on user level
		public string GetUserLevelName(int UserLevelID)
		{
			if (ewr_SameStr(UserLevelID, "-1")) {
				return "Administrator";
			} else if (UserLevelID >= 0) {
				if (ewr_IsList(UserLevel)) {
					foreach (string[] Row in UserLevel) {
						if (ewr_SameStr(Row[0], UserLevelID)) {
							return Convert.ToString(Row[1]);
						}
					}
				}
			}
			return "";
		}

		// Display all the User Level settings (for debug only)
		public void ShowUserLevelInfo()
		{
			if (ewr_IsList(UserLevel)) {
				ewr_Write("User Levels:<br>");
				ewr_Write("UserLevelId, UserLevelName<br>");
				foreach (string[] Row in UserLevel)
					ewr_Write("&nbsp;&nbsp;" + String.Join(", ", Row) + "<br>");
			} else {
				ewr_Write("No User Level definitions." + "<br>");
			}
			if (ewr_IsList(UserLevelPriv)) {
				ewr_Write("User Level Privs:<br>");
				ewr_Write("TableName, UserLevelId, UserLevelPriv<br>");
				foreach (string[] Row in UserLevelPriv)
					ewr_Write("&nbsp;&nbsp;" + String.Join(", ", Row) + "<br>");
			} else {
				ewr_Write("No User Level privilege settings." + "<br>");
			}
			ewr_Write("CurrentUserLevel = " + CurrentUserLevel + "<br>");
			ewr_Write("User Levels = " + UserLevelList() + "<br>");
		}

		// Check privilege for List page (for menu items)
		public bool AllowList(string TableName)
		{
			return ewr_ConvertToBool(CurrentUserLevelPriv(TableName) & EWR_ALLOW_LIST);
		}

//		// Check privilege for Add page (for Allow-Add / Detail-Add)
//		public bool AllowAdd(string TableName)
//		{
//			return ewr_ConvertToBool(CurrentUserLevelPriv(TableName) & EWR_ALLOW_ADD);
//		}
//		
//		// Check privilege for Edit page (for Detail-Edit)
//		public bool AllowEdit(string TableName) {
//			return ewr_ConvertToBool(CurrentUserLevelPriv(TableName) & EWR_ALLOW_EDIT);
//		}		
//		
//		// Check if user password expired
//		public bool IsPasswordExpired
//		{
//			get {
//				return ewr_SameStr(ewr_Session[EWR_SESSION_STATUS], "passwordexpired");
//			}
//		}
		// Check if user is logging in (after changing password)
		public bool IsLoggingIn
		{
			get {
				return ewr_SameStr(ewr_Session[EWR_SESSION_STATUS], "loggingin");
			}
		}

		// Check if user is logged in
		public bool IsLoggedIn
		{
			get {
				return ewr_SameStr(ewr_Session[EWR_SESSION_STATUS], "login");
			}
		}

		// Check if user is system administrator
		public bool IsSysAdmin
		{
			get {
				return (Convert.ToInt32(ewr_Session[EWR_SESSION_SYS_ADMIN]) == 1);
			}
		}

		// Check if user is administrator
		public bool IsAdmin
		{
			get {
				bool res = IsSysAdmin;
				return res;
			}
		}

		// Save user level to session
		public void SaveUserLevel()
		{
			ewr_Session[EWR_SESSION_AR_USER_LEVEL] = UserLevel;
			ewr_Session[EWR_SESSION_AR_USER_LEVEL_PRIV] = UserLevelPriv;
		}

		// Load user level from session
		public void LoadUserLevel()
		{
			if (!ewr_IsList(ewr_Session[EWR_SESSION_AR_USER_LEVEL]) || !ewr_IsList(ewr_Session[EWR_SESSION_AR_USER_LEVEL_PRIV])) { 
				SetUpUserLevel();
				SaveUserLevel();
			} else {
				UserLevel = (List<string[]>)ewr_Session[EWR_SESSION_AR_USER_LEVEL];
				UserLevelPriv = (List<string[]>)ewr_Session[EWR_SESSION_AR_USER_LEVEL_PRIV];
			}
		}

		// UserID Loading event
		public virtual void UserID_Loading() {

			//ewr_Write("UserID Loading: " + CurrentUserID + "<br>");
		}

		// UserID Loaded event
		public virtual void UserID_Loaded() {

			//ewr_Write("UserID Loaded: " + UserIDList() + "<br>");
		}

		// User Level Loaded event
		public virtual void UserLevel_Loaded() {

			//AddUserPermission(<UserLevelName>, <TableName>, <UserPermission>);
			//DeleteUserPermission(<UserLevelName>, <TableName>, <UserPermission>);

		}

		// User Custom Validate event
		public virtual bool User_CustomValidate(ref string usr, ref string pwd) {

			// Enter your custom code to validate user, return true if valid.
			return false;
		}

		// User Validated event
		public virtual void User_Validated(ewDataReader dr) {

			// Example:
			//ewr_Session["UserEmail"] = dr["Email"];

		}
	}

	// Allow list
	public bool AllowList(string TableName)
	{
		if (Security != null)
			return Security.AllowList(TableName);
		return true;
	}

	// Check if valid operator
	public static bool ewr_IsValidOpr(string Opr, int FldType)
	{
		bool Valid = (Opr == "=" || Opr == "<" || Opr == "<=" || Opr == ">" || Opr == ">=" || Opr == "<>");
		if (FldType == EWR_DATATYPE_STRING || FldType == EWR_DATATYPE_MEMO) {
			Valid = Valid || Opr == "LIKE" || Opr == "NOT LIKE" || Opr == "STARTS WITH";
		}
		return Valid;
	}

	// Quoted name for table/field
	public static string ewr_QuotedName(string Name)
	{
		return EWR_DB_QUOTE_START + Name.Replace(EWR_DB_QUOTE_END, EWR_DB_QUOTE_END + EWR_DB_QUOTE_END) + EWR_DB_QUOTE_END;
	}

	// Quoted value for field type
	public static string ewr_QuotedValue(object Value, int FldType)
	{
		if (Convert.IsDBNull(Value))
			return "NULL";
		switch (FldType) {
			case EWR_DATATYPE_STRING:
			case EWR_DATATYPE_MEMO:
				return "'" + ewr_AdjustSql(Value) + "'";
			case EWR_DATATYPE_GUID:
				if (EWR_IS_MSACCESS) {
					if (Convert.ToString(Value).StartsWith("{")) {
						return Convert.ToString(Value);
					} else {
						return "{" + ewr_AdjustSql(Value) + "}";
					}
				} else {
					return "'" + ewr_AdjustSql(Value) + "'";
				}
				break;
			case EWR_DATATYPE_DATE:				
			case EWR_DATATYPE_TIME:
				if (Value is DateTime) { // AXR
					if (FldType == EWR_DATATYPE_DATE) {
						Value = ((DateTime)Value).ToString("yyyy'/'MM'/'dd HH':'mm':'ss");
					} else {
						Value = ((DateTime)Value).ToString("HH':'mm':'ss");
					}
				}			
				if (EWR_IS_MSACCESS) {
					return "#" + ewr_AdjustSql(Value) + "#";
				} else if (EWR_IS_ORACLE) { 
					return "TO_DATE('" + ewr_AdjustSql(Value) + "', 'YYYY/MM/DD HH24:MI:SS')"; 
				} else {
					return "'" + ewr_AdjustSql(Value) + "'";
				}
				break;
			default:
				return Convert.ToString(Value);
		}
	}

	// Get distinct values
	public static List<string> ewr_GetDistinctValues(string FldOpr, string sql, string dlm = "")
	{
		if (ewr_Empty(sql))
			return null;
		var ar = new List<string>();
		var rswrk = Conn.GetRows(sql);
		if (rswrk != null) {
			foreach (var row in rswrk) {
				var wrkval = ewr_ConvertValue(FldOpr, row[0]);
				string[] arval;
				if (ewr_NotEmpty(dlm)) {
					arval = wrkval.Split(new char[] { Convert.ToChar(dlm) });
				} else {
					arval = new string[] { wrkval };
				}
				foreach (var val in arval) {
					if (!ar.Contains(val))
						ar.Add(val);
				}				
			}
		}
		return ar;
	}

	// Convert value
	public static string ewr_ConvertValue(string FldOpr, object val) {
		if (Convert.IsDBNull(val)) {
			return EWR_NULL_VALUE;
		} else if (ewr_Empty(val)) {
			return EWR_EMPTY_VALUE;			
		}
        if (ewr_Empty(FldOpr))
		    return Convert.ToString(val);
        if (ewr_IsDate(val)) {
		    var DT = Convert.ToDateTime(val);		
		    switch (FldOpr.ToLower()) {
			    case "year":
				    return Convert.ToString(DT.Year);
			    case "quarter":				
				    return DT.Year + "|" + ewr_DatePart(DateInterval.Quarter, DT);
			    case "month":
				    return DT.Year + "|" + DT.Month;
			    case "day":
				    return DT.Year + "|" + DT.Month + "|" + DT.Day;
			    case "date":
				    return DT.Year + "/" + DT.Month + "/" + DT.Day;
		    }
        }
		return Convert.ToString(val);
	}

	// Dropdown display values
	public static string ewr_DropDownDisplayValue(object v, string t, int fmt)
	{
		if (ewr_SameStr(v, EWR_NULL_VALUE)) {
			return ReportLanguage.Phrase("NullLabel");			
		} else if (ewr_SameStr(v, EWR_EMPTY_VALUE)) {
			return ReportLanguage.Phrase("EmptyLabel");
		} else if (ewr_SameText(t, "boolean")) {
			return ewr_BooleanName(v);
		}
		string[] ar = Convert.ToString(v).Split(new char[] {'|'});
		switch (t.ToLower()) {
			case "year":
				return Convert.ToString(v);
			case "quarter":
				if (ar.Length >= 1)
					return ewr_QuarterName(ar[1]) + " " + ar[0];
				break;
			case "month":
				if (ar.Length >= 1)
					return ewr_MonthName(ar[1]) + " " + ar[0];
				break;
			case "day":
				if (ar.Length >= 2)
					return ewr_FormatDateTime(Convert.ToDateTime(ar[0] + "/" + ar[1] + "/" + ar[2]), fmt);
				break;
			case "date":
				if (ewr_IsDate(v))
					return ewr_FormatDateTime(v, fmt);
				break;
		}
		return Convert.ToString(v);
	}	

	// Get Boolean Name
	// - Treat "T" / "True" / "Y" / "Yes" / "1" As True
	public static string ewr_BooleanName(object v) {
		if (Convert.IsDBNull(v)) {
			return ReportLanguage.Phrase("NullLabel");
		} else if (ewr_SameText(v, "true") || ewr_SameText(v, "yes") ||
			ewr_SameText(v, "t") || ewr_SameText(v, "y") || ewr_SameText(v, "1")) {
			return ReportLanguage.Phrase("BooleanYes");
		} else {
			return ReportLanguage.Phrase("BooleanNo");
		}
	}

	// Quarter name
	public static string ewr_QuarterName(object q) {
		switch (Convert.ToInt32(q)) {
			case 1:
				return ReportLanguage.Phrase("Qtr1");
			case 2:
				return ReportLanguage.Phrase("Qtr2");
			case 3:
				return ReportLanguage.Phrase("Qtr3");
			case 4:
				return ReportLanguage.Phrase("Qtr4");
		}
		return Convert.ToString(q);
	}

	// Month name
	public static string ewr_MonthName(object m) {
		switch (Convert.ToInt32(m)) {
			case 1:
				return ReportLanguage.Phrase("MonthJan");				
			case 2:
				return ReportLanguage.Phrase("MonthFeb");				
			case 3:
				return ReportLanguage.Phrase("MonthMar");				
			case 4:
				return ReportLanguage.Phrase("MonthApr");				
			case 5:
				return ReportLanguage.Phrase("MonthMay");				
			case 6:
				return ReportLanguage.Phrase("MonthJun");				
			case 7:
				return ReportLanguage.Phrase("MonthJul");				
			case 8:
				return ReportLanguage.Phrase("MonthAug");				
			case 9:
				return ReportLanguage.Phrase("MonthSep");				
			case 10:
				return ReportLanguage.Phrase("MonthOct");				
			case 11:
				return ReportLanguage.Phrase("MonthNov");				
			case 12:
				return ReportLanguage.Phrase("MonthDec");				
		}
		return Convert.ToString(m);
	}

	// Join array
	public static string ewr_JoinArray(object ar, string sep, int ft, int pos = 0) {		
		if (!ewr_IsList(ar))
			return "";
		var str = "";
		var list = (IList)ar;
		for (int i = pos; i < list.Count; i++) {
			if (str != "") str += ", ";
			str += ewr_QuotedValue(list[i], ft);
		}
		return str;
	}

	// Functions for default date format
	// ANamedFormat = 0-8, where 0-4 same as VBScript
	// 5 = "yyyy/mm/dd"
	// 6 = "mm/dd/yyyy"
	// 7 = "dd/mm/yyyy"
	// 8 = Short Date + Short Time
	// 9 = "yyyy/mm/dd HH:MM:SS"
	// 10 = "mm/dd/yyyy HH:MM:SS"
	// 11 = "dd/mm/yyyy HH:MM:SS"
	// 12 - Short Date - 2 digit year (yy/mm/dd)
	// 13 - Short Date - 2 digit year (mm/dd/yy)
	// 14 - Short Date - 2 digit year (dd/mm/yy)
	// 15 - Short Date (yy/mm/dd) + Short Time (hh:mm:ss)
	// 16 - Short Date (mm/dd/yy) + Short Time (hh:mm:ss)
	// 17 - Short Date (dd/mm/yy) + Short Time (hh:mm:ss)
	// Format date time based on format type
	public static string ewr_FormatDateTime(object ADate, int ANamedFormat)
	{
		string sDT;
		if (Information.IsDate(ADate)) {
			DateTime DT = Convert.ToDateTime(ADate);
			if (ANamedFormat >= 0 && ANamedFormat <= 4) {
				sDT = Strings.FormatDateTime(DT, (DateFormat)Enum.ToObject(typeof(DateFormat), ANamedFormat));
			} else if (ANamedFormat == 5 || ANamedFormat == 9) {
				sDT = DT.ToString("yyyy'" + EWR_DATE_SEPARATOR + "'MM'" + EWR_DATE_SEPARATOR + "'dd");
			} else if (ANamedFormat == 6 || ANamedFormat == 10) {
				sDT = DT.ToString("MM'" + EWR_DATE_SEPARATOR + "'dd'" + EWR_DATE_SEPARATOR + "'yyyy");
			} else if (ANamedFormat == 7 || ANamedFormat == 11) {
				sDT = DT.ToString("dd'" + EWR_DATE_SEPARATOR + "'MM'" + EWR_DATE_SEPARATOR + "'yyyy");
			} else if (ANamedFormat == 8) {
				sDT = Strings.FormatDateTime(DT, (DateFormat)Enum.ToObject(typeof(DateFormat), 2));
				if (DT.Hour != 0 || DT.Minute != 0 || DT.Second != 0)
					sDT += " " + DT.ToString("HH':'mm':'ss");
			} else if (ANamedFormat == 12 || ANamedFormat == 15) {
				sDT = DT.ToString("yy'" + EWR_DATE_SEPARATOR + "'MM'" + EWR_DATE_SEPARATOR + "'dd");
			} else if (ANamedFormat == 13 || ANamedFormat == 16) {
				sDT = DT.ToString("MM'" + EWR_DATE_SEPARATOR + "'dd'" + EWR_DATE_SEPARATOR + "'yy");
			} else if (ANamedFormat == 14 || ANamedFormat == 17) {
				sDT = DT.ToString("dd'" + EWR_DATE_SEPARATOR + "'MM'" + EWR_DATE_SEPARATOR + "'yy");	
			} else {
				return DT.ToString();
			}
			if ((ANamedFormat >= 9 && ANamedFormat <= 11) || (ANamedFormat >= 15 && ANamedFormat <= 17))
				sDT += " " + DT.ToString("HH':'mm':'ss");
			return sDT;
		} else {
			return Convert.ToString(ADate);
		}
	}

	// Unformat date time based on format type
	public static string ewr_UnformatDateTime(object ADate, int ANamedFormat)
	{
		string[] arDateTime, arDatePt;
		DateTime d;
		string sDT;
		string sDate = Convert.ToString(ADate).Trim();
		while (sDate.Contains("  "))
			sDate = sDate.Replace("  ", " ");
		if (Regex.IsMatch(sDate, @"^([0-9]{4})/([0][1-9]|[1][0-2])/([0][1-9]|[1|2][0-9]|[3][0|1])( (0[0-9]|1[0-9]|2[0-3]):([0-5][0-9]):([0-5][0-9]))?$")) // ASPX
			return sDate;		
		arDateTime = sDate.Split(new char[] {' '});
		if (ANamedFormat == 0 && Information.IsDate(sDate)) {
			d = Convert.ToDateTime(arDateTime[0]);
			sDT = d.ToString("yyyy'/'MM'/'dd");
			if (arDateTime.Length > 0) {
				for (int i = 1; i < arDateTime.Length; i++)
					sDT = sDT + " " + arDateTime[i];
			}
			return sDT;
		} else {
			arDatePt = arDateTime[0].Split(new char[] { Convert.ToChar(EWR_DATE_SEPARATOR) });
			if (arDatePt.Length == 3) {
				switch (ANamedFormat) {
					case 5:
					case 9: //yyyymmdd
						if (ewr_CheckDate(arDateTime[0])) {
							sDT = arDatePt[0] + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[2].PadLeft(2, '0');							
							break;
						} else {
							return sDate;
						}
					case 6:
					case 10: //mmddyyyy
						if (ewr_CheckUSDate(arDateTime[0])) {
							sDT = arDatePt[2].PadLeft(2, '0') + "/" + arDatePt[0].PadLeft(2, '0') + "/" + arDatePt[1];
							break;
						} else {
							return sDate;
						}
					case 7:
					case 11: //ddmmyyyy
						if (ewr_CheckEuroDate(arDateTime[0])) {
							sDT = arDatePt[2].PadLeft(2, '0') + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[0];
							break;
						} else {
							return sDate;
						}
					case 12:
					case 15: //yymmdd
						if (ewr_CheckShortDate(arDateTime[0])) {
							arDatePt[0] = ewr_UnformatYear(arDatePt[0]);
							sDT = arDatePt[0] + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[2].PadLeft(2, '0');							
							break;
						} else {
							return sDate;
						}
					case 13:
					case 16: //mmddyy
						if (ewr_CheckShortUSDate(arDateTime[0])) {
							arDatePt[2] = ewr_UnformatYear(arDatePt[2]);
							sDT = arDatePt[2] + "/" + arDatePt[0].PadLeft(2, '0') + "/" + arDatePt[1].PadLeft(2, '0');
							break;
						} else {
							return sDate;
						}
					case 14:
					case 17: //ddmmyy
						if (ewr_CheckShortEuroDate(arDateTime[0])) {
							arDatePt[2] = ewr_UnformatYear(arDatePt[2]);
							sDT = arDatePt[2] + "/" + arDatePt[1].PadLeft(2, '0') + "/" + arDatePt[0].PadLeft(2, '0');
							break;
						} else {
							return sDate;
						}
					default:
						return sDate;
				}				
				if (arDateTime.Length > 1) {
					if (Information.IsDate(arDateTime[1])) // Is time
						sDT += " " + arDateTime[1];
				}
				return sDT;
			} else {
				return sDate;
			}
		}
	}

	// ViewValue
	// - return &nbsp; if empty
	public string ewr_ViewValue(object value) {
		if (ewr_NotEmpty(value))
			return Convert.ToString(value);
		else
			return "&nbsp;";
	}

	// Get current year
	public int ewr_CurrentYear() {
		return DateTime.Today.Year;
	}

	// Get current quarter
	public int ewr_CurrentQuarter() {
		return Convert.ToInt32(Math.Ceiling(Convert.ToDouble(DateTime.Today.Month / 3)));
	}

	// Get current month
	public int ewr_CurrentMonth() {
		return DateTime.Today.Month;
	}

	// Get current day
	public int ewr_CurrentDay() {
		return DateTime.Today.Day;
	}

	// Format currency
	// -2 Retain all values after decimal place
	public static string ewr_FormatCurrency(object Expression, int NumDigitsAfterDecimal = -1, int IncludeLeadingDigit = -2, int UseParensForNegativeNumbers = -2, int GroupDigits = -2)
	{
		if (!ewr_IsNumeric(Expression)) return Convert.ToString(Expression);
		if (Convert.IsDBNull(Expression)) return String.Empty;

		// check NumDigitsAfterDecimal
		int FracDigits = -1;
		if (NumDigitsAfterDecimal == -2) { // Use all values after decimal point
			string stramt = Convert.ToString(Expression);
			FracDigits = (stramt.Contains(".")) ? (stramt.Length - stramt.LastIndexOf(".") - 1) : 0;
		} else if (NumDigitsAfterDecimal > -1) {
			FracDigits = NumDigitsAfterDecimal;
		}
		string res = Strings.FormatCurrency(Expression, FracDigits, (Microsoft.VisualBasic.TriState)IncludeLeadingDigit, (Microsoft.VisualBasic.TriState)UseParensForNegativeNumbers, (Microsoft.VisualBasic.TriState)GroupDigits); 
		if (EWR_USE_SYSTEM_LOCALE) {
			return res; 
		} else {
			string DecimalSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencyDecimalSeparator;
			string GroupSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencyGroupSeparator;
			string Symbol = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.CurrencySymbol;
			if (Symbol != EWR_CURRENCY_SYMBOL)
				res = res.Replace(Symbol, EWR_CURRENCY_SYMBOL);
			string str = "";
			bool ReplaceDecimalSeparator = DecimalSeparator != EWR_DECIMAL_POINT;
			bool ReplaceGroupSeparator = GroupSeparator != "" && GroupSeparator != EWR_THOUSANDS_SEP; 
            foreach (char c in res) {
                if (ReplaceDecimalSeparator && ewr_SameStr(c, DecimalSeparator)) {
                    str += EWR_DECIMAL_POINT;
                } else if (ReplaceGroupSeparator && ewr_SameStr(c, GroupSeparator)) {
                    str += EWR_THOUSANDS_SEP;
                } else {
                    str += c;
                }
            }					
			return str;
		}
	}

	// Format number
	// -2 Retain all values after decimal place
	public static string ewr_FormatNumber(object Expression, int NumDigitsAfterDecimal = -1, int IncludeLeadingDigit = -2, int UseParensForNegativeNumbers = -2, int GroupDigits = -2)
	{
		if (!ewr_IsNumeric(Expression)) return Convert.ToString(Expression);
		if (Convert.IsDBNull(Expression)) return String.Empty;

		// check NumDigitsAfterDecimal
		int FracDigits = -1;
		if (NumDigitsAfterDecimal == -2) { // Use all values after decimal point
			string stramt = Convert.ToString(Expression);
			FracDigits = (stramt.Contains(".")) ? (stramt.Length - stramt.LastIndexOf(".") - 1) : 0;
		} else if (NumDigitsAfterDecimal > -1) {
			FracDigits = NumDigitsAfterDecimal;
		}
		string res = Strings.FormatNumber(Expression, FracDigits, (Microsoft.VisualBasic.TriState)IncludeLeadingDigit, (Microsoft.VisualBasic.TriState)UseParensForNegativeNumbers, (Microsoft.VisualBasic.TriState)GroupDigits);
		if (EWR_USE_SYSTEM_LOCALE) {
			return res; 
		} else {
			string DecimalSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberDecimalSeparator;
			string GroupSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.NumberGroupSeparator;			
			bool ReplaceDecimalSeparator = DecimalSeparator != EWR_DECIMAL_POINT;
			bool ReplaceGroupSeparator = GroupSeparator != "" && GroupSeparator != EWR_THOUSANDS_SEP;
			string str = ""; 
            foreach (char c in res) {
                if (ReplaceDecimalSeparator && ewr_SameStr(c, DecimalSeparator)) {
                    str += EWR_DECIMAL_POINT;
                } else if (ReplaceGroupSeparator && ewr_SameStr(c, GroupSeparator)) {
                    str += EWR_THOUSANDS_SEP;
                } else {
                    str += c;
                }
            }					
			return str;
		}
	}

	// Format percent
	public static string ewr_FormatPercent(object Expression,  int NumDigitsAfterDecimal = -1, int IncludeLeadingDigit = -2, int UseParensForNegativeNumbers = -2, int GroupDigits = -2)
	{
		if (!ewr_IsNumeric(Expression)) return Convert.ToString(Expression);
		if (Convert.IsDBNull(Expression)) return String.Empty;
		string res = Strings.FormatPercent(Expression, NumDigitsAfterDecimal, (Microsoft.VisualBasic.TriState)IncludeLeadingDigit, (Microsoft.VisualBasic.TriState)UseParensForNegativeNumbers, (Microsoft.VisualBasic.TriState)GroupDigits);
		if (EWR_USE_SYSTEM_LOCALE) {
			return res; 
		} else {
			string DecimalSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.PercentDecimalSeparator;
			string GroupSeparator = System.Threading.Thread.CurrentThread.CurrentCulture.NumberFormat.PercentGroupSeparator;			
			bool ReplaceDecimalSeparator = DecimalSeparator != EWR_DECIMAL_POINT;
			bool ReplaceGroupSeparator = GroupSeparator != "" && GroupSeparator != EWR_THOUSANDS_SEP;
			string str = ""; 
            foreach (char c in res) {
                if (ReplaceDecimalSeparator && ewr_SameStr(c, DecimalSeparator)) {
                    str += EWR_DECIMAL_POINT;
                } else if (ReplaceGroupSeparator && ewr_SameStr(c, GroupSeparator)) {
                    str += EWR_THOUSANDS_SEP;
                } else {
                    str += c;
                }
            }					
			return str;
		}
	}

	// Create a DIV as container of encrypted SQL for synchronous query
	public static void ewr_CreateQuery(string id, string sql) {
		ewr_Write(ewr_HtmlElement("div", new Dictionary<string, string>() {{"id", id}, {"class", "ewDisplayNone"}}, ewr_Encrypt(sql)));
	}

	// Output SCRIPT tag
	public static void ewr_AddClientScript(string src, Dictionary<string, string> attrs = null) {
		var atts = new Dictionary<string, string>() {{"type", "text/javascript"}, {"src", src}};
		if (attrs != null) {
			foreach (var kvp in attrs)
				atts.Add(kvp.Key, kvp.Value);
		}
		ewr_Write(ewr_HtmlElement("script", atts, "", true) + "\n");
	}

	// Output LINK tag
	public static void ewr_AddStylesheet(string href, Dictionary<string, string> attrs = null) {
		var atts = new Dictionary<string, string>() {{"rel", "stylesheet"}, {"type", "text/css"}, {"href", href}};
		if (attrs != null) {
			foreach (var kvp in attrs)
				atts.Add(kvp.Key, kvp.Value);
		}
		ewr_Write(ewr_HtmlElement("link", atts, "", false) + "\n");
	}	

	// Build HTML element
	public static string ewr_HtmlElement(string tagname, Dictionary<string, string> attrs, string innerhtml = "", bool endtag = true) {
		string html = "<" + tagname;
		if (attrs != null) {
			foreach (var kvp in attrs) {
				if (ewr_NotEmpty(kvp.Value))
					html += " " + kvp.Key + "=\"" + ewr_HtmlEncode(kvp.Value) + "\"";
			}
		}
		html += ">";
		if (ewr_NotEmpty(innerhtml))
			html += innerhtml;
		if (endtag)
			html += "</" + tagname + ">";
		return html;
	}

	// XML tag name
	public static string ewr_XmlTagName(string name) {
		name = name.Replace(" ", "_");
		Regex regEx = new Regex(@"^(?!XML)[a-z][\w-]*$", RegexOptions.IgnoreCase);
		if (!regEx.IsMatch(name))
			name = "_" + name;
		return name;
	}

	// Encode URL
	public static string ewr_UrlEncode(object Expression)
	{
		return ewr_Server.UrlEncode(Convert.ToString(Expression));
	}

	// Decode URL
	public static string ewr_UrlDecode(string Str)
	{
		return ewr_Server.UrlDecode(Str);
	}

	// Adjust SQL for special characters
	public static string ewr_AdjustSql(object value)
	{
		string sWrk = Convert.ToString(value).Trim();
		sWrk = sWrk.Replace("'", "''");	// Adjust for single quote
		sWrk = sWrk.Replace("[", "[[]"); // Adjust for open square bracket
		return sWrk;
	}

	// Build Report SQL
	public static string ewr_BuildReportSql(string sSelect, string sWhere, string sGroupBy, string sHaving, string sOrderBy, string sFilter, string sSort) {
		string sDbWhere = sWhere;
		ewr_AddFilter(ref sDbWhere, sFilter);
		string sDbOrderBy = ewr_UpdateSortFields(sOrderBy, sSort, 1);
		string sSql = sSelect;
		if (ewr_NotEmpty(sDbWhere))
			sSql = sSql + " WHERE " + sDbWhere;
		if (ewr_NotEmpty(sGroupBy))
			sSql = sSql + " GROUP BY " + sGroupBy;
		if (ewr_NotEmpty(sHaving))
			sSql = sSql + " HAVING " + sHaving;
		if (ewr_NotEmpty(sDbOrderBy))
			sSql = sSql + " ORDER BY " + sDbOrderBy;		
		return sSql;
	}

	// Load a text file
	public static string ewr_LoadTxt(string fn) {
		string sTxt = "";
		if (ewr_NotEmpty(fn)) {
			fn = ewr_MapPath(fn); // Relative to script
			StreamReader sw = File.OpenText(fn); // Note: The file fn should be UTF-8 encoded text file.
			sTxt = sw.ReadToEnd();
			sw.Close();
		}
		return sTxt;
	}

	// Update sort fields
	// opt = 1, merge all sort fields
	// opt = 2, merge sOrderBy fields only
	public static string ewr_UpdateSortFields(string sOrderBy, string sSort, int opt) {
		if (ewr_Empty(sOrderBy)) {
			return (opt == 1) ? sSort : "";
		} else if (ewr_Empty(sSort)) {
			return sOrderBy;
		} else { // Merge sort field list
			List<string> arorderby = ewr_GetSortFlds(sOrderBy);
			int cntorderby = arorderby.Count;
			List<string> arsort = ewr_GetSortFlds(sSort);
			int cntsort = arsort.Count;
			for (int i = 0; i < cntsort; i++) {

				// Get sort field				
				string sortfld = arsort[i].Trim();				
				if (sortfld.ToUpper().EndsWith(" ASC")) {
					sortfld = sortfld.Substring(0, sortfld.Length - 4).Trim();
				} else if (sortfld.ToUpper().EndsWith(" DESC")) {
					sortfld = sortfld.Substring(0, sortfld.Length - 4).Trim();
				}
				string orderfld = "";
				for (int j = 0; j < cntorderby; j++) {

					// Get orderby field
					orderfld = Convert.ToString(arorderby[j]).Trim();
					if (orderfld.ToUpper().EndsWith(" ASC")) {
						orderfld = orderfld.Substring(0, orderfld.Length - 4).Trim();
					} else if (orderfld.ToUpper().EndsWith(" DESC")) {
						orderfld = orderfld.Substring(0, orderfld.Length - 4).Trim();
					}

					// Replace field
					if (ewr_SameStr(orderfld, sortfld)) {
						arorderby[j] = arsort[i];
						break;
					}
				}

				// Append field
				if (opt == 1 && !ewr_SameStr(orderfld, sortfld))
					arorderby.Add(arsort[i]);
			}
			return String.Join(", ", arorderby);
		}
	}	

	// Get sort fields
	public static List<string> ewr_GetSortFlds(string flds) {
		int offset = -1;
		int fldpos = 0;
		var ar = new List<string>();
		offset = flds.IndexOf(",", offset + 1);
		while (offset > -1) {
			string orderfld = flds.Substring(fldpos, offset - fldpos);
			if (orderfld.ToUpper().EndsWith(" ASC") || orderfld.ToUpper().EndsWith(" DESC")) {
				fldpos = offset + 1;
				ar.Add(orderfld);
			}
			offset = flds.IndexOf(",", offset + 1);
		}
		ar.Add(flds.Substring(fldpos));
		return ar;
	}

	// Get reverse sort
	public static string ewr_ReverseSort(object sorttype) {
		return (ewr_SameText(sorttype, "ASC")) ? "DESC" : "ASC";
	}

	// Construct a crosstab field name
	public static string ewr_CrossTabField(string smrytype, object smryfld, object colfld, string datetype, object val, object qc, string alias = "")
	{
		string fld = "";
		string wrkval;
		string wrkqc;
		if (ewr_SameStr(val, EWR_NULL_VALUE)) {
			wrkval = "NULL";
			wrkqc = "";
		} else if (ewr_SameStr(val, EWR_EMPTY_VALUE)) {
			wrkval = "";
			wrkqc = Convert.ToString(qc);
		}	else {
			wrkval = Convert.ToString(val);
			wrkqc = Convert.ToString(qc);
		}
		switch (smrytype) {
			case "SUM":
				fld = smrytype + "(" + smryfld + "*" + ewr_SQLDistinctFactor(colfld, datetype, wrkval, wrkqc) + ")";
				break;
			case "COUNT":
				fld = "SUM(" + ewr_SQLDistinctFactor(colfld, datetype, wrkval, wrkqc) + ")";
				break;
			case "MIN":
			case "MAX":
				string aggwrk = ewr_SQLDistinctFactor(colfld, datetype, wrkval, wrkqc);
				fld = smrytype + "(IF(" + aggwrk + "=0,NULL," + smryfld + "))";
				if (EWR_IS_MSACCESS) {
					fld = smrytype + "(IIf(" + aggwrk + "=0,NULL," + smryfld + "))";
				} else if (EWR_IS_MSSQL || EWR_IS_ORACLE) {
					fld = smrytype + "(CASE " + aggwrk + " WHEN 0 THEN NULL ELSE " + smryfld + " END)";
				} else if (EWR_IS_MYSQL || EWR_IS_POSTGRESQL) {
					fld = smrytype + "(IF(" + aggwrk + "=0,NULL," + smryfld + "))";				
				}
				break;
			case "AVG":
				string sumwrk = "SUM(" + smryfld + "*" + ewr_SQLDistinctFactor(colfld, datetype, wrkval, wrkqc) + ")";
				if (ewr_NotEmpty(alias))
					sumwrk += " AS " + ewr_QuotedName("sum_" + alias);
				string cntwrk = "SUM(" + ewr_SQLDistinctFactor(colfld, datetype, wrkval, wrkqc) + ")";
				if (ewr_NotEmpty(alias))
					cntwrk += " AS " + ewr_QuotedName("cnt_" + alias);
				return sumwrk + ", " + cntwrk;
				break;
		}
		if (ewr_NotEmpty(alias))
			fld += " AS " + ewr_QuotedName(alias);
		return fld;
	}

	// Construct SQL Distinct factor (MySQL)
	// - ACCESS
	// y: IIf(Year(FieldName)=1996,1,0)
	// q: IIf(DatePart(""q"",FieldName,1,0)=1,1,0))
	// m: (IIf(DatePart(""m"",FieldName,1,0)=1,1,0)))
	// others: (IIf(FieldName=val,1,0)))
	// - MS SQL
	// y: (1-ABS(SIGN(Year(FieldName)-1996)))
	// q: (1-ABS(SIGN(DatePart(q,FieldName)-1)))
	// m: (1-ABS(SIGN(DatePart(m,FieldName)-1)))
	// d: (CASE Convert(VarChar(10),FieldName,120) WHEN '1996-1-1' THEN 1 ELSE 0 END)
	// - MySQL
	// y: IF(YEAR(FieldName)=1996,1,0))
	// q: IF(QUARTER(FieldName)=1,1,0))
	// m: IF(MONTH(FieldName)=1,1,0))
	// - PostgreSql
	// y: IF(EXTRACT(YEAR FROM FieldName)=1996,1,0))
	// q: IF(EXTRACT(QUARTER FROM FieldName)=1,1,0))
	// m: IF(EXTRACT(MONTH FROM FieldName)=1,1,0))
	public static string ewr_SQLDistinctFactor(object sFld, string dateType, string val, string qc) {

		// ACCESS
		if (EWR_IS_MSACCESS) {
			if (dateType == "y" && ewr_IsNumeric(val)) {
				return "IIf(Year(" + sFld + ")=" + val + ",1,0)";
			} else if ((dateType == "q" || dateType == "m") && ewr_IsNumeric(val)) {
				return "IIf(DatePart(\"" + dateType + "\"," + sFld + ")=" + val + ",1,0)";
			} else {
				if (val == "NULL")
					return "IIf(" + sFld + " IS NULL,1,0)";
				else
					return "IIf(" + sFld + "=" + qc + ewr_AdjustSql(val) + qc + ",1,0)";
			}

		// MS SQL
		} else if (EWR_IS_MSSQL) {
			if (dateType == "y" && ewr_IsNumeric(val)) {
				return "(1-ABS(SIGN(Year(" + sFld + ")-" + val + ")))";
			} else if ((dateType == "q" || dateType == "m") && ewr_IsNumeric(val)) {
				return "(1-ABS(SIGN(DatePart(" + dateType + "," + sFld + ")-" + val + ")))";
			} else if (dateType == "d") {
				return "(CASE CONVERT(VARCHAR(10)," + sFld + ",120) WHEN " + qc + ewr_AdjustSql(val) + qc + " THEN 1 ELSE 0 END)";
			} else if (dateType == "dt") {
				return "(CASE CONVERT(VARCHAR," + sFld + ",120) WHEN " + qc + ewr_AdjustSql(val) + qc + " THEN 1 ELSE 0 END)";
			} else {
				if (val == "NULL")
					return "(CASE WHEN " + sFld + " IS NULL THEN 1 ELSE 0 END)";
				else
					return "(CASE " + sFld + " WHEN " + qc + ewr_AdjustSql(val) + qc + " THEN 1 ELSE 0 END)";
			}

		// MySQL
		} else if (EWR_IS_MYSQL) {
			if (dateType == "y" && ewr_IsNumeric(val)) {
				return "IF(YEAR(" + sFld + ")=" + val + ",1,0)";
			} else if (dateType == "q" && ewr_IsNumeric(val)) {
				return "IF(QUARTER(" + sFld + ")=" + val + ",1,0)";
			} else if (dateType == "m" && ewr_IsNumeric(val)) {
				return "IF(MONTH(" + sFld + ")=" + val + ",1,0)";
			} else {
				if (val == "NULL") {
					return "IF(" + sFld + " IS NULL,1,0)";
				} else {
					return "IF(" + sFld + "=" + qc + ewr_AdjustSql(val) + qc + ",1,0)";
				}
			}

		// PostgreSql
		} else if (EWR_IS_POSTGRESQL) {
			if (dateType == "y" && ewr_IsNumeric(val)) {
				return "CASE WHEN TO_CHAR(" + sFld + ",'YYYY')='" + val + "' THEN 1 ELSE 0 END";
			} else if (dateType == "q" && ewr_IsNumeric(val)) {
				return "CASE WHEN TO_CHAR(" + sFld + ",'Q')='" + val + "' THEN 1 ELSE 0 END";
			} else if (dateType == "m" && ewr_IsNumeric(val)) {
				return "CASE WHEN TO_CHAR(" + sFld + ",'MM')=LPAD('" + val + "',2,'0') THEN 1 ELSE 0 END";
			} else {
				if (val == "NULL") {
					return "CASE WHEN " + sFld + " IS NULL THEN 1 ELSE 0 END";
				} else {
					return "CASE WHEN " + sFld + "=" + qc + ewr_AdjustSql(val) + qc + " THEN 1 ELSE 0 END";
				}
			}

		// Oracle
		} else if (EWR_IS_ORACLE || EWR_IS_POSTGRESQL) {
			if (dateType == "y" && ewr_IsNumeric(val)) {
				return "DECODE(TO_CHAR(" + sFld + ",'YYYY'),'" + val + "',1,0)";
			} else if (dateType == "q" && ewr_IsNumeric(val)) {
				return "DECODE(TO_CHAR(" + sFld + ",'Q'),'" + val + "',1,0)";
			} else if (dateType == "m" && ewr_IsNumeric(val)) {
				return "DECODE(TO_CHAR(" + sFld + ",'MM'),LPAD('" + val + "',2,'0'),1,0)";
			} else if (dateType == "d") {
				val = ewr_FormatDateTime(val, 5); // AXR
				return "DECODE(" + sFld + ",TO_DATE(" + qc + ewr_AdjustSql(val) + qc + ",'YYYY/MM/DD'),1,0)";
			} else if (dateType == "dt") {
				val = ewr_FormatDateTime(val, 9); // AXR
				return "DECODE(" + sFld + ",TO_DATE(" + qc + ewr_AdjustSql(val) + qc + ",'YYYY/MM/DD HH24:MI:SS'),1,0)";
			} else {
				if (val == "NULL") {
					return "(CASE WHEN " + sFld + " IS NULL THEN 1 ELSE 0 END)";
				} else {
					return "DECODE(" + sFld + "," + qc + ewr_AdjustSql(val) + qc + ",1,0)";
				}
			}
		}
	}

	// Evaluate summary value
	public static object ewr_SummaryValue(object val1, object val2, string ityp) {
		switch (ityp) {
		case "SUM":
		case "COUNT":
		case "AVG":
			if (Convert.IsDBNull(val2) || !ewr_IsNumeric(val2))	{
				return val1;
			} else {
				return ewr_ConvertToDouble(val1) + ewr_ConvertToDouble(val2);;
			}
		case "MIN":
			if (Convert.IsDBNull(val2) || !ewr_IsNumeric(val2)) {
				return val1; // Skip null and non-numeric
			} else if (val1 == null) { // Initialize for first valid value
				return val2;
			} else if (ewr_ConvertToDouble(val1) < ewr_ConvertToDouble(val2)) {
				return val1;
			} else {
				return val2;
			}
		case "MAX":
			if (Convert.IsDBNull(val2) || !ewr_IsNumeric(val2)) {
				return val1; // Skip null and non-numeric
			} else if (val1 == null) { // Initialize for first valid value
				return val2;
			} else if (ewr_ConvertToDouble(val1) > ewr_ConvertToDouble(val2)) {
				return val1;
			} else {
				return val2;
			}
		}
		return null;
	}

	// Match filter value
	public static bool ewr_MatchedFilterValue(object ar, object value) {
		if (!ewr_IsList(ar)) {
			return ewr_SameStr(ar, value);
		} else {
			foreach (object val in (IList)ar) {
				if (ewr_SameStr(val, value))
					return true;
			}
			return false;
		}
	}

	// Render repeat column table
	// rowcnt - zero based row count
	public static string ewr_RepeatColumnTable(int totcnt, int rowcnt, int repeatcnt, int rendertype) {
		string sWrk = "";
		if (rendertype == 1) { // Render control start
			if (rowcnt == 0) sWrk += "<table class=\"" + EWR_ITEM_TABLE_CLASSNAME + "\">";
			if (rowcnt % repeatcnt == 0) sWrk += "<tr>";
			sWrk += "<td>";
		} else if (rendertype == 2) { // Render control end
			sWrk += "</td>";
			if (rowcnt % repeatcnt == repeatcnt - 1) {
				sWrk += "</tr>";
			} else if (rowcnt == totcnt - 1) {
				for (int i = (rowcnt % repeatcnt) + 1; i < repeatcnt; i++) {
					sWrk += "<td>&nbsp;</td>";
				}
				sWrk += "</tr>";
			}
			if (rowcnt == totcnt - 1) sWrk += "</table>";
		}
		return sWrk;
	}

	// Check if the value is selected
	public static bool ewr_IsSelectedValue(List<string> ar, object value, int ft) {
		if (ar == null || ar.Count == 0) // AXR
			return true;
		foreach (var val in ar) {
			if (Convert.ToString(value).StartsWith("@@") || val.StartsWith("@@")) { // Popup filters			
				if (ewr_SameStr(val, value))
					return true;
			} else if (value == EWR_NULL_VALUE && ewr_SameStr(value, val)) {
				return true;
			} else if (ewr_CompareValue(val, value, ft)) {
				return true;				
			}
		}
		return false;
	}

	// Check if advanced filter value
	public static bool ewr_IsAdvancedFilterValue(object v) {
		if (ewr_IsList(v)) {
			foreach (string val in (List<string>)v) {
				if (!Convert.ToString(val).StartsWith("@@"))
					return false;
			}
			return true;
		} else if (Convert.ToString(v).StartsWith("@@")) {
			return true;
		}
		return false;
	}

	// Set up distinct values
	// ar: array for distinct values
	// val: value
	// label: display value
	// dup: check duplicate
	public static void ewr_SetupDistinctValues(OrderedDictionary ar, string val, string label, bool dup, string dlm = "") {
		string[] arval, arlabel;
		if (ewr_NotEmpty(dlm)) {
			arval = val.Split(new char[] { Convert.ToChar(dlm) });
			arlabel = label.Split(new char[] { Convert.ToChar(dlm) });
			if (arval.Length != arlabel.Length) {
				arval = new string[] { val };
				arlabel = new string[] { label };
			}
		} else {
			arval = new string[] { val };
			arlabel = new string[] { label };
		}
		int cntval = arval.Length;
		for (var i = 0; i < cntval; i++) {
			var v = arval[i];
			var l = arlabel[i];
			if (dup && ar != null && ar.Contains(v))
				continue;
			if (ar == null) {
				ar = new OrderedDictionary() {{v, l}};
			} else if (v == EWR_EMPTY_VALUE || v == EWR_NULL_VALUE) { // Null/Empty
				ar.Insert(0, v, l);
			} else {
				ar.Add(v, l); // Default insert at end
			}
		}	
	}	

	// Compare values based on field type
	public static bool ewr_CompareValue(object v1, object v2, int ft) {
		switch (ft) {
			case 20:
			case 3:
			case 2:
			case 16:
			case 17:
			case 18:
			case 19:
			case 21: // adBigInt, adInteger, adSmallInt, adTinyInt, adUnsignedTinyInt, adUnsignedSmallInt, adUnsignedInt, adUnsignedBigInt
				if (ewr_IsNumeric(v1) && ewr_IsNumeric(v2))
					return (ewr_ConvertToInt(v1) == ewr_ConvertToInt(v2));
				break;
			case 4:
			case 5:
			case 131:
			case 6:	// adSingle, adDouble, adNumeric, adCurrency
				if (ewr_IsNumeric(v1) && ewr_IsNumeric(v2))
					return (ewr_ConvertToDouble(v1) == ewr_ConvertToDouble(v2));					
				break;
			case 7:
			case 133:
			case 134:
			case 135:	// adDate, adDBDate, adDBTime, adDBTimeStamp
				if (ewr_IsDate(v1) && ewr_IsDate(v2))
					return (Convert.ToDateTime(v1) == Convert.ToDateTime(v2));
				break;
			case 11:
				return (ewr_ConvertToBool(v1) == ewr_ConvertToBool(v2));
		}
		return ewr_SameStr(v1, v2); // Treat as string
	}

	// Is date
	public static bool ewr_IsDate(object obj) {
		return Information.IsDate(obj);
	}

	// Is numeric
	public static bool ewr_IsNumeric(object obj) {
		return Information.IsNumeric(obj);
	}

	// Register filter
	public static void ewr_RegisterFilter(crField fld, string ID, string Name, string FunctionName = "") {
		var wrkid = (ID.StartsWith("@@")) ? ID : "@@" + ID;
		var key = wrkid.Substring(2);
		fld.AdvancedFilters.Add(key, new crAdvancedFilter(wrkid, Name, FunctionName));
	}

	// Unregister filter
	public static void ewr_UnregisterFilter(crField fld, string ID) {
		var wrkid = (ID.StartsWith("@@")) ? ID : "@@" + ID;
		var key = wrkid.Substring(2);
		foreach (var kvp in fld.AdvancedFilters) {
			var filter = kvp.Value;
			if (filter.ID == wrkid) {
				fld.AdvancedFilters.Remove(kvp.Key);
				break;
			}
		}
	}

	// Return date value	
	public static object ewr_DateVal(string FldOpr, string FldVal, int ValType) {
		string wrkVal = "";
		string[] arWrk;
		int y, q, m;

		// Compose date string
		switch (FldOpr.ToLower()) { 
		case "year":
			if (ValType == 1) { 
				wrkVal = FldVal + "/01/01"; 
			} else if (ValType == 2) { 
				wrkVal = FldVal + "/12/31"; 
			}
			break;
		case "quarter":
			arWrk = FldVal.Split(new char[] {'|'}); 
			y = ewr_ConvertToInt(arWrk[0]);
			q = ewr_ConvertToInt(arWrk[1]);
			if (y == 0 || q == 0) {
				wrkVal = "0000/00/00";
			} else {
				if (ValType == 1) {
					m = (q - 1) * 3 + 1;
					wrkVal = Convert.ToString(y) + "/" + Convert.ToString(m).PadLeft(2, '0') + "/01";
				} else if (ValType == 2) {
					m = (q - 1) * 3 + 3;
					wrkVal = Convert.ToString(y) + "/" + Convert.ToString(m).PadLeft(2, '0') + "/" + ewr_DaysInMonth(y, m);
				}
			}
			break;
		case "month":
			arWrk = FldVal.Split(new char[] {'|'}); 
			y = ewr_ConvertToInt(arWrk[0]);
			m = ewr_ConvertToInt(arWrk[1]);
			if (y == 0 || m == 0) {
				wrkVal = "0000/00/00";
			} else {
				if (ValType == 1) {
					wrkVal = Convert.ToString(y) + "/" + Convert.ToString(m).PadLeft(2, '0') + "/01";
				} else if (ValType == 2) {
					wrkVal = Convert.ToString(y) + "/" + Convert.ToString(m).PadLeft(2, '0') + "/" + ewr_DaysInMonth(y, m);
				}
			}
			break;
		case "day":
			wrkVal = FldVal.Replace("|", "/");
			break;
		}

		// Add time if necessary
		if (Regex.IsMatch(wrkVal, @"(\d{4}|\d{2})/(\d{1,2})/(\d{1,2})$")) { // date without time
			if (ValType == 1) {
				wrkVal += " 00:00:00";
			} else if (ValType == 2) {
				wrkVal += " 23:59:59";
			}
		}

		// Check if datetime
		if (Regex.IsMatch(wrkVal, @"(\d{4}|\d{2})/(\d{1,2})/(\d{1,2}) (\d{1,2}):(\d{1,2}):(\d{1,2})")) // datetime
			return wrkVal;
		return "";
	}

	// Is past
	public string ewr_IsPast(string FldExpression) {
		return "(" + FldExpression + " < " + ewr_QuotedValue(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), EWR_DATATYPE_TIME) + ")";
	}

	// Is future
	public string ewr_IsFuture(string FldExpression) {
		return "(" + FldExpression + " > " + ewr_QuotedValue(DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss"), EWR_DATATYPE_TIME) + ")";
	}

	// Is last 30 days
	public string ewr_IsLast30Days(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -29, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +1, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is last 14 days
	public string ewr_IsLast14Days(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -13, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +1, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is last 7 days
	public string ewr_IsLast7Days(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -6, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +1, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is next 7 days
	public string ewr_IsNext7Days(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = dt;
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +7, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is next 14 days
	public string ewr_IsNext14Days(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = dt;
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +14, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is next 30 days
	public string ewr_IsNext30Days(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = dt;
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +30, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is yesterday
	public string ewr_IsYesterday(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -1, dt);
		DateTime dt2 = dt;
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is DT
	public string ewr_IsToday(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = dt;
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +1, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is tomorrow
	public string ewr_IsTomorrow(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, +1, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, +2, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is last month
	public string ewr_IsLastMonth(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Month, -1, dt);
		DateTime dt2 = dt;
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/01"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/01"), EWR_DATATYPE_TIME) + ")";		
	}

	// Is this month
	public string ewr_IsThisMonth(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = dt;
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Month, +1, dt);	
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/01"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/01"), EWR_DATATYPE_TIME) + ")";	
	}

	// Is next month
	public string ewr_IsNextMonth(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Month, +1, dt);	
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Month, +2, dt);	
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/01"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/01"), EWR_DATATYPE_TIME) + ")";	
	}

	// Is last 2 weeks
	public string ewr_IsLast2Weeks(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek - 14, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek, dt);		
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is last week
	public string ewr_IsLastWeek(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek - 7, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek, dt);			
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is this week
	public string ewr_IsThisWeek(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek + 7, dt);	
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is next week
	public string ewr_IsNextWeek(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek + 7, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek + 14, dt);	
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is next 2 weeks
	public string ewr_IsNext2Weeks(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek + 7, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Day, -1*(int)dt.DayOfWeek + 21, dt);	
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/MM/dd"), EWR_DATATYPE_TIME) + ")";
	}

	// Is last year
	public string ewr_IsLastYear(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Year, -1, dt);
		DateTime dt2 = dt;	
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/01/01"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/01/01"), EWR_DATATYPE_TIME) + ")";
	}

	// Is this year
	public string ewr_IsThisYear(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = dt;
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Year, 1, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/01/01"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/01/01"), EWR_DATATYPE_TIME) + ")";
	}

	// Is next year
	public string ewr_IsNextYear(string FldExpression) {
		DateTime dt = DateTime.Today;
		DateTime dt1 = DateAndTime.DateAdd(DateInterval.Year, 1, dt);
		DateTime dt2 = DateAndTime.DateAdd(DateInterval.Year, 2, dt);
		return "(" + FldExpression + " >= " + ewr_QuotedValue(dt1.ToString("yyyy/01/01"), EWR_DATATYPE_TIME) +
			" AND " + FldExpression + " < " + ewr_QuotedValue(dt2.ToString("yyyy/01/01"), EWR_DATATYPE_TIME) + ")";
	}

	// Get number of days in a month
	public static int ewr_DaysInMonth(int y, int m) {
		if ((new List<int>() {1, 3, 5, 7, 8, 10, 12}).Contains(m)) {
			return 31;
		} else if ((new List<int>() {4, 6, 9, 11}).Contains(m)) {
			return 30;
		} else if (m == 2) {
			return (y % 4 == 0) ? 29 : 28;
		}
		return 0;
	}	

	// Set up distinct values from ext. filter
	public static void ewr_SetupDistinctValuesFromFilter(OrderedDictionary ar, Dictionary<string, crAdvancedFilter> af) {
		if (af != null) {
			foreach (var kvp in af) {
				var filter = kvp.Value;
				if (filter.Enabled)
					ewr_SetupDistinctValues(ar, filter.ID, filter.Name, false);
			}
		}
	}

	// DatePart // ASPX
	public static int ewr_DatePart(DateInterval Interval, DateTime DateValue) {
		return DateAndTime.DatePart(Interval, DateValue, FirstDayOfWeek.Sunday, FirstWeekOfYear.Jan1);
	}

	// Pad zeros before number
	public static string ewr_ZeroPad(int m, int t) {
		return Convert.ToString(m).PadLeft(t, '0');
	}	

	// Get group value
	// - Get the group value based on field type, group type and interval
	// - ft: field type
	// * 1: numeric, 2: date, 3: string
	// - gt: group type
	// * numeric: i = interval, n = normal
	// * date: d = Day, w = Week, m = Month, q = Quarter, y = Year
	// * string: f = first nth character, n = normal
	// - intv: interval
	public static object ewr_GroupValue(crField fld, object val) {
		var ft = fld.FldType;
		var grp = fld.FldGroupByType;
		var intv = fld.FldGroupInt;
		switch (ft) {

		// Case adBigInt, adInteger, adSmallInt, adTinyInt, adSingle, adDouble, adNumeric, adCurrency, adUnsignedTinyInt, adUnsignedSmallInt, adUnsignedInt, adUnsignedBigInt (numeric)
		case 20:
		case 3:
		case 2:
		case 16:
		case 4:
		case 5:
		case 131:
		case 6:
		case 17:
		case 18:
		case 19:
		case 21:
			if (!ewr_IsNumeric(val))
				return val;	
			var wrkIntv = Convert.ToInt32(intv);
			if (wrkIntv <= 0)
				wrkIntv = 10;
			switch (grp) {
				case "i":
					return Convert.ToInt32(Convert.ToDouble(val) / wrkIntv);
				default:
					return val;
			}

		// Case adDate, adDBDate, adDBTime, adDBTimeStamp (date) // ASPX
		case 7:
		case 133:
		case 134:
		case 135:
			if (!ewr_IsDate(val))
				return val;
			var DT = Convert.ToDateTime(val); 					
			switch (grp) {
				case "y":
					return DT.Year;
				case "q":
					var q = ewr_DatePart(DateInterval.Quarter, DT);
					return DT.Year + "|" + q;
				case "m":
					return DT.Year + "|" + ewr_ZeroPad(DT.Month, 2);
				case "w":
					var ww = ewr_DatePart(DateInterval.WeekOfYear, Convert.ToDateTime(val));
					return DT.Year + "|" + ewr_ZeroPad(ww, 2);
				case "d":
					return DT.Year + "|" + ewr_ZeroPad(DT.Month, 2) + "|" + ewr_ZeroPad(DT.Day, 2);
				case "h":
					return DT.Hour;
				case "min":
					return DT.Minute;
				default:
					return val;
			}

		// Case adLongVarChar, adLongVarWChar, adChar, adWChar, adVarChar, adVarWChar (string)
		case 201: // string
		case 203:
		case 129:
		case 130:
		case 200:
		case 202:
			wrkIntv = Convert.ToInt32(intv);
			if (wrkIntv <= 0)
				wrkIntv = 1;
			switch (grp) {
				case "f":
					return Convert.ToString(val).Substring(0, wrkIntv);
				default:
					return val;
			}			
		default:
			return val; // ignore
		}
	}

	// Display group value
	public static string ewr_DisplayGroupValue(crField fld, object val) {
		var ft = fld.FldType;
		var grp = fld.FldGroupByType;
		var intv = fld.FldGroupInt;
		if (Convert.IsDBNull(val))
			return ReportLanguage.Phrase("NullLabel");
		if (ewr_Empty(val))
			return ReportLanguage.Phrase("EmptyLabel");
		switch (ft) {

		// Case adBigInt, adInteger, adSmallInt, adTinyInt, adSingle, adDouble, adNumeric, adCurrency, adUnsignedTinyInt, adUnsignedSmallInt, adUnsignedInt, adUnsignedBigInt (numeric)
		case 20:
		case 3:
		case 2:
		case 16:
		case 4:
		case 5:
		case 131:
		case 6:
		case 17:
		case 18:
		case 19:
		case 21:
			var wrkIntv = Convert.ToInt32(intv);
			if (wrkIntv <= 0)
				wrkIntv = 10;
			switch (grp) {
				case "i":
					return Convert.ToString(Convert.ToDouble(val) * wrkIntv) + " - " + Convert.ToString((Convert.ToDouble(val) + 1) * wrkIntv - 1);
				default:
					return Convert.ToString(val);
			}
			break;

		// Case adDate, adDBDate, adDBTime, adDBTimeStamp (date)
		case 7:
		case 133:
		case 134:
		case 135:
			var ar = Convert.ToString(val).Split(new char[] {'|'});
			switch (grp) {
				case "y":
					return ar[0];
				case "q":
					if (ar.Length < 2) return Convert.ToString(val);
					return ewr_FormatQuarter(ar[0], ar[1]);
				case "m":
					if (ar.Length < 2) return Convert.ToString(val);
					return ewr_FormatMonth(ar[0], ar[1]);
				case "w":
					if (ar.Length < 2) return Convert.ToString(val);
					return ewr_FormatWeek(ar[0], ar[1]);
				case "d":
					if (ar.Length < 3) return Convert.ToString(val);
					return ewr_FormatDay(ar[0], ar[1], ar[2]);
				case "h":
					return ewr_FormatHour(ar[0]);
				case "min":
					return ewr_FormatMinute(ar[0]);
				default:
					return Convert.ToString(val);
			}
			break;
		default: // string and others
			return Convert.ToString(val); // ignore
		}
	}

	public static string ewr_FormatQuarter(object y, object q) {
		return "Q" + Convert.ToString(q).Trim() + "/" + Convert.ToString(y).Trim();
	}

	public static string ewr_FormatMonth(object y, object m) {
		return Convert.ToString(m).Trim() + "/" + Convert.ToString(y).Trim();
	}

	public static string ewr_FormatWeek(object y, object w) {
		return "WK" + Convert.ToString(w).Trim() + "/" + Convert.ToString(y).Trim();
	}

	public static string ewr_FormatDay(object y, object m, object d) {
		return Convert.ToString(y).Trim() + "/" + Convert.ToString(m).Trim() + "/" + Convert.ToString(d).Trim();
	}

	public static string ewr_FormatHour(object h) {
		if (Convert.ToInt32(h) == 0) {
			return "12 AM";
		} else if (Convert.ToInt32(h) < 12) {
			return h + " AM";
		} else if (Convert.ToInt32(h) == 12) {
			return "12 PM";
		} else {
			return (Convert.ToInt32(h) - 12) + " PM";
		}
	}

	public static string ewr_FormatMinute(object n) {
		return Convert.ToString(n).Trim() + " MIN";
	}

	// Get JavaScript db in the form of:
	// [{k:"key1",v:"value1",s:selected1}, {k:"key2",v:"value2",s:selected2}, ...]
	public static string ewr_GetJsDb(crField fld, int ft) {
		var jsdb = "";
		var arv = fld.ValueList;
		var ars = fld.SelectionList;
		if (arv != null) {
			foreach (DictionaryEntry de in arv) {
				string jsselect = (ewr_IsSelectedValue(ars, de.Key, ft)) ? "true" : "false";
				if (ewr_NotEmpty(jsdb))
					jsdb += ",";
				jsdb += "{\"k\":\"" + ewr_EscapeJs(de.Key) + "\",\"v\":\"" + ewr_EscapeJs(de.Value) + "\",\"s\":" + jsselect + "}";
			}
		}
		jsdb = "[" + jsdb + "]";
		return jsdb;
	}

	// Return detail filter SQL
	public static string ewr_DetailFilterSQL(crField fld, string fn, object val) {
		int ft = fld.FldDataType;
		if (ewr_NotEmpty(fld.FldGroupSql))
			ft = EWR_DATATYPE_STRING;
		string sqlwrk = fn;
		if (Convert.IsDBNull(val)) {
			sqlwrk += " IS NULL";
		} else {
			sqlwrk += " = " + ewr_QuotedValue(val, ft);
		}
		return sqlwrk;
	}

	// Return popup filter SQL
	public static string ewr_FilterSQL(crField fld, string fn, int ft) {
		var ar = fld.SelectionList;
		if (!ewr_IsList(ar))
			return "";
		var af = fld.AdvancedFilters;
		var gt = fld.FldGroupByType;
		var gi = fld.FldGroupInt;
		var sql = fld.FldGroupSql;
		var dlm = fld.FldDelimiter;		
		var sqlwrk = "";
		int i = 0;
		foreach (var value in ar) {
			if (ewr_SameStr(value, EWR_EMPTY_VALUE)) { // Empty string
				sqlwrk += fn + " = '' OR ";
			} else if (ewr_SameStr(value, EWR_NULL_VALUE)) { // Null value
				sqlwrk += fn + " IS NULL OR ";
			} else if (value.StartsWith("@@")) { // Advanced filter					
				object afsql = ewr_AdvancedFilterSQL(af, fn, value); // Process popup filter
				if (afsql != null)
					sqlwrk += Convert.ToString(afsql) + " OR ";
			} else if (ewr_NotEmpty(sql)) {
				sqlwrk += sql.Replace("%s", fn) + " = '" + value + "' OR ";
			} else if (ewr_NotEmpty(dlm)) {
				sql = ewr_GetMultiSearchSql(fn, value.Trim());
				if (ewr_NotEmpty(sql))
					sqlwrk += sql + " OR ";
			} else {
				sqlwrk += fn + " IN (" + ewr_JoinArray(ar, ", ", ft, i) + ") OR ";
				break;
			}
			i++;
		}
		if (ewr_NotEmpty(sqlwrk))
			sqlwrk = "(" + sqlwrk.Substring(0, sqlwrk.Length - 4) + ")";
		return sqlwrk;
	}

	// Return multi-value search SQL
	public static string ewr_GetMultiSearchSql(string fn, string val) {
		string sSql = "";
		if (val == EWR_INIT_VALUE || val == EWR_ALL_VALUE) {
			sSql = "";
		} else if (EWR_IS_MYSQL) {
			sSql = "FIND_IN_SET('" + ewr_AdjustSql(val) + "', " + fn + ")";
		} else {
			sSql = fn + " = '" + ewr_AdjustSql(val) + "' OR " + ewr_GetMultiSearchSqlPart(fn, val);
		}
		return sSql;
	}

	// Get multi search SQL part
	public static string ewr_GetMultiSearchSqlPart(string fn, string val) {
		return fn + ewr_Like("'" + ewr_AdjustSql(val) + EWR_CSV_DELIMITER + "%'") + " OR " +
			fn + ewr_Like("'%" + EWR_CSV_DELIMITER + ewr_AdjustSql(val) + EWR_CSV_DELIMITER + "%'") + " OR " +
			fn + ewr_Like("'%" + EWR_CSV_DELIMITER + ewr_AdjustSql(val) + "'");
	}

	// Return Advanced Filter SQL
	public static object ewr_AdvancedFilterSQL(Dictionary<string, crAdvancedFilter> ar, string fn, object val) {
		if (!ewr_IsList(ar)) {
			return null;
		} else if (Convert.IsDBNull(val)) {
			return null;
		} else {
			foreach (var kvp in ar) {
				var filter = kvp.Value;				
				if (ewr_SameStr(val, filter.ID) && filter.Enabled && CurrentPage != null) // AXR
					return ewr_WebPage.Invoke(filter.FunctionName, new object[] { fn });		
			}			
			return null;
		}
	}

	// Truncate Memo Field based on specified length, string truncated to nearest space or CrLf
	public static string ewr_TruncateMemo(string memostr, int ln, bool removehtml) {
		string str = (removehtml) ? ewr_RemoveHtml(memostr) : memostr;		
		if (str.Length > 0 && str.Length > ln)	{
			int k = 0;
			while (k >= 0 && k < str.Length) {
				int i = str.IndexOf(" ", k);
				int j = str.IndexOf("\r\n", k);
				if (i < 0 && j < 0)	{ // Unable to truncate
					return str;
				} else {// Get nearest space or CrLf
					if (i > 0 && j > 0)	{
						k = (i < j) ? i : j; 
					} else if (i > 0) {
						k = i;
					} else if (j > 0) {
						k = j;
					}

					// Get truncated text
					if (k >= ln) {
						return str.Substring(0, k) + "...";
					}	else {
						k = k + 1;
					}
				}
			}
		}
		return str;
	}

	// Remove HTML tags from text
	public static string ewr_RemoveHtml(string str) {
		return Regex.Replace(str, "<[^>]*>", string.Empty);
	}

	// Escape string for JavaScript
	public static string ewr_EscapeJs(object str) {
		string val = Convert.ToString(str);
		val = val.Replace("\\", "\\\\");
		val = val.Replace("\"", "\\\"");
		val = val.Replace("\t", "\\t");
		val = val.Replace("\r", "\\r");
		val = val.Replace("\n", "\\n");
		return val;
	}	

	// Load Chart Series
	public void ewr_LoadChartSeries(string sSql, crChart cht) {
		var rscht = Conn.GetRows(sSql);
		var sdt = cht.SeriesDateType;
		if (rscht != null) {
			foreach (var Row in rscht)
				cht.Series.Add(ewr_ChartSeriesValue(Row[0], sdt)); // Series value
		}
	}

	// Load Chart Data
	public void ewr_LoadChartData(string sSql, crChart cht) {
		var rscht = Conn.GetRows(sSql);
		if (rscht != null) {
			foreach (var Row in rscht)
				cht.Data.Add(Row);
		}
	}

	// Get Chart X value
	public static string ewr_ChartXValue(object val, string dt) {
		if (Convert.IsDBNull(val)) {
			return ReportLanguage.Phrase("NullLabel");
		} else if (ewr_Empty(val)) {
			return ReportLanguage.Phrase("EmptyLabel");
		} else if (ewr_IsNumeric(dt)) {
			return ewr_FormatDateTime(val, ewr_ConvertToInt(dt));
		} else if (dt == "y") {
			return Convert.ToString(val);
		} else if (dt == "xyq") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2)
				return ar[0] + " " + ewr_QuarterName(ar[1]);
			else
				return Convert.ToString(val);
		} else if (dt == "xym") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2)
				return ar[0] + " " + ewr_MonthName(ar[1]);
			else
				return Convert.ToString(val);
		} else if (dt == "xq") {
			return ewr_QuarterName(val);
		} else if (dt == "xm") {
			return ewr_MonthName(val);
		} else {
			return Convert.ToString(val).Trim();
		}
	}

	// Get Chart X SQL
	public static string ewr_ChartXSQL(string fldsql, int fldtype, object val, string dt) {
		if (ewr_IsNumeric(dt)) {
			return fldsql + " = " + ewr_QuotedValue(ewr_UnformatDateTime(val, ewr_ConvertToInt(dt)), fldtype);
		} else if (dt == "y") {
			if (ewr_IsNumeric(val))
				return EWR_YEAR_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(val, EWR_DATATYPE_NUMBER);
			else
				return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		} else if (dt == "xyq") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2 && ewr_IsNumeric(ar[0]) && ewr_IsNumeric(ar[1]))
				return EWR_YEAR_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[0], EWR_DATATYPE_NUMBER) + " AND " + EWR_QUARTER_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[1], EWR_DATATYPE_NUMBER);
			else
				return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		} else if (dt == "xym") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2 && ewr_IsNumeric(ar[0]) && ewr_IsNumeric(ar[1]))
				return EWR_YEAR_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[0], EWR_DATATYPE_NUMBER) + " AND " + EWR_MONTH_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[1], EWR_DATATYPE_NUMBER);
			else
				return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		} else if (dt == "xq") {
			return EWR_QUARTER_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(val, EWR_DATATYPE_NUMBER);
		} else if (dt == "xm") {
			return EWR_MONTH_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(val, EWR_DATATYPE_NUMBER);
		} else {
			return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		}
	}

	// Get Chart Series value
	public static string ewr_ChartSeriesValue(object val, string dt) {
		if (dt == "syq") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2)
				return ar[0] + " " + ewr_QuarterName(ar[1]);
			else
				return Convert.ToString(val);
		} else if (dt == "sym") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2)
				return ar[0] + " " + ewr_MonthName(ar[1]);
			else
				return Convert.ToString(val);
		} else if (dt == "sq") {
			return ewr_QuarterName(val);
		} else if (dt == "sm") {
			return ewr_MonthName(val);
		} else {
			return Convert.ToString(val).Trim();
		}
	}

	// Get Chart Series SQL	
	public static string ewr_ChartSeriesSQL(string fldsql, int fldtype, object val, string dt) {
		if (dt == "syq") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2 && ewr_IsNumeric(ar[0]) && ewr_IsNumeric(ar[1]))
				return EWR_YEAR_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[0], EWR_DATATYPE_NUMBER) + " AND " + EWR_QUARTER_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[1], EWR_DATATYPE_NUMBER);
			else
				return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		} else if (dt == "sym") {
			string[] ar = Convert.ToString(val).Split(new char[] {'|'});
			if (ar.Length >= 2 && ewr_IsNumeric(ar[0]) && ewr_IsNumeric(ar[1]))
				return EWR_YEAR_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[0], EWR_DATATYPE_NUMBER) + " AND " + EWR_MONTH_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(ar[1], EWR_DATATYPE_NUMBER);
			else
				return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		} else if (dt == "sq") {
			return EWR_QUARTER_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(val, EWR_DATATYPE_NUMBER);
		} else if (dt == "sm") {
			return EWR_MONTH_SQL.Replace("%s", fldsql) + " = " + ewr_QuotedValue(val, EWR_DATATYPE_NUMBER);
		} else {
			return fldsql + " = " + ewr_QuotedValue(val, fldtype);
		}
	}

	// Chart data comparer // ASPX
	public class ewr_ChartDataComparer: Comparer<OrderedDictionary> {
		int Index = 0;
		object Seq = ""; // Empty (Default)
		string Order = "ASC"; // ASC/DESC

		public ewr_ChartDataComparer(int index, object seq, string order) {
			if (index > 0)
				Index = index;
			Seq = seq;
			Order = ewr_SameText(order, "ASC") ? "ASC" : "DESC";
		}

		public override int Compare(OrderedDictionary d1, OrderedDictionary d2) {
			object x = d1[Index];
			object y = d2[Index];
			if (ewr_Empty(Seq)) { // Default	
				if (ewr_IsNumeric(x) && ewr_IsNumeric(y)) {	
					Seq = "_number";
				} else if (Information.IsDate(x) && Information.IsDate(y)) {
					Seq = "_date";
				} else {
					Seq = "_string";
				}			
			}
			if (ewr_SameText(Seq, "_string") && Order == "ASC") { // String, ASC		
				return String.Compare(Convert.ToString(x), Convert.ToString(y));
			} else if (ewr_SameText(Seq, "_string") && Order == "DESC") { // String, DESC
				return String.Compare(Convert.ToString(y), Convert.ToString(x));
			} else if (ewr_SameText(Seq, "_number") && Order == "ASC") { // Number, ASC
				if (ewr_IsNumeric(x) && ewr_IsNumeric(y))
					return Convert.ToDouble(x).CompareTo(Convert.ToDouble(y));
			} else if (ewr_SameText(Seq, "_number") && Order == "DESC") { // Number, DESC
				if (ewr_IsNumeric(x) && ewr_IsNumeric(y))
					return Convert.ToDouble(y).CompareTo(Convert.ToDouble(x));
			} else if (ewr_SameText(Seq, "_date") && Order == "ASC") { // Date, ASC
				if (Information.IsDate(x) && Information.IsDate(y))
					return DateTime.Compare(Convert.ToDateTime(x), Convert.ToDateTime(y));
			} else if (ewr_SameText(Seq, "_date") && Order == "DESC") { // Date, DESC
				if (Information.IsDate(x) && Information.IsDate(y))
					return DateTime.Compare(Convert.ToDateTime(y), Convert.ToDateTime(x));
			} else if (ewr_NotEmpty(Seq) && Convert.ToString(Seq).Contains("|")) { // Custom sequence by delimited string
				string[] ar = Convert.ToString(Seq).Split(new char[] {'|'});
				if (Array.IndexOf(ar, Convert.ToString(x)) > -1 && Array.IndexOf(ar, Convert.ToString(y)) > -1)
					return (Array.IndexOf(ar, Convert.ToString(x)) - Array.IndexOf(ar, Convert.ToString(y)));
			}
			return 0;			
		}		
  	}

	// Sort chart data
	public void ewr_SortChartData(List<OrderedDictionary> ar, int opt, string seq = "") {
		if (!ewr_IsList(ar) || ((opt < 3 || opt > 4) && ewr_Empty(seq)) || ((opt < 1 || opt > 4) && ewr_NotEmpty(seq)))
			return;
		if ((opt == 3 || opt == 4) && ewr_Empty(seq))
			seq = "_number";
		switch (opt) {
			case 1:	// X values ascending
				ar.Sort(new ewr_ChartDataComparer(0, seq, "ASC"));
				break;
			case 2:	// X values descending
				ar.Sort(new ewr_ChartDataComparer(0, seq, "DESC"));
				break;
			case 3:	// Y values ascending					
				ar.Sort(new ewr_ChartDataComparer(2, seq, "ASC"));
				break;
			case 4:	// Y values descending
				ar.Sort(new ewr_ChartDataComparer(2, seq, "DESC"));	
				break;
		}
	}

	// Sort chart multi series data
	public void ewr_SortMultiChartData(List<OrderedDictionary> ar, int opt, string seq = "") {
		if (!ewr_IsList(ar) || ((opt < 3 || opt > 4) && ewr_Empty(seq)) || ((opt < 1 || opt > 4) && ewr_NotEmpty(seq)))
			return;
		if ((opt == 3 || opt == 4) && ewr_Empty(seq))
			seq = "_number";

		// Obtain a list of columns
		Hashtable xsums = new Hashtable();
		foreach (var d in ar) {
			if (xsums.Contains(d[0])) {
				xsums[d[0]] = ewr_ConvertToDouble(xsums[d[0]]) + ewr_ConvertToDouble(d[2]);
			} else {
				xsums[d[0]] = d[2];
			}
		}

		// Set up Y sum
		int idx = -1;
		if (opt == 3 || opt == 4) {
			foreach (var d in ar) {				
				if (idx == -1)
					idx = d.Count; 
				d.Add(idx, xsums[d[0]]); 				
			}		
		}
		switch (opt) {
			case 1: // X values ascending
				ar.Sort(new ewr_ChartDataComparer(0, seq, "ASC"));
				break;
			case 2: // X values descending
				ar.Sort(new ewr_ChartDataComparer(0, seq, "DESC"));
				break;
			case 3:
				ar.Sort(new ewr_ChartDataComparer(idx, seq, "ASC"));
				break;
			case 4: // Y values
				ar.Sort(new ewr_ChartDataComparer(idx, seq, "DESC"));
				break;
		}	
	}

	// Load array from sql
	public static void ewr_LoadArrayFromSql(string sql, List<string> ar) {
		if (ewr_Empty(sql))
			return;
		var rswrk = Conn.GetRows(sql);
		if (ar == null)
			ar = new List<string>();
		if (rswrk != null) {
			foreach (var row in rswrk) {
				var v = row[0];
				if (Convert.IsDBNull(v)) {
					v = EWR_NULL_VALUE;
				} else if (ewr_Empty(v)) {
					v = EWR_EMPTY_VALUE;
				}
				ar.Add(Convert.ToString(v));
			}
		}
	}

	// Match array as string
	public static bool ewr_MatchedArray(object ar1, object ar2) {     
		if (!ewr_IsList(ar1) && !ewr_IsList(ar2))	{
			return true;
		} else if (ewr_IsList(ar1) && ewr_IsList(ar2)) {
			return ewr_SameStr(String.Join(",", (IEnumerable<string>)ar1), String.Join(",", (IEnumerable<string>)ar2));
		}
		return false;
	}

	// Write a value to file for debug
	public static void ewr_Trace(object Msg) {
		string FileName = ewr_Server.MapPath("debug.txt");
		StreamWriter sw = File.AppendText(FileName);
		sw.WriteLine(Convert.ToString(Msg));
		sw.Close();
	}

	// Write HTTP header
	public static void ewr_Header(bool cache, string charset = EWR_CHARSET) {
		string export = ewr_Get("export");
		if (cache || !cache && ewr_IsHttps() && ewr_NotEmpty(export) && export != "print") { // Allow cache
			ewr_AddHeader("Cache-Control", "private, must-revalidate");
			ewr_AddHeader("Pragma", "public");
		} else { // No cache
			ewr_Response.Cache.SetCacheability(HttpCacheability.NoCache);
		}
		if (ewr_NotEmpty(charset)) // Charset
			ewr_Response.Charset = charset;
	}

	// Add HTTP header
	public static void ewr_AddHeader(string name, string value) {
		if (ewr_NotEmpty(name)) // value can be empty
			ewr_Response.AddHeader(name, value);
	}

	// Get content type
	public static string ewr_ContentType(IEnumerable<byte> data) {
		if (data.Take(6).SequenceEqual(new byte[] {0x47, 0x49, 0x46, 0x38, 0x37, 0x61}) || data.Take(6).SequenceEqual(new byte[] {0x47, 0x49, 0x46, 0x38, 0x39, 0x61})) { // gif
			return "image/gif";
		} else if (data.Take(4).SequenceEqual(new byte[] {0xFF, 0xD8, 0xFF, 0xE0}) && data.Skip(6).Take(5).SequenceEqual(new byte[] {0x4A, 0x46, 0x49, 0x46, 0x00})) { // jpg
			return "image/jpeg";
		} else if (data.Take(8).SequenceEqual(new byte[] {0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A})) { // png
			return "image/png";
		} else if (data.Take(2).SequenceEqual(new byte[] {0x42, 0x4D})) { // bmp
			return "image/bmp";
		} else if (data.Take(4).SequenceEqual(new byte[] {0x25, 0x50, 0x44, 0x46})) { // pdf
			return "application/pdf";
		} else {
			return "images";
		}
	}

	//
	// Connection object
	//
	public class cConnectionBase : IDisposable
	{

		public string ConnectionString = EWR_DB_CONNECTION_STRING;

		public ewConnection Conn;		

		public ewTransaction Trans;

		private ewConnection _Conn; 

		private List<ewCommand> _Command = new List<ewCommand>(); 

		private List<ewDataReader> _DataReader = new List<ewDataReader>();

		// Constructor
		public cConnectionBase(string ConnStr)
		{
			ConnectionString = ConnStr;
			Conn = OpenConnection();		
		}

		// Constructor
		public cConnectionBase() : this(EWR_DB_CONNECTION_STRING)
		{			
		}

		// Execute SQL for the main connection
		public int Execute(string Sql)
		{			
			var cmd = GetCommand(Sql);
			var res = cmd.ExecuteNonQuery();
			return res;			
		}

		// Execute SQL for a specified connection
		public int Execute(string Sql, ewConnection Cnn)
		{			
			if (EWR_DEBUG_ENABLED)
				ewr_SetDebugMsg(Sql); // Show SQL for debugging
			using (var cmd = new ewCommand(Sql, Cnn)) {
				return cmd.ExecuteNonQuery();
			}			
		}

		// Execute SQL
		public int ExecuteNonQuery(string Sql)
		{			
			using (var cmd = OpenCommand(Sql)) { // Use new connection
				return cmd.ExecuteNonQuery();
			}		
		}

		// Execute SQL and return first value of first row
		public object ExecuteScalar(string Sql)
		{
			using (var cmd = OpenCommand(Sql)) { // Use new connection
				return cmd.ExecuteScalar();
			}
		}

		// Get last insert ID
		public object GetLastInsertId()
		{
			using (var cmd = GetCommand("SELECT @@Identity")) { // Use main connection
				return cmd.ExecuteScalar();
			}			
			return System.DBNull.Value;
		}

		// Get data reader
		public ewDataReader GetDataReader(string Sql)
		{
			try {
				var cmd = GetCommand(Sql);  // Use main connection
				return cmd.ExecuteReader();
			} catch {
				if (EWR_DEBUG_ENABLED)
					throw; 
				return null;
			}
		}

		// Get a new connection
		public ewConnection OpenConnection()
		{
			Database_Connecting(ref ConnectionString); 
			var c = new ewConnection(ConnectionString);			
			c.Open();
			Database_Connected(c);
			return c; 
		}		

		// Get a new command
		public ewCommand OpenCommand(string Sql)
		{ 
			if (EWR_DEBUG_ENABLED)
				ewr_SetDebugMsg(Sql); // Show SQL for debugging
			try {
				if (_Conn == null)
					_Conn = OpenConnection(); // Use secondary connection							
				var cmd = new ewCommand(Sql, _Conn);					
				_Command.Add(cmd);							
				return cmd;
			} catch {
				if (EWR_DEBUG_ENABLED)
					throw; 
				return null;
			}
		}

		// Get a new data reader
		public ewDataReader OpenDataReader(string Sql)
		{ 
			try {
				var cmd = OpenCommand(Sql); // Use secondary connection					
				var r = cmd.ExecuteReader();
				_DataReader.Add(r);			
				return r;
			} catch {
				if (EWR_DEBUG_ENABLED)
					throw; 
				return null;
			}
		}

		// Get a row as OrderedDictionary from data reader
		public OrderedDictionary GetRow(ewDataReader dr)
		{
			if (dr != null) {
				var od = new OrderedDictionary();
				for (int i = 0; i < dr.FieldCount; i++) {
					try {
						if (ewr_NotEmpty(dr.GetName(i))) {
							od[dr.GetName(i)] = dr[i];
						} else {
							od[Convert.ToString(i)] = dr[i];
						}
					} catch {}
				}
				return od;
			}
			return null;
		}

		// Get a row as OrderedDictionary by SQL
		public OrderedDictionary GetRow(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {			
				if (dr != null && dr.Read())
					return GetRow(dr);				
			}
			return null;			
		}

		// Get a row as string[] from data reader
		public string[] GetRow2(ewDataReader dr)
		{
			if (dr != null && dr.FieldCount > 0) {
				var ar = new string[dr.FieldCount];
				for (int i = 0; i < dr.FieldCount; i++)
					ar[i] = Convert.ToString(dr[i]);
				return ar;
			}
			return null;
		}		

		// Get rows as List<OrderedDictionary>
		public List<OrderedDictionary> GetRows(ewDataReader dr)
		{
			if (dr != null) {		
				var rows = new List<OrderedDictionary>();
				while (dr.Read())
					rows.Add(GetRow(dr));
				dr.Close();
				dr.Dispose();
				return rows;
			}
			return null;
		}

		// Get rows as List<OrderedDictionary> by SQL
		public List<OrderedDictionary> GetRows(string Sql)
		{
			var dr = OpenDataReader(Sql);
			return GetRows(dr);			
		}

		// Get rows as List<string[]> by SQL
		public List<string[]> GetRows2(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {
				if (dr != null) {		
					var rows = new List<string[]>();
					while (dr.Read())
						rows.Add(GetRow2(dr));
					return rows;
				}
			}
			return null;			
		}		

		// Get rows as List<DbDataRecord> by SQL
		public List<DbDataRecord> GetRecords(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {
				if (dr != null) {				
					var list = new List<DbDataRecord>();		
					foreach (DbDataRecord record in dr)
						list.Add(record);
					return list;
				}
			}
			return null;
		}

		// Get first row as DbDataRecord by SQL
		public DbDataRecord GetRecord(string Sql)
		{
			using (var dr = OpenDataReader(Sql)) {
				if (dr != null) {
					foreach (DbDataRecord r in dr)
		               return r;  
				}
			}
			return null;			
		}		

		// Get count
		public int GetCount(string Sql)
		{
			int cnt = 0;
			using (var dr = OpenDataReader(Sql)) {			
				if (dr != null) {
					while (dr.Read())
						cnt++;
				}
			}
			return cnt;			
		}

		// Get command
		public ewCommand GetCommand(string Sql)
		{
			if (EWR_DEBUG_ENABLED)
				ewr_SetDebugMsg(Sql); // Show SQL for debugging
			var Cmd = new ewCommand(Sql, Conn);
			if (Trans != null)
				Cmd.Transaction = Trans; 
			return Cmd;
		}

		// Begin transaction
		public void BeginTrans()
		{
			try {
				Trans = Conn.BeginTransaction();
			} catch {
				if (EWR_DEBUG_ENABLED)
					throw; 
			}
		}

		// Commit transaction
		public void CommitTrans()
		{
			try {
				if (Trans != null)
					Trans.Commit();
			} catch {
				if (EWR_DEBUG_ENABLED)
					throw; 
			} 
		}

		// Rollback transaction
		public void RollbackTrans()
		{
			try {
				if (Trans != null)
					Trans.Rollback();
			} catch {
				if (EWR_DEBUG_ENABLED)
					throw; 
			} 
		}

		// Concat // ASPX
		public string Concat(params string[] list) {
			if (EWR_IS_MSACCESS) {
				return String.Join(" & ", list);
			} else if (EWR_IS_MSSQL) { 
				return String.Join(" + ", list);			
			} else if (EWR_IS_ORACLE || EWR_IS_POSTGRESQL) {
				return String.Join(" || ", list);
			} else { // MySQL/ODBC 
				return "CONCAT(" + String.Join(", ", list) + ")";
			}
		}

		// Dispose
		public void Dispose()
		{
			if (Trans != null)
				Trans.Dispose(); 
			Conn.Close();
			Conn.Dispose();
			foreach (ewDataReader dr in _DataReader) {
				if (dr != null) {
					dr.Close();
					dr.Dispose();
				}
			}
			foreach (ewCommand cmd in _Command) {
				if (cmd != null)
					cmd.Dispose();
			}
			if (_Conn != null) {
				_Conn.Close();
				_Conn.Dispose();
			}
		}

		// Close
		public void Close()
		{
			Dispose();
		}

		// Database Connecting event
		public virtual void Database_Connecting(ref string Connstr) {

			//ewr_Write("Database Connecting");
		}

		// Database Connected event
		public virtual void Database_Connected(ewConnection Cnn) {

			//Execute("Your SQL", Cnn);
		}
	}

	// Convert object to bool
	public static bool ewr_ConvertToBool(object value)
	{
		try {
			if (value is bool) {
				return Convert.ToBoolean(value);
			} else if (ewr_IsNumeric(value)) {
				return Convert.ToBoolean(ewr_ConvertToDouble(value));
			} else {
				return ewr_SameStr(value, "y") || ewr_SameStr(value, "t");
			}
		} catch {
			return false;
		}
	}	

	// Encode HTML
	public static string ewr_HtmlEncode(object Expression)
	{
		return ewr_Server.HtmlEncode(Convert.ToString(Expression));
	}

	// Encode value for single-quoted JavaScript string
	public static string ewr_JsEncode(object val)
	{
		string outstr = Convert.ToString(val).Replace("\\", "\\\\");
		outstr = outstr.Replace("'", "\\'");
		outstr = outstr.Replace("\r\n", "<br>");
		outstr = outstr.Replace("\r", "<br>");
		outstr = outstr.Replace("\n", "<br>");
		return outstr;		
	}

	// Encode value for double-quoted JavaScript string
	public static string ewr_JsEncode2(object val)
	{
		string outstr = Convert.ToString(val).Replace("\\", "\\\\");
		outstr = outstr.Replace("\"", "\\\"");
		outstr = outstr.Replace("\t", "\\t");
		outstr = outstr.Replace("\r", "\\r");
		outstr = outstr.Replace("\n", "\\n");
		return outstr;
	}	

	// Encode value to single-quoted Javascript string for HTML attributes
	public static string ewr_JsEncode3(object val)
	{
		string outstr = Convert.ToString(val).Replace("\\", "\\\\");
		outstr = outstr.Replace("'", "\\'");
		outstr = outstr.Replace("\"", "&quot;");
		return outstr;
	}

	// View Option Separator
	public static string ewr_ViewOptionSeparator(int idx = -1)
	{
		return ", ";
	}

	// Send email
	public static bool ewr_SendEmail(string sFrEmail, string sToEmail, string sCcEmail, string sBccEmail, string sSubject, string sMail, string sFormat, string sCharset, bool bSsl = false, string sAttachmentFileName = "", string sAttachmentContent = "", List<string> arImages = null)
	{
		var mail = new System.Net.Mail.MailMessage();
		if (ewr_NotEmpty(sFrEmail)) {
			var m = Regex.Match(sFrEmail.Trim(), @"^(.+)<([\w.%+-]+@[\w.-]+\.[A-Z]{2,6})>$", RegexOptions.IgnoreCase);
			if (m.Success) {
				mail.From = new System.Net.Mail.MailAddress(m.Groups[2].Value, m.Groups[1].Value);
			} else {
				mail.From = new System.Net.Mail.MailAddress(sFrEmail);
			}			
		}
		if (ewr_NotEmpty(sToEmail)) {
			sToEmail = sToEmail.Replace(',', ';');
			string[] arTo = sToEmail.Split(new char[] {';'});
			foreach (string strTo in arTo)
				mail.To.Add(strTo);
		}
		if (ewr_NotEmpty(sCcEmail)) {
			sCcEmail = sCcEmail.Replace(',', ';');
			string[] arCC = sCcEmail.Split(new char[] {';'});
			foreach (string strCC in arCC)
				mail.CC.Add(strCC);
		}
		if (ewr_NotEmpty(sBccEmail)) {
			sBccEmail = sBccEmail.Replace(',', ';');
			string[] arBcc = sBccEmail.Split(new char[] {';'});
			foreach (string strBcc in arBcc)
				mail.Bcc.Add(strBcc);
		}
		mail.Subject = sSubject;
		mail.Body = sMail;
		mail.IsBodyHtml = ewr_SameText(sFormat, "html");
		if (ewr_NotEmpty(sCharset) && !ewr_SameText(sCharset, "iso-8859-1"))
			mail.BodyEncoding = Encoding.GetEncoding(sCharset); 
		var smtp = new System.Net.Mail.SmtpClient();
		if (ewr_NotEmpty(EWR_SMTP_SERVER)) {
			smtp.Host = EWR_SMTP_SERVER;
		} else {
			smtp.Host = "localhost";
		}
		if (EWR_SMTP_SERVER_PORT > 0)
			smtp.Port = EWR_SMTP_SERVER_PORT;
		smtp.EnableSsl = bSsl;	
		if (ewr_NotEmpty(EWR_SMTP_SERVER_USERNAME) && ewr_NotEmpty(EWR_SMTP_SERVER_PASSWORD)) {
			var smtpuser = new System.Net.NetworkCredential();
			smtpuser.UserName = EWR_SMTP_SERVER_USERNAME;
			smtpuser.Password = EWR_SMTP_SERVER_PASSWORD;
			smtp.UseDefaultCredentials = false;
			smtp.Credentials = smtpuser;
		}
		if (ewr_NotEmpty(sAttachmentFileName) && ewr_NotEmpty(sAttachmentContent)) { // HTML
			byte[] arByte = mail.BodyEncoding.GetBytes(sAttachmentContent);
			var stream = new MemoryStream(arByte);
			var data = new Attachment(stream, new ContentType(MediaTypeNames.Text.Html));
			ContentDisposition disposition = data.ContentDisposition;
			disposition.FileName = sAttachmentFileName;
			mail.Attachments.Add(data);
		} else if (ewr_NotEmpty(sAttachmentFileName)) { //URL
			var data = new Attachment(sAttachmentFileName, new ContentType(MediaTypeNames.Text.Html));
			mail.Attachments.Add(data);
		}
		if (mail.IsBodyHtml && arImages != null && arImages.Count > 0) {
			string html = mail.Body;
			foreach (string tmpimage in arImages) {
				string file = ewr_UploadPathEx(true, EWR_UPLOAD_DEST_PATH) + tmpimage;				
				string cid = ewr_TmpImageLnk(tmpimage, "email");
				html = html.Replace(file, cid);
			}
			AlternateView htmlview = AlternateView.CreateAlternateViewFromString(html, null, "text/html");			
			foreach (string tmpimage in arImages) {
				string file = ewr_UploadPathEx(true, EWR_UPLOAD_DEST_PATH) + tmpimage;
				if (File.Exists(file)) {
					LinkedResource res = new LinkedResource(file);
					res.ContentId = ewr_TmpImageLnk(tmpimage, "cid");				
					htmlview.LinkedResources.Add(res);
				}
			}
			mail.AlternateViews.Add(htmlview);
		}
		try {
			smtp.Send(mail);
			return true;
		} catch (Exception e) {
			gsEmailErrDesc = e.ToString();
			if (EWR_DEBUG_ENABLED) throw; 
			return false;
		}
	}

	// Load email count
	public static int ewr_LoadEmailCount() {

		// Read from log
		if (EWR_EMAIL_WRITE_LOG) {
			string ip = ewr_ServerVar("REMOTE_ADDR");

			// Load from database
			if (EWR_EMAIL_WRITE_LOG_TO_DATABASE) {
				string dt1 = DateTime.Now.AddMinutes(EWR_MAX_EMAIL_SENT_PERIOD * -1).ToString("yyyyMMdd HH:mm:ss");
				string dt2 = DateTime.Now.ToString("yyyyMMdd HH:mm:ss");
				string sEmailSql = "SELECT COUNT(*) FROM " + ewr_QuotedName(EWR_EMAIL_LOG_TABLE_NAME) +
					" WHERE " + ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_DATETIME) +
					" BETWEEN " + ewr_QuotedValue(dt1, EWR_DATATYPE_DATE) + " AND " + ewr_QuotedValue(dt2, EWR_DATATYPE_DATE) +
					" AND " + ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_IP) + 
					" = " + ewr_QuotedValue(ip, EWR_DATATYPE_STRING);
				int cnt = ewr_ConvertToInt(Conn.ExecuteScalar(sEmailSql));
				if (cnt > -1) {
					ewr_Session[EWR_EXPORT_EMAIL_COUNTER] = cnt;
				} else {
					ewr_Session[EWR_EXPORT_EMAIL_COUNTER] = 0;
				}

			// Load from log file
			} else {
				string pfx = "email";
				string sTab = "\t";
				string sFolder = EWR_UPLOAD_DEST_PATH;
				string randomkey = ewr_Encrypt(DateTime.Today.ToString("yyyyMMdd"), EWR_RANDOM_KEY);
				randomkey = randomkey.Replace("_", "").Replace("-", "").Replace(".", "");
				if (randomkey.Length > 32) randomkey = randomkey.Substring(0, 32);
				string sFn = pfx + "_" + DateTime.Today.ToString("yyyyMMdd") + "_" + randomkey + ".txt";
				string filename = ewr_UploadPathEx(true, sFolder) + sFn;
				if (File.Exists(filename)) {
					string[] arLines = File.ReadAllLines(filename);
					int cnt = 0;
					foreach (string line in arLines) {
						if (ewr_NotEmpty(line)) {
							string[] arwrk = line.Split(new char[] {Convert.ToChar(sTab)});
							DateTime dtwrk;
							if (DateTime.TryParse(arwrk[0], out dtwrk)) {
								string ipwrk = arwrk[1];
								if (ipwrk == ip && dtwrk.AddMinutes(EWR_MAX_EMAIL_SENT_PERIOD) > DateTime.Now)
									cnt++;
							}
						}
					}
					ewr_Session[EWR_EXPORT_EMAIL_COUNTER] = cnt;
				} else {
					ewr_Session[EWR_EXPORT_EMAIL_COUNTER] = 0;
				}
			}
		}
		if (ewr_Session[EWR_EXPORT_EMAIL_COUNTER] == null)
			ewr_Session[EWR_EXPORT_EMAIL_COUNTER] = 0;
		return ewr_ConvertToInt(ewr_Session[EWR_EXPORT_EMAIL_COUNTER]);
	}

	// Add email log
	public static void ewr_AddEmailLog(string sender, string recipient, string subject, string message) {
		int cnt = ewr_ConvertToInt(ewr_Session[EWR_EXPORT_EMAIL_COUNTER]);
		ewr_Session[EWR_EXPORT_EMAIL_COUNTER] = cnt++;

		// Save to email log
		if (EWR_EMAIL_WRITE_LOG) {
			string dt = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
			string ip = ewr_ServerVar("REMOTE_ADDR");
			string senderwrk = ewr_TruncateText(sender);
			string recipientwrk = ewr_TruncateText(recipient);
			string subjectwrk = ewr_TruncateText(subject);
			string messagewrk = ewr_TruncateText(message);

			// Save to database
			if (EWR_EMAIL_WRITE_LOG_TO_DATABASE) {
				string sEmailSql = "INSERT INTO " + ewr_QuotedName(EWR_EMAIL_LOG_TABLE_NAME) +
					" (" + ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_DATETIME) + ", " +
					ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_IP) + ", " +
					ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_SENDER) + ", " +
					ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_RECIPIENT) + ", " +
					ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_SUBJECT) + ", " +
					ewr_QuotedName(EWR_EMAIL_LOG_FIELD_NAME_MESSAGE) + ") VALUES (" +
					ewr_QuotedValue(dt, EWR_DATATYPE_DATE) + ", " +
					ewr_QuotedValue(ip, EWR_DATATYPE_STRING) + ", " +
					ewr_QuotedValue(senderwrk, EWR_DATATYPE_STRING) + ", " +
					ewr_QuotedValue(recipientwrk, EWR_DATATYPE_STRING) + ", " +
					ewr_QuotedValue(subjectwrk, EWR_DATATYPE_STRING) + ", " +
					ewr_QuotedValue(messagewrk, EWR_DATATYPE_STRING) + ")";
				Conn.Execute(sEmailSql);

			// Save to log file
			} else {
				string pfx = "email";
				string sTab = "\t";
				string sHeader = "date/time" + sTab + "ip" + sTab + "sender" + sTab + "recipient" + sTab + "subject" + sTab + "message";
				string sMsg = dt + sTab + ip + sTab + senderwrk + sTab + recipientwrk + sTab + subjectwrk + sTab + messagewrk;
				string sFolder = EWR_UPLOAD_DEST_PATH;
				string randomkey = ewr_Encrypt(DateTime.Today.ToString("yyyyMMdd"), EWR_RANDOM_KEY);
				randomkey = randomkey.Replace("_", "").Replace("-", "").Replace(".", "");
				if (randomkey.Length > 32) randomkey = randomkey.Substring(0, 32);
				string sFn = pfx + "_" + DateTime.Today.ToString("yyyyMMdd") + "_" + randomkey + ".txt";
				string filename = ewr_UploadPathEx(true, sFolder) + sFn;
				StreamWriter sw;
				if (File.Exists(filename)) {
					sw = File.AppendText(filename);
				} else {
					sw = File.CreateText(filename);
					sw.WriteLine(sHeader);
				}
				sw.WriteLine(sMsg);
				sw.Close();
			}
		}
	}

	// Truncate text
	public static string ewr_TruncateText(string v) {
		int maxlen = EWR_EMAIL_LOG_SIZE_LIMIT;
		v = v.Replace("\r\n", " ");
		v = v.Replace("\t", " ");
		if (v.Length > maxlen)
			v = v.Substring(0, maxlen-3) + "...";
		return v;
	}

	// Get current page name
	public static string ewr_CurrentPage()
	{
		return ewr_GetPageName(ewr_ServerVar("SCRIPT_NAME"));
	}

	// Get refer page name
	public static string ewr_ReferPage()
	{
		return ewr_GetPageName(ewr_ServerVar("HTTP_REFERER"));
	}

	// Get page name // ASPX
	public static string ewr_GetPageName(string url)
	{
		if (ewr_NotEmpty(url)) {
			if (url.Contains("?"))
				url = url.Substring(0, url.LastIndexOf("?")); // Remove querystring first
			string p = ewr_CurrentPath(false); // Current relative path	
			url = url.Substring(url.LastIndexOf(p) + p.Length); // Remove path
			if (url.Contains("/"))
				url = url.Substring(0, url.IndexOf("/")); // Remove UrlData, if any
			return url;			
		}
		return "";
	}

	// YUI files host
	public static string ewr_YuiHost() {
		return "yui290/"; // Use local files
	}

	// jQuery files host
	public static string ewr_jQueryHost(bool mobile) {
		return "jquery/"; // Use local files
	}

	// jQuery version
	public static string ewr_jQueryFile(string f) {
		string ver = "1.9.1"; // jQuery version
		string mver = "1.3.0"; // jquery.mobile version
		bool m = f.Contains("mobile");
		string v = (m) ? mver : ver;
		return (ewr_jQueryHost(m) + f).Replace("%v", v);
	}

	// Check if HTTPS
	public static bool ewr_IsHttps() {
		return !ewr_SameText(ewr_ServerVar("HTTPS"), "off") & ewr_NotEmpty(ewr_ServerVar("HTTPS"));
	}

	// Get browser type and version
	public static string[] ewr_UserAgent() {
		string browser, browser_version; 
		string useragent = ewr_ServerVar("HTTP_USER_AGENT");
		Match m;		
		if ((m = Regex.Match(useragent, @"MSIE ([0-9].[0-9]{1,2})")) != null && m.Success) {
			browser = "IE";
			browser_version = m.Groups[1].Value;
		} else if ((m = Regex.Match(useragent, @"Firefox/([0-9\.]+)")) != null && m.Success) {
			browser = "Firefox";
			browser_version = m.Groups[1].Value;
		} else if ((m = Regex.Match(useragent, @"Opera/([0-9].[0-9]{1,2})")) != null && m.Success) {
			browser = "Opera";
			browser_version = m.Groups[1].Value;
		} else if ((m = Regex.Match(useragent, @"Chrome/([0-9\.]+)")) != null && m.Success) {
			browser = "Chrome";
			browser_version = m.Groups[1].Value;
		} else if ((m = Regex.Match(useragent, @"Version/([0-9\.]+)")) != null && m.Success && Regex.IsMatch(useragent, @"Safari/")) {
			browser = "Safari";
			browser_version = m.Groups[1].Value;
		} else { // browser not recognized
			browser = "Other";
			browser_version = "0";
		}
		string[] ver = browser_version.Split(new char[] { '.' });
		string[] ua = new string[ver.Length + 1];
		ua[0] = browser;
		ver.CopyTo(ua, 1);
		return ua;
	}

	// Check if mobile device
	public static bool ewr_IsMobile() {	

		//string useragent = ewr_ServerVar("HTTP_USER_AGENT");
	    return EWR_USE_MOBILE_MENU && ewr_Request.Browser.IsMobileDevice;
	}

	// Get server variable by name
	public static string ewr_ServerVar(string Name) {
		string str = "";
		if (ewr_Request.ServerVariables[Name] != null);
			str = ewr_Request.ServerVariables[Name];
		return str;
	}

	// Encrypt password
	public static string ewr_EncryptPassword(string input) {
		return ewr_MD5(input);
	}

	// Compare password
	public static bool ewr_ComparePassword(string pwd, string input) {
		if (EWR_CASE_SENSITIVE_PASSWORD) {
			if (EWR_ENCRYPTED_PASSWORD) {
				return (pwd == ewr_EncryptPassword(input));
			} else {
				return ewr_SameStr(pwd, input);
			}
		} else {
			if (EWR_ENCRYPTED_PASSWORD) {
				return (pwd == ewr_EncryptPassword(input.ToLower()));
			} else {
				return ewr_SameText(pwd, input);
			}
		}
	}	

	// MD5
	public static string ewr_MD5(string InputStr)
	{
		var Md5Hasher = new MD5CryptoServiceProvider();
		byte[] Data = Md5Hasher.ComputeHash(Encoding.Unicode.GetBytes(InputStr));
		var sBuilder = new StringBuilder();
		for (int i = 0; i <= Data.Length - 1; i++) {
			sBuilder.Append(Data[i].ToString("x2"));
		}
		return sBuilder.ToString();
	}

	// CRC32
	public static uint ewr_CRC32(string InputStr) {
		byte[] bytes = Encoding.Unicode.GetBytes(InputStr);
		uint crc = 0xffffffff;
		uint poly	=	0xedb88320;
		uint[] table = new uint[256];
		uint temp = 0;
		for (uint i = 0; i < table.Length; ++i) {
			temp = i;
			for (int j = 8; j > 0; --j) {
				if ((temp & 1) == 1) {
					temp = (uint)((temp >> 1) ^ poly);
				} else {
					temp >>= 1;
				}
			}
			table[i] = temp;
		}
		for (int i = 0; i < bytes.Length; ++i) {
			byte index = (byte)(((crc) & 0xff) ^ bytes[i]);
			crc = (uint)((crc >> 8) ^ table[index]);
		}
		return ~crc;
	}

	// Check if object is List/Dictionary
	public static bool ewr_IsList(object obj)
	{
		return (obj != null) && (obj is IList || obj is IDictionary); // AXR
	}

	// check if a value is in a string array
	public static bool ewr_Contains(object str, string[] ar)
	{
		return (new List<string>(ar)).Contains(Convert.ToString(str)); 
	}

	// check if a value is in an integer array
	public static bool ewr_Contains(object i, int[] ar)
	{
		try {
			return (new List<int>(ar)).Contains(Convert.ToInt32(i));
		} catch {
			return false;
		} 
	}

	// Get domain URL
	public static string ewr_DomainUrl() {
		bool bSSL = ewr_IsHttps();
		string sUrl = (bSSL) ? "https": "http";
		string sPort = ewr_ServerVar("SERVER_PORT");
		string defPort = (bSSL) ? "443" : "80";
		sPort = (sPort == defPort) ? "" : ":" + sPort; 
		return sUrl + "://" + ewr_ServerVar("SERVER_NAME") + sPort;
	}

	// Get full URL
	public static string ewr_FullUrl() {
		return ewr_DomainUrl() + ewr_ServerVar("SCRIPT_NAME");
	}

	// Get current URL
	public static string ewr_CurrentUrl() {
		string s = ewr_ServerVar("SCRIPT_NAME");
		string q = ewr_ServerVar("QUERY_STRING");
		if (ewr_NotEmpty(q))
			s += "?" + q;
		return s;
	}

	// Get application root path (relative to domain)
	public static string ewr_AppPath() {
		string Path = ewr_ServerVar("APPL_MD_PATH");
		int pos = Path.IndexOf("Root", StringComparison.InvariantCultureIgnoreCase); // Note: IgnoreCase
		if (pos > 0)
			Path = Path.Substring(pos + 4); 
		return Path;
	}

	// Convert to full URL
	public static string ewr_ConvertFullUrl(string url) {
		if (ewr_Empty(url)) {
			return "";
		} else if (url.Contains("://")) {
			return url;
		} else {
			string sUrl = ewr_FullUrl();
			return sUrl.Substring(0, sUrl.LastIndexOf("/") + 1) + url;
		}
	}

	// Get script name
	public static string ewr_ScriptName() {
		string sn = ewr_ServerVar("SCRIPT_NAME");
		if (ewr_Empty(sn)) sn = ewr_ServerVar("PATH_INFO");
		if (ewr_Empty(sn)) sn = ewr_ServerVar("URL");
		if (ewr_Empty(sn)) sn = "UNKNOWN";
		return sn;
	}	

	// Load selection from a filter clause
	public static void ewr_LoadSelectionFromFilter(crField fld, string filter, List<string> sel, object af = null) {
		sel.Clear(); // AXR
		if (af != null) { // Set up advanced filter first
			IEnumerable<string> ar = ewr_IsList(af) ? (IEnumerable<string>)af : new string[] { Convert.ToString(af) };
			foreach (var str in ar) {
				if (str.StartsWith("@@")) {

					//if (sel == null)
						//sel = new List<string>();

					sel.Add(str);
				}
			}
		}
		if (ewr_NotEmpty(filter)) {
			string sSql = ewr_BuildReportSql(fld.SqlSelect, "", "", "", fld.SqlOrderBy, filter, "");
			ewr_LoadArrayFromSql(sSql, sel);
		}
	}

	// Load drop down list
	public static void ewr_LoadDropDownList(List<string> list, object val) {
		List<string> ar = new List<string>(); // AXR
		if (ewr_IsList(val)) {
			ar.AddRange((IEnumerable<string>)val);
		} else if (!ewr_SameStr(val, EWR_INIT_VALUE) && !ewr_SameStr(val, EWR_ALL_VALUE) && ewr_NotEmpty(val)) {
			ar.Add(Convert.ToString(val));
		}
		if (list != null) {
			list.Clear();
		} else {
			list = new List<string>();
		}
		foreach (var v in ar) {
			if (v != EWR_INIT_VALUE && ewr_NotEmpty(v) && !v.StartsWith("@@"))
				list.Add(v);
		}
	}

	// Load selection list
	public static void ewr_LoadSelectionList(object list, object val) {
		List<string> ar = new List<string>(); // AXR
		if (ewr_IsList(val)) {
			ar.AddRange((IEnumerable<string>)val);
		} else if (!ewr_SameStr(val, EWR_INIT_VALUE) && !ewr_SameStr(val, EWR_ALL_VALUE) && ewr_NotEmpty(val)) {
			ar.Add(Convert.ToString(val));
		}
		var sl = new List<string>();
		foreach (var v in ar) {
			if (v == EWR_ALL_VALUE) {
				list = EWR_INIT_VALUE;
				return;
			} else if (v != EWR_INIT_VALUE && ewr_NotEmpty(v)) {
				sl.Add(v);
			}
		}
		if (sl.Count == 0) {
            list = EWR_INIT_VALUE;
        } else {
            list = sl;
        }
	}

	// Get extended filter
	public static string ewr_GetExtendedFilter(crField fld, bool def = false) {
		var FldName = fld.FldName;
		var FldExpression = fld.FldExpression;
		var FldDataType = fld.FldDataType;
		var FldDateTimeFormat = fld.FldDateTimeFormat;
		var FldVal1 = (def) ? fld.DefaultSearchValue : fld.SearchValue;
		if (ewr_IsFloatFormat(fld.FldType)) FldVal1 = ewr_StrToFloat(FldVal1);
		var FldOpr1 = (def) ? fld.DefaultSearchOperator : fld.SearchOperator;
		var FldCond = (def) ? fld.DefaultSearchCondition : fld.SearchCondition;
		var FldVal2 = (def) ? fld.DefaultSearchValue2 : fld.SearchValue2;
		if (ewr_IsFloatFormat(fld.FldType)) FldVal2 = ewr_StrToFloat(FldVal2);
		var FldOpr2 = (def) ? fld.DefaultSearchOperator2 : fld.SearchOperator2;
		var sWrk = "";
		FldOpr1 = FldOpr1.Trim().ToUpper();
		if (ewr_Empty(FldOpr1)) FldOpr1 = "=";
		FldOpr2 = FldOpr2.Trim().ToUpper();
		if (ewr_Empty(FldOpr2)) FldOpr2 = "=";
		var wrkFldVal1 = Convert.ToString(FldVal1);
		var wrkFldVal2 = Convert.ToString(FldVal2);
		if (FldDataType == EWR_DATATYPE_BOOLEAN) {
			if (EWR_IS_MSACCESS) {
				if (ewr_NotEmpty(wrkFldVal1)) wrkFldVal1 = (wrkFldVal1 == "1") ? "True" : "False";
				if (ewr_NotEmpty(wrkFldVal2)) wrkFldVal2 = (wrkFldVal2 == "1") ? "True" : "False";
			} else {
				if (ewr_NotEmpty(wrkFldVal1)) wrkFldVal1 = (wrkFldVal1 == "1") ? "1" : "0";
				if (ewr_NotEmpty(wrkFldVal2)) wrkFldVal2 = (wrkFldVal2 == "1") ? "1" : "0";
			}
		} else if (FldDataType == EWR_DATATYPE_DATE) {
			if (ewr_NotEmpty(wrkFldVal1)) wrkFldVal1 = ewr_UnformatDateTime(wrkFldVal1, FldDateTimeFormat);
			if (ewr_NotEmpty(wrkFldVal2)) wrkFldVal2 = ewr_UnformatDateTime(wrkFldVal2, FldDateTimeFormat);
		}
		if (FldOpr1 == "BETWEEN") {
			var IsValidValue = (FldDataType != EWR_DATATYPE_NUMBER ||
				(FldDataType == EWR_DATATYPE_NUMBER && ewr_IsNumeric(wrkFldVal1) && ewr_IsNumeric(wrkFldVal2)));
			if (ewr_NotEmpty(wrkFldVal1) && ewr_NotEmpty(wrkFldVal2) && IsValidValue)
				sWrk = FldExpression + " BETWEEN " + ewr_QuotedValue(wrkFldVal1, FldDataType) +
					" AND " + ewr_QuotedValue(wrkFldVal2, FldDataType);
		} else if (FldVal1 == EWR_NULL_VALUE || FldOpr1 == "IS NULL") {
	        sWrk = FldExpression + " IS NULL";
	    } else if (FldVal1 == EWR_NOT_NULL_VALUE || FldOpr1 == "IS NOT NULL") {
	        sWrk = FldExpression + " IS NOT NULL";
		} else {
			var IsValidValue = (FldDataType != EWR_DATATYPE_NUMBER ||
				(FldDataType == EWR_DATATYPE_NUMBER && ewr_IsNumeric(wrkFldVal1)));
			if (ewr_NotEmpty(wrkFldVal1) && IsValidValue && ewr_IsValidOpr(FldOpr1, FldDataType))
				sWrk = FldExpression + ewr_FilterString(FldOpr1, wrkFldVal1, FldDataType);
			IsValidValue = (FldDataType != EWR_DATATYPE_NUMBER ||
				(FldDataType == EWR_DATATYPE_NUMBER && ewr_IsNumeric(wrkFldVal2)));
			if (ewr_NotEmpty(wrkFldVal2) && IsValidValue && ewr_IsValidOpr(FldOpr2, FldDataType)) {
				if (ewr_NotEmpty(sWrk))
					sWrk += " " + ((FldCond == "OR") ? "OR" : "AND") + " ";
				sWrk += FldExpression + ewr_FilterString(FldOpr2, wrkFldVal2, FldDataType);
			}
		}
		return sWrk;
	}

	// Return search string
	public static string ewr_FilterString(string FldOpr, string FldVal, int FldType) {
		if (FldVal == EWR_NULL_VALUE || FldOpr == "IS NULL") {
			return " IS NULL";
		} else if (FldVal == EWR_NOT_NULL_VALUE || FldOpr == "IS NOT NULL") {
			return " IS NOT NULL";
		} else if (FldOpr == "LIKE") {
			return ewr_Like(ewr_QuotedValue("%" + FldVal + "%", FldType));
		} else if (FldOpr == "NOT LIKE") {
			return " NOT " + ewr_Like(ewr_QuotedValue("%" + FldVal + "%", FldType));
		} else if (FldOpr == "STARTS WITH") {
			return ewr_Like(ewr_QuotedValue(FldVal + "%", FldType));
		} else {
			return " " + FldOpr + " " + ewr_QuotedValue(FldVal, FldType);
		}
	}

	// Append like operator
	public static string ewr_Like(string pat) {
		if (ewr_NotEmpty(EWR_LIKE_COLLATION_FOR_MSSQL)) {
			return  " COLLATE " + EWR_LIKE_COLLATION_FOR_MSSQL + " LIKE " + pat;
		} else {
			return " LIKE " + pat;
		}
	}

	// Return date search string
	public static string ewr_DateFilterString(string FldOpr, string FldVal, int FldType) {
		var wrkVal1 = ewr_DateVal(FldOpr, FldVal, 1);
		var wrkVal2 = ewr_DateVal(FldOpr, FldVal, 2);
		if (ewr_NotEmpty(wrkVal1) && ewr_NotEmpty(wrkVal2)) {
			return " BETWEEN " + ewr_QuotedValue(wrkVal1, FldType) + " AND " + ewr_QuotedValue(wrkVal2, FldType);
		} else {
			return "";
		}
	}

	//		
	// Validation functions
	//
	// Check date format
	// format: std/stdshort/us/usshort/euro/euroshort
	public static bool ewr_CheckDateEx(string value, string format, string sep)
	{
		if (ewr_Empty(value)) return true; 
		while (value.Contains("  "))
			value = value.Replace("  ", " ");
		value = value.Trim();
		string[] arDT;
		string[] arD;
		string pattern = "";
		string sYear = "";
		string sMonth = "";
		string sDay = "";
		arDT = value.Split(new char[] {' '});
		if (arDT.Length > 0) {
			Match m;
			if ((m = Regex.Match(arDT[0], @"^([0-9]{4})/([0][1-9]|[1][0-2])/([0][1-9]|[1|2][0-9]|[3][0|1])$")) != null && m.Success) { // Accept yyyy/mm/dd
				sYear = m.Groups[1].Value;
				sMonth = m.Groups[2].Value;
				sDay = m.Groups[3].Value;
			} else {
				string wrksep = "\\" + sep;
				switch (format) {
					case "std":
						pattern = "^([0-9]{4})" + wrksep + "([0]?[1-9]|[1][0-2])" + wrksep + "([0]?[1-9]|[1|2][0-9]|[3][0|1])$";
						break;
					case "us":
						pattern = "^([0]?[1-9]|[1][0-2])" + wrksep + "([0]?[1-9]|[1|2][0-9]|[3][0|1])" + wrksep + "([0-9]{4})$";
						break;
					case "euro":
						pattern = "^([0]?[1-9]|[1|2][0-9]|[3][0|1])" + wrksep + "([0]?[1-9]|[1][0-2])" + wrksep + "([0-9]{4})$";
						break;
				}
				if (!Regex.IsMatch(arDT[0], pattern)) return false; 
				arD = arDT[0].Split(new char[] {Convert.ToChar(sep)});
				switch (format) {
					case "std":
					case "stdshort":
						sYear = ewr_UnformatYear(arD[0]);
						sMonth = arD[1];
						sDay = arD[2];
						break;
					case "us":
					case "usshort":
						sYear = ewr_UnformatYear(arD[2]);
						sMonth = arD[0];
						sDay = arD[1];
						break;
					case "euro":
					case "euroshort":
						sYear = ewr_UnformatYear(arD[2]);
						sMonth = arD[1];
						sDay = arD[0];
						break;
				}
			}
			if (!ewr_CheckDay(ewr_ConvertToInt(sYear), ewr_ConvertToInt(sMonth), ewr_ConvertToInt(sDay))) return false; 
		}
		if (arDT.Length > 1 && !ewr_CheckTime(arDT[1])) return false; 
		return true;
	}

	// Unformat 2 digit year to 4 digit year
	public static string ewr_UnformatYear(object year) {
		string yr = Convert.ToString(year);
		if (ewr_IsNumeric(yr) && yr.Length == 2) {
			if (ewr_ConvertToInt(yr) > EWR_UNFORMAT_YEAR)
				return "19" + yr;
			else
				return "20" + yr;
		} else {
			return yr;
		}
	}

	// Check Date format (yyyy/mm/dd)
	public static bool ewr_CheckDate(string value)
	{
		return ewr_CheckDateEx(value, "std", EWR_DATE_SEPARATOR);
	}

	// Check Date format (yy/mm/dd)
	public static bool ewr_CheckShortDate(string value) {
		return ewr_CheckDateEx(value, "stdshort", EWR_DATE_SEPARATOR);
	}

	// Check US Date format (mm/dd/yyyy)
	public static bool ewr_CheckUSDate(string value)
	{
		return ewr_CheckDateEx(value, "us", EWR_DATE_SEPARATOR);
	}

	// Check US Date format (mm/dd/yy)
	public static bool ewr_CheckShortUSDate(string value) {
		return ewr_CheckDateEx(value, "usshort", EWR_DATE_SEPARATOR);
	}

	// Check Euro Date format (dd/mm/yyyy)
	public static bool ewr_CheckEuroDate(string value)
	{
		return ewr_CheckDateEx(value, "euro", EWR_DATE_SEPARATOR);
	}

	// Check Euro Date format (dd/mm/yy)
	public static bool ewr_CheckShortEuroDate(string value) {
		return ewr_CheckDateEx(value, "euroshort", EWR_DATE_SEPARATOR);
	}

	// Check day
	public static bool ewr_CheckDay(int checkYear, int checkMonth, int checkDay)
	{
		int maxDay = 31;
		if (checkMonth == 4 || checkMonth == 6 || checkMonth == 9 || checkMonth == 11) {
			maxDay = 30;
		} else if (checkMonth == 2) {
			if (checkYear % 4 > 0) {
				maxDay = 28;
			} else if (checkYear % 100 == 0 && checkYear % 400 > 0) {
				maxDay = 28;
			} else {
				maxDay = 29;
			}
		}
		return (checkDay >= 1 && checkDay <= maxDay);
	}

	// Check integer
	public static bool ewr_CheckInteger(string value)
	{
		if (ewr_Empty(value)) return true; 
		if (value.Contains(EWR_DECIMAL_POINT))
			return false;
		return ewr_CheckNumber(value);
	}

	// Check number
	public static bool ewr_CheckNumber(string value)
	{
		if (ewr_Empty(value)) return true;
		string pat = @"^[+-]?(\d{1,3}(" + ((EWR_THOUSANDS_SEP != "") ? @"\" + EWR_THOUSANDS_SEP + "?" : "") + @"\d{3})*(\" +
			EWR_DECIMAL_POINT + @"\d+)?|\" + EWR_DECIMAL_POINT + @"\d+)$"; // Note: Do not use ewr_NotEmpty(EWR_THOUSANDS_SEP).
		return Regex.IsMatch(value, pat);
	}

	// Check range
	public static bool ewr_CheckRange(string value, object min, object max)
	{
		if (ewr_Empty(value)) return true;
		if (ewr_IsNumeric(min) || ewr_IsNumeric(max)) { // Number
			if (ewr_CheckNumber(value)) {
				double val = Convert.ToDouble(ewr_StrToFloat(value));
				if (min != null && val < Convert.ToDouble(min) || max != null && val > Convert.ToDouble(max))
					return false;
			}
		} else if (min != null && String.Compare(value, Convert.ToString(min)) < 0 || max != null && String.Compare(value, Convert.ToString(max)) > 0) // String
			return false;
		return true;
	}

	// Check time
	public static bool ewr_CheckTime(string value)
	{
		if (ewr_Empty(value)) return true;
		string[] Values = value.Split(new char[] {'.', ' '}); 
		return Regex.IsMatch(Values[0], "^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9](:[0-5][0-9])?");
	}

	// Check US phone number
	public static bool ewr_CheckPhone(string value)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value, "^\\(\\d{3}\\) ?\\d{3}( |-)?\\d{4}|^\\d{3}( |-)?\\d{3}( |-)?\\d{4}");
	}

	// Check US zip code
	public static bool ewr_CheckZip(string value)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value, "^\\d{5}|^\\d{5}-\\d{4}");
	}

	// Check credit card
	public static bool ewr_CheckCreditCard(string value)
	{
		if (ewr_Empty(value)) return true; 
		var creditcard = new Dictionary<string, string>() {
			{"visa", "^4\\d{3}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"mastercard", "^5[1-5]\\d{2}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"discover", "^6011[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"amex", "^3[4,7]\\d{13}"},
			{"diners", "^3[0,6,8]\\d{12}"},
			{"bankcard", "^5610[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}"},
			{"jcb", "^[3088|3096|3112|3158|3337|3528]\\d{12}"},
			{"enroute", "^[2014|2149]\\d{11}"},
			{"switch", "^[4903|4911|4936|5641|6333|6759|6334|6767]\\d{12}"}
		};
		foreach (var kvp in creditcard) {
			if (Regex.IsMatch(value, kvp.Value))
				return ewr_CheckSum(value);
		}
		return false;
	}

	// Check sum
	public static bool ewr_CheckSum(string value)
	{
		int checksum;
		byte digit;
		value = value.Replace("-", "");
		value = value.Replace(" ", "");
		checksum = 0;
		for (int i = 2 - (value.Length % 2); i <= value.Length; i += 2) {
			checksum = checksum + Convert.ToByte(value[i - 1]);
		}
		for (int i = (value.Length % 2) + 1; i <= value.Length; i += 2) {
			digit = Convert.ToByte(Convert.ToByte(value[i - 1]) * 2);
			checksum = checksum + ((digit < 10) ? digit : (digit - 9));
		}
		return (checksum % 10 == 0);
	}

	// Check US social security number
	public static bool ewr_CheckSSC(string value)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value, "^(?!000)([0-6]\\d{2}|7([0-6]\\d|7[012]))([ -]?)(?!00)\\d\\d\\3(?!0000)\\d{4}");
	}

	// Check email
	public static bool ewr_CheckEmail(string value)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value.Trim(), @"^[\w.%+-]+@[\w.-]+\.[A-Z]{2,6}$", RegexOptions.IgnoreCase);
	}	

	// Check emails
	public static bool ewr_CheckEmailList(string value, int cnt)
	{
		if (ewr_Empty(value)) return true; 
		string emailList = value.Replace(",", ";");
		string[] arEmails = emailList.Split(new char[] {';'});
		if (arEmails.Length > cnt && cnt > 0)
			return false;
		foreach (string email in arEmails) {
			if (!ewr_CheckEmail(email))
				return false;
		}
		return true;
	}	

	// Check GUID
	public static bool ewr_CheckGUID(string value)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value, "^{{1}([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}}{1}") || Regex.IsMatch(value, "^([0-9a-fA-F]){8}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){4}-([0-9a-fA-F]){12}");
	}

	// Check empty string
	public static bool ewr_EmptyStr(object value) {
		string str = Convert.ToString(value).Replace("&nbsp;", "");
		return ewr_Empty(str);
	}	

	// Check by regular expression
	public static bool ewr_CheckByRegEx(string value, string pattern)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value, pattern);
	}

	// Check by regular expression
	public static bool ewr_CheckByRegEx(string value, string pattern, RegexOptions options)
	{
		if (ewr_Empty(value)) return true; 
		return Regex.IsMatch(value, pattern, options);
	}

	// Upload path (relative to application root)
	public static string ewr_UploadPathEx(bool PhyPath, string DestPath)
	{
		if (PhyPath) {			
			return ewr_Server.MapPath(DestPath); // in case virtual directory
		} else {
			return ewr_MapPath(DestPath, false, true); // ASPX
		} 
	}	

	// Get a temp folder for temp file
	public static string ewr_TmpFolder() {
		return Path.GetTempPath();
	}

	// Field data type
	public static int ewr_FieldDataType(int fldtype) {
		switch (fldtype) {
			case 20:
			case 3:
			case 2:
			case 16:
			case 4:
			case 5:
			case 131:
			case 139:
			case 6:
			case 17:
			case 18:
			case 19:
			case 21: // Numeric
				return EWR_DATATYPE_NUMBER;
			case 7:
			case 133:
			case 135: // Date
			case 146: // DateTiemOffset
				return EWR_DATATYPE_DATE;
			case 134: // Time
			case 145: // Time
				return EWR_DATATYPE_TIME;
			case 201:
			case 203: // Memo
				return EWR_DATATYPE_MEMO;
			case 129:
			case 130:
			case 200:
			case 202: // String
				return EWR_DATATYPE_STRING;
			case 11: // Boolean
				return EWR_DATATYPE_BOOLEAN;
			case 72: // GUID
				return EWR_DATATYPE_GUID;
			case 128:
			case 204:
			case 205: // Binary
				return EWR_DATATYPE_BLOB;

			//case 141: // XML
			//	return EWR_DATATYPE_XML;

			default:
				return EWR_DATATYPE_OTHER;
		}
	}

	// Current path  // ASPX
	public static string ewr_CurrentPath(bool PhyPath = true) {
		string p = "";
		string ext = ".vbhtml";
		string[] ar = ewr_Server.MapPath(ewr_ServerVar("SCRIPT_NAME")).Split(new char[] {'\\'}); // Split current path
		if (PhyPath) { // Physical path 

			// Check if folder
			if (Directory.Exists(ewr_Server.MapPath(ewr_ServerVar("SCRIPT_NAME")))) {
				p = ewr_Server.MapPath(ewr_ServerVar("SCRIPT_NAME"));
			} else {
				p = ewr_Server.MapPath(".");		

				// Check URL routing // ASPX
				for (int i = 0; i < ar.Length; i++) {
					string tmp = String.Join("\\", ar.Take(ar.Length - i));
					if (!Path.HasExtension(tmp))
						tmp = Path.ChangeExtension(tmp, ext);
					if (File.Exists(tmp)) {
						p = Path.GetDirectoryName(tmp);
						break;
					}
				}
			}
		} else { // Path relative to host		
			p = ewr_ServerVar("SCRIPT_NAME");		
			string[] ar2 = ewr_ServerVar("SCRIPT_NAME").Split(new char[] {'/'});

			// Check URL routing // ASPX
			for (int i = 0; i < ar.Length; i++) {
				string tmp = String.Join("\\", ar.Take(ar.Length - i));
				if (!Path.HasExtension(tmp))					
					tmp = Path.ChangeExtension(tmp, ext);
				if (File.Exists(tmp)) {
					p = String.Join("/", ar2.Take(ar2.Length - i - 1));
					break;
				}			
			}
		}
		return ewr_IncludeTrailingDelimiter(p, PhyPath);
	}

	// Application root // ASPX
	public static string ewr_AppRoot(bool PhyPath = true) {
		string p = "";
		if (PhyPath) {
			p = ewr_CurrentPath(true);

			// Use Server.MapPath
			if (!Directory.Exists(p))
				p = ewr_Server.MapPath(".");		

			// Use custom path, uncomment the following line and enter your path, e.g. @"C:\Inetpub\wwwroot\MyWebRoot"
			//return @"enter your path here";

			if (!Directory.Exists(p))
				ewr_End("Path of website root unknown.");
		} else {		
			p = ewr_CurrentPath(false);
		}
		return ewr_PathCombine(p, EWR_ROOT_RELATIVE_PATH, PhyPath);
	}

	// Get path relative to app root // ASPX
	public static string ewr_MapPath(string p, bool PhyPath = true, bool FromRoot = false)
	{
		if (Path.IsPathRooted(p) || p.ToLower().StartsWith("http:") || p.ToLower().StartsWith("https:"))
			return p; 
		p = p.Trim().Replace("\\", "/");
		if (p.StartsWith("~/"))
			p = p.Substring(2);
		if (FromRoot) { // relative to app root
			return ewr_PathCombine(ewr_AppRoot(PhyPath), p, PhyPath);
		} else { // relative to script
			return ewr_PathCombine(ewr_CurrentPath(PhyPath), p, PhyPath);
		}
	}

	// Get physical path relative to app root (for backward compatibility) // ASPX
	public static string ewr_ServerMapPath(string p) {
		return ewr_MapPath(p, true, true);
	}

	// Get path relative to a base path
	public static string ewr_PathCombine(string BasePath, string RelPath, bool PhyPath)
	{
		string Delimiter = (PhyPath) ? "\\" : "/";
		BasePath = ewr_RemoveTrailingDelimiter(BasePath, PhyPath);		
		RelPath = (PhyPath) ? RelPath.Replace("/", "\\") : RelPath.Replace("\\", "/");
		if (RelPath == "." || RelPath == "..")
			RelPath = RelPath + Delimiter; 
		int p1 = RelPath.IndexOf(Delimiter);
		string Path2 = "";
		while (p1 > -1) {
			string Path = RelPath.Substring(0, p1 + 1);
			if (Path == Delimiter || Path == "." + Delimiter) {

				// Skip
			} else if (Path == ".." + Delimiter) {
				int p2 = BasePath.LastIndexOf(Delimiter);
				if (p2 > -1)
					BasePath = BasePath.Substring(0, p2); 
			} else {
				Path2 += Path;
			}
			RelPath = RelPath.Substring(p1 + 1);
			p1 = RelPath.IndexOf(Delimiter);
		}
		return ewr_IncludeTrailingDelimiter(BasePath, PhyPath) + Path2 + RelPath; 
	}

	// Remove the last delimiter for a path
	public static string ewr_RemoveTrailingDelimiter(string Path, bool PhyPath)
	{
		string Delimiter = (PhyPath) ? "\\" : "/"; 
		while (Path.EndsWith(Delimiter))
			Path = Path.Substring(0, Path.Length - 1);
		return Path;
	}

	// Include the last delimiter for a path
	public static string ewr_IncludeTrailingDelimiter(string Path, bool PhyPath)
	{
		string Delimiter = (PhyPath) ? "\\" : "/";
		Path = ewr_RemoveTrailingDelimiter(Path, PhyPath);
		return Path + Delimiter;
	}

	// Write the paths for config/debug only
	public static void ewr_WriteUploadPaths()
	{
		ewr_Write("ewr_AppRoot() = " + ewr_AppRoot() + "<br>");
		ewr_Write("APPL_PHYSICAL_PATH = " + ewr_ServerVar("APPL_PHYSICAL_PATH") + "<br>");
		ewr_Write("APPL_MD_PATH = " + ewr_ServerVar("APPL_MD_PATH") + "<br>");
	}

	// Check if folder exists
	public static bool ewr_FolderExists(string folder)
	{
		return Directory.Exists(folder);
	}

	// Check if file exists
	public static bool ewr_FileExists(string fn, string folder = "")
	{
		return File.Exists(folder + fn);
	}

	// Delete file
	public static void ewr_DeleteFile(string FilePath)
	{
		File.Delete(FilePath);
	}

	// Rename file
	public static void ewr_RenameFile(string OldFile, string NewFile)
	{
		File.Move(OldFile, NewFile);
	}

	// Copy file
	public static void ewr_CopyFile(string SrcFile, string DestFile)
	{
		File.Copy(SrcFile, DestFile);
	}

	// Create folder
	public static bool ewr_CreateFolder(string folder)
	{
		try {
			DirectoryInfo di = Directory.CreateDirectory(folder);
			return (di != null);
		} catch {
			return false;
		}
	}

	// Save file
	public static bool ewr_SaveFile(string folder, string fn, byte[] filedata) {
		if (ewr_CreateFolder(folder)) {
			try {
				var	fs = new FileStream(folder + fn, FileMode.Create);
				fs.Write(filedata, 0, filedata.Length);
				fs.Close();
				return true;
			} catch {
				if (EWR_DEBUG_ENABLED) throw; 
				return false;
			}
		}
		return false;
	}

	// Save file // AXR
	public static bool ewr_SaveFile(string folder, string fn, string filedata, Encoding enc) {
		if (ewr_CreateFolder(folder)) {
			try {
				File.WriteAllText(folder + fn, filedata, enc);				
				return true;
			} catch {
				if (EWR_DEBUG_ENABLED) throw; 
				return false;
			}
		}
		return false;
	}

	// Global random
	private static Random ewrGlobalRandom = new Random();

	// Get a random number
	public static int ewr_Random()
	{	
		lock (ewrGlobalRandom) {
			Random NewRandom = new Random(ewrGlobalRandom.Next());
			return NewRandom.Next();
		}
	}

	// Get query string value
	public static string ewr_Get(string name)
	{
		return (ewr_QueryString[name] != null) ? ewr_QueryString[name] : "";
	}

	// Get form value
	public static string ewr_Post(string name)
	{
		return (ewr_Form[name] != null) ? ewr_Form[name] : "";
	}

	// Get/set project cookie
	public static crCookie ewr_Cookie = new crCookie();

	public class crCookie
	{

		public string this[string name] {
			get {
				if (ewr_Request.Cookies[EWR_PROJECT_NAME] != null) {
					return ewr_Request.Cookies[EWR_PROJECT_NAME][name];
				} else {
					return "";
				}
			}
			set {
				HttpCookie c;
				if (ewr_Request.Cookies[EWR_PROJECT_NAME] != null) {
					c = ewr_Request.Cookies[EWR_PROJECT_NAME];
				} else {
					c = new HttpCookie(EWR_PROJECT_NAME);
				}
				c.Values[name] = value;
				c.Path = ewr_AppPath();
				c.Expires = EWR_COOKIE_EXPIRY_TIME;
				ewr_Response.Cookies.Add(c);				
			}
		}
	}

	// Write literal
	public static void ewr_Write(object value) {
		ewr_Page.WriteLiteral(value);
	}

	// Response.WriteBinary
	public static void ewr_BinaryWrite(byte[] value) {
		ewr_Response.WriteBinary(value);
	}

	// Shortcut to ObjectInfo helper, usage: @ewr_Print(variable)
	public HelperResult ewr_Print(object value) {
		return ObjectInfo.Print(value, EWR_OBJECTINFO_DEPTH, EWR_OBJECTINFO_ENUMERATION_LENGTH);
	}

	// Export object info as HTML string
	public static string ewr_VarExport(params object[] list) {
		string str = "";
		foreach (object value in list)
        	str += ObjectInfo.Print(value, EWR_OBJECTINFO_DEPTH, EWR_OBJECTINFO_ENUMERATION_LENGTH).ToHtmlString();
		return str;
    }

	// Write object info in razor page
	public static void ewr_VarPrint(params object[] list) {
		foreach (object value in list)
        	ewr_Write(ewr_VarExport(value));
    }

	// Response.Write object info
	public static void ewr_VarDump(params object[] list) {
		foreach (object value in list)
        	ewr_Response.Write(ewr_VarExport(value));
    }

	// Exit page // ASPX
	public static void ewr_End(object value = null) {
		if (value is string) { // String => Message
			ewr_Response.Write(value);
		} else if (value != null) { // Object
			ewr_VarDump(value);
		}	
		ewr_Response.End();
	}

	// Exit page // ASPX
	public static void ewr_End(params object[] list) {
		ewr_VarDump(list);
		ewr_Response.End();
	}

	// Check if float format
	public static bool ewr_IsFloatFormat(int FldType) {
		return (FldType == 4 || FldType == 5 || FldType == 131 || FldType == 6);
	}

	// Convert string to float
	public static string ewr_StrToFloat(object value) {
		string val = Convert.ToString(value);
		val = val.Replace(" ", "");
		val = val.Replace(EWR_THOUSANDS_SEP, "");
		val = val.Replace(EWR_DECIMAL_POINT, ".");
		return val;
	}

	// Calculate elapsed time
	public static string ewr_ElapsedTime(long tm) {
		double endTimer = Environment.TickCount;
		return "<div>page processing time: " + Convert.ToString((endTimer - tm) / 1000) + " seconds</div>";
	}

	// Convert different data type value
	public static object ewr_Conv(object v, int t) {
		if (Convert.IsDBNull(v)) return System.DBNull.Value; 
		switch (t) {
			case 20: // adBigInt
				return Convert.ToInt64(v);
			case 21: // adUnsignedBigInt
				return Convert.ToUInt64(v);
			case 2:
			case 16: // adSmallInt/adTinyInt
				return Convert.ToInt16(v);
			case 3: // adInteger
				return Convert.ToInt32(v);
			case 17:
			case 18: // adUnsignedTinyInt/adUnsignedSmallInt
				return Convert.ToUInt16(v);
			case 19: // adUnsignedInt
				return Convert.ToUInt32(v);
			case 4: // adSingle
				return Convert.ToSingle(v);
			case 5:
			case 6:
			case 131:
			case 139: // adDouble/adCurrency/adNumeric/adVarNumeric
				return Convert.ToDouble(v);
			default:
				return v;
		}
	}	

	// Convert byte to string // AXR
	public static string ewr_ByteToString(object b, int l) {
		return BitConverter.ToString((byte[])b);
	}

	// Create temp image file from binary data
	public static string ewr_TmpImage(byte[] filedata) {
		string export = "";
		if (ewr_NotEmpty(ewr_Get("export")))
			export = ewr_Get("export");
		else if (ewr_NotEmpty(ewr_Post("export")))
			export = ewr_Post("export");
		string folder = ewr_UploadPathEx(true, EWR_UPLOAD_DEST_PATH);
		string f = folder + Path.GetRandomFileName();
		using (var ms = new MemoryStream(filedata)) {
			try {
				using (var img = System.Drawing.Image.FromStream(ms)) { // ASPX
					if (img.RawFormat.Equals(ImageFormat.Gif)) {
						f = Path.ChangeExtension(f, ".gif");
					} else if (img.RawFormat.Equals(ImageFormat.Jpeg)) {
						f = Path.ChangeExtension(f, ".jpg");
					} else if (img.RawFormat.Equals(ImageFormat.Png)) {
						f = Path.ChangeExtension(f, ".png");
					} else if (img.RawFormat.Equals(ImageFormat.Bmp)) {
						f = Path.ChangeExtension(f, ".bmp");
					} else {
						return "";
					}
					img.Save(f);
				}
			} catch {}
		}
		string tmpimage = Path.GetFileName(f);
		gTmpImages.Add(tmpimage);			
		return ewr_TmpImageLnk(tmpimage, export);
	}

	// Garbage collection
	public static void ewr_GCollect() {

		// Force garbage collection
		GC.Collect();		

		// Wait for all finalizers to complete before continuing. 
		// Without this call to GC.WaitForPendingFinalizers,  
		// the worker loop below might execute at the same time  
		// as the finalizers. 
		// With this call, the worker loop executes only after 
		// all finalizers have been called.

		GC.WaitForPendingFinalizers();
	}	

	// Delete temp images
	public static void ewr_DeleteTmpImages() {
		ewr_GCollect(); // AXR
		if (gTmpImages != null) {			
			string folder = ewr_UploadPathEx(true, EWR_UPLOAD_DEST_PATH);
			foreach (string tmpimage in gTmpImages) {
				string f = folder + tmpimage;
				ewr_DeleteFile(f);
			}
			gTmpImages.Clear();
		}
	}

	// Get temp chart image
	public static string ewr_TmpChartImage(string id) {
		string exportid = "";
		if (ewr_NotEmpty(ewr_Get("exportid")))
			exportid = ewr_Get("exportid");
		else if (ewr_NotEmpty(ewr_Post("exportid")))
			exportid = ewr_Post("exportid");
		string export = "";
		if (ewr_NotEmpty(ewr_Get("export")))
			export = ewr_Get("export");
		else if (ewr_NotEmpty(ewr_Post("export")))
			export = ewr_Post("export");
		if (ewr_NotEmpty(exportid)) {
			string file = exportid + "_" + id + ".jpg";
			string folder = ewr_AppRoot() + EWR_UPLOAD_DEST_PATH;
			string f = folder + file;
			if (File.Exists(f)) {
				string tmpimage = Path.GetFileName(f);
				gTmpImages.Add(tmpimage);			
				return ewr_TmpImageLnk(tmpimage, export);
			}			
		}
		return "";
	}	

	// Create temp file
	public static string ewr_TmpFile(string afile) {		
		if (File.Exists(afile)) { // Copy only
			string export = "";
			if (ewr_NotEmpty(ewr_Get("export")))
				export = ewr_Get("export");
			else if (ewr_NotEmpty(ewr_Post("export")))
				export = ewr_Post("export");
			string folder = ewr_UploadPathEx(true, EWR_UPLOAD_DEST_PATH);
			string f = folder + Path.GetRandomFileName();
			string ext = Path.GetExtension(afile);
			if (ewr_NotEmpty(ext))
				f += ext;
			ewr_CopyFile(afile, f);
			string tmpimage = Path.GetFileName(f);
			gTmpImages.Add(tmpimage);			
			return ewr_TmpImageLnk(tmpimage, export);
		} else {
			return "";
		}
	}

	// Get temp image link
	public static string ewr_TmpImageLnk(string file, string lnktype = "") {
		if (ewr_Empty(file))
			return "";
		if (lnktype == "email" || lnktype == "cid") {
			string[] ar = file.Split(new char[] {'.'});
			var list = new List<string>(ar);
			list.RemoveAt(list.Count - 1);
			ar = list.ToArray();
			string lnk = String.Join(".", ar);
			if (lnktype == "email") lnk = "cid:" + lnk;
			return lnk;
		} else {
			return ewr_UploadPathEx(true, EWR_UPLOAD_DEST_PATH) + file;
		}
	}

	// Remove field/record delimiters from Ajax result
	public static string ewr_RemoveDelimiters(object value) {
		string wrkstr = Convert.ToString(value);
		if (wrkstr.Length > 0) {
			wrkstr = wrkstr.Replace("\r", " ").Replace("\n", " ");
			wrkstr = wrkstr.Replace(EWR_RECORD_DELIMITER, "").Replace(EWR_FIELD_DELIMITER, " ");
		}
		return wrkstr;
	}

	// Invoke method of ASP.NET WebPage // AXR
	public object Invoke(string name, object[] parameters = null) {
		MethodInfo mi = this.GetType().GetMethod(name);
		if (mi != null)
			return mi.Invoke(this, parameters);
		return null;
	}

	// Resize binary to thumbnail
	public static bool ewr_ResizeBinary(ref byte[] filedata, ref int width, ref int height, int interpolation = -1)
	{
		return true; // No resize
	}

	// Resize file to thumbnail file
	public static bool ewr_ResizeFile(string fn, string tn, ref int width, ref int height, int interpolation = -1)
	{
		try {
			if (File.Exists(fn)) {
				File.Copy(fn, tn); // Copy only, no resize
				return true;
			}
			return false;
		} catch {
			if (EWR_DEBUG_ENABLED) throw; 
			return false;
		}
	}

	// Resize file to binary
	public static byte[] ewr_ResizeFileToBinary(string fn, ref int width, ref int height, int interpolation = -1)
	{
		try {
			if (File.Exists(fn)) {
				WebImage img = new WebImage(fn);
				return img.GetBytes(); // No resize
			}
			return null;
		} catch {
			if (EWR_DEBUG_ENABLED) throw; 
			return null;
		}
	}
}
